#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DICOM Loader Module for PET/CT Viewer
-------------------------------------
This module handles loading and processing of DICOM files for PET/CT imaging.
It supports loading of PET, CT, and fused datasets, with appropriate metadata extraction.
"""

import os
import sys
import logging
import numpy as np
import pydicom
from pydicom.errors import InvalidDicomError
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('DicomLoader')

class DicomLoader:
    """
    Class for loading and processing DICOM files for PET/CT imaging.
    Handles different modalities and series, with support for metadata extraction.
    """
    
    def __init__(self):
        """Initialize the DicomLoader with empty datasets."""
        self.pet_dataset = None
        self.ct_dataset = None
        self.pet_series = []
        self.ct_series = []
        self.pet_metadata = {}
        self.ct_metadata = {}
        self.pet_array = None
        self.ct_array = None
        self.pet_pixel_spacing = None
        self.ct_pixel_spacing = None
        self.pet_slice_thickness = None
        self.ct_slice_thickness = None
        self.patient_info = {}
        
    def load_directory(self, directory_path):
        """
        Load all DICOM files from a directory, sorting by modality.
        
        Args:
            directory_path (str): Path to directory containing DICOM files
            
        Returns:
            dict: Dictionary with keys 'pet', 'ct', 'status' containing loaded data and status
        """
        logger.info(f"Loading DICOM files from: {directory_path}")
        
        if not os.path.exists(directory_path):
            logger.error(f"Directory does not exist: {directory_path}")
            return {'status': 'error', 'message': f"Directory does not exist: {directory_path}"}
        
        # Find all potential DICOM files
        dicom_files = []
        for root, _, files in os.walk(directory_path):
            for file in files:
                if file.lower().endswith(('.dcm', '.ima')) or '.' not in file:
                    dicom_files.append(os.path.join(root, file))
        
        if not dicom_files:
            logger.warning(f"No DICOM files found in: {directory_path}")
            return {'status': 'error', 'message': f"No DICOM files found in: {directory_path}"}
        
        # Sort files by modality
        pet_files = []
        ct_files = []
        other_files = []
        
        for file_path in dicom_files:
            try:
                ds = pydicom.dcmread(file_path, force=True)
                
                # Check if it's a valid DICOM file with pixel data
                if not hasattr(ds, 'SOPClassUID') or not hasattr(ds, 'Modality'):
                    other_files.append(file_path)
                    continue
                
                # Sort by modality
                if ds.Modality == 'PT':
                    pet_files.append((file_path, ds))
                elif ds.Modality == 'CT':
                    ct_files.append((file_path, ds))
                else:
                    other_files.append(file_path)
                    
            except (InvalidDicomError, AttributeError, IOError) as e:
                logger.warning(f"Error reading file {file_path}: {str(e)}")
                other_files.append(file_path)
        
        logger.info(f"Found {len(pet_files)} PET files, {len(ct_files)} CT files, and {len(other_files)} other files")
        
        # Process PET files if available
        if pet_files:
            self._process_pet_files(pet_files)
        
        # Process CT files if available
        if ct_files:
            self._process_ct_files(ct_files)
        
        # Extract patient information from any valid dataset
        if pet_files:
            self._extract_patient_info(pet_files[0][1])
        elif ct_files:
            self._extract_patient_info(ct_files[0][1])
        
        return {
            'status': 'success',
            'pet': len(pet_files) > 0,
            'ct': len(ct_files) > 0,
            'message': f"Loaded {len(pet_files)} PET files and {len(ct_files)} CT files"
        }
    
    def _extract_patient_info(self, dataset):
        """Extract patient information from a DICOM dataset."""
        try:
            self.patient_info = {
                'PatientName': str(dataset.PatientName) if hasattr(dataset, 'PatientName') else 'Unknown',
                'PatientID': dataset.PatientID if hasattr(dataset, 'PatientID') else 'Unknown',
                'PatientBirthDate': dataset.PatientBirthDate if hasattr(dataset, 'PatientBirthDate') else 'Unknown',
                'PatientSex': dataset.PatientSex if hasattr(dataset, 'PatientSex') else 'Unknown',
                'StudyDate': dataset.StudyDate if hasattr(dataset, 'StudyDate') else 'Unknown',
                'StudyTime': dataset.StudyTime if hasattr(dataset, 'StudyTime') else 'Unknown',
                'StudyDescription': dataset.StudyDescription if hasattr(dataset, 'StudyDescription') else 'Unknown',
                'Modality': dataset.Modality if hasattr(dataset, 'Modality') else 'Unknown',
            }
        except Exception as e:
            logger.error(f"Error extracting patient info: {str(e)}")
            self.patient_info = {'Error': 'Failed to extract patient information'}
    
    def _process_pet_files(self, pet_files):
        """Process PET DICOM files and organize them into series."""
        # Group files by SeriesInstanceUID
        series_dict = defaultdict(list)
        for file_path, ds in pet_files:
            if hasattr(ds, 'SeriesInstanceUID'):
                series_dict[ds.SeriesInstanceUID].append((file_path, ds))
            else:
                logger.warning(f"PET file missing SeriesInstanceUID: {file_path}")
        
        # Process each series
        for series_uid, files in series_dict.items():
            try:
                # Sort files by slice location if available
                sorted_files = self._sort_by_slice_location(files)
                
                # Extract metadata from first file
                ref_ds = sorted_files[0][1]
                
                # Create 3D array for this series
                series_array, pixel_spacing, slice_thickness = self._create_3d_array(sorted_files)
                
                # Store series information
                series_info = {
                    'SeriesInstanceUID': series_uid,
                    'SeriesDescription': ref_ds.SeriesDescription if hasattr(ref_ds, 'SeriesDescription') else 'Unknown',
                    'SeriesNumber': ref_ds.SeriesNumber if hasattr(ref_ds, 'SeriesNumber') else 0,
                    'Rows': ref_ds.Rows if hasattr(ref_ds, 'Rows') else 0,
                    'Columns': ref_ds.Columns if hasattr(ref_ds, 'Columns') else 0,
                    'SliceCount': len(sorted_files),
                    'PixelSpacing': pixel_spacing,
                    'SliceThickness': slice_thickness,
                    'Array': series_array
                }
                
                self.pet_series.append(series_info)
                
                # Use the largest series as the default PET dataset
                if self.pet_array is None or series_array.shape[2] > self.pet_array.shape[2]:
                    self.pet_array = series_array
                    self.pet_pixel_spacing = pixel_spacing
                    self.pet_slice_thickness = slice_thickness
                    self.pet_metadata = {
                        'SeriesDescription': series_info['SeriesDescription'],
                        'SeriesNumber': series_info['SeriesNumber'],
                        'Rows': series_info['Rows'],
                        'Columns': series_info['Columns'],
                        'SliceCount': series_info['SliceCount']
                    }
                
            except Exception as e:
                logger.error(f"Error processing PET series {series_uid}: {str(e)}")
    
    def _process_ct_files(self, ct_files):
        """Process CT DICOM files and organize them into series."""
        # Group files by SeriesInstanceUID
        series_dict = defaultdict(list)
        for file_path, ds in ct_files:
            if hasattr(ds, 'SeriesInstanceUID'):
                series_dict[ds.SeriesInstanceUID].append((file_path, ds))
            else:
                logger.warning(f"CT file missing SeriesInstanceUID: {file_path}")
        
        # Process each series
        for series_uid, files in series_dict.items():
            try:
                # Sort files by slice location if available
                sorted_files = self._sort_by_slice_location(files)
                
                # Extract metadata from first file
                ref_ds = sorted_files[0][1]
                
                # Create 3D array for this series
                series_array, pixel_spacing, slice_thickness = self._create_3d_array(sorted_files)
                
                # Store series information
                series_info = {
                    'SeriesInstanceUID': series_uid,
                    'SeriesDescription': ref_ds.SeriesDescription if hasattr(ref_ds, 'SeriesDescription') else 'Unknown',
                    'SeriesNumber': ref_ds.SeriesNumber if hasattr(ref_ds, 'SeriesNumber') else 0,
                    'Rows': ref_ds.Rows if hasattr(ref_ds, 'Rows') else 0,
                    'Columns': ref_ds.Columns if hasattr(ref_ds, 'Columns') else 0,
                    'SliceCount': len(sorted_files),
                    'PixelSpacing': pixel_spacing,
                    'SliceThickness': slice_thickness,
                    'Array': series_array
                }
                
                self.ct_series.append(series_info)
                
                # Use the largest series as the default CT dataset
                if self.ct_array is None or series_array.shape[2] > self.ct_array.shape[2]:
                    self.ct_array = series_array
                    self.ct_pixel_spacing = pixel_spacing
                    self.ct_slice_thickness = slice_thickness
                    self.ct_metadata = {
                        'SeriesDescription': series_info['SeriesDescription'],
                        'SeriesNumber': series_info['SeriesNumber'],
                        'Rows': series_info['Rows'],
                        'Columns': series_info['Columns'],
                        'SliceCount': series_info['SliceCount']
                    }
                
            except Exception as e:
                logger.error(f"Error processing CT series {series_uid}: {str(e)}")
    
    def _sort_by_slice_location(self, files):
        """Sort DICOM files by slice location."""
        def get_slice_location(file_tuple):
            ds = file_tuple[1]
            # Try different DICOM tags for slice location
            if hasattr(ds, 'SliceLocation'):
                return float(ds.SliceLocation)
            elif hasattr(ds, 'ImagePositionPatient'):
                # Use the z-coordinate of the Image Position Patient
                return float(ds.ImagePositionPatient[2])
            elif hasattr(ds, 'InstanceNumber'):
                # Fall back to instance number if slice location is not available
                return float(ds.InstanceNumber)
            else:
                # If no location information is available, return 0
                return 0
        
        try:
            return sorted(files, key=get_slice_location)
        except Exception as e:
            logger.warning(f"Error sorting slices: {str(e)}. Using original order.")
            return files
    
    def _create_3d_array(self, sorted_files):
        """Create a 3D numpy array from sorted DICOM files."""
        # Get dimensions from the first file
        ref_ds = sorted_files[0][1]
        rows = int(ref_ds.Rows)
        cols = int(ref_ds.Columns)
        slices = len(sorted_files)
        
        # Get pixel spacing and slice thickness
        pixel_spacing = None
        if hasattr(ref_ds, 'PixelSpacing'):
            pixel_spacing = (float(ref_ds.PixelSpacing[0]), float(ref_ds.PixelSpacing[1]))
        else:
            pixel_spacing = (1.0, 1.0)  # Default if not available
        
        slice_thickness = None
        if hasattr(ref_ds, 'SliceThickness'):
            slice_thickness = float(ref_ds.SliceThickness)
        else:
            slice_thickness = 1.0  # Default if not available
        
        # Create empty 3D array
        array_3d = np.zeros((rows, cols, slices), dtype=np.float32)
        
        # Fill array with pixel data
        for i, (_, ds) in enumerate(sorted_files):
            # Get pixel array
            pixel_array = ds.pixel_array
            
            # Convert to float for processing
            pixel_array = pixel_array.astype(np.float32)
            
            # Apply rescale slope and intercept if available
            if hasattr(ds, 'RescaleSlope') and hasattr(ds, 'RescaleIntercept'):
                pixel_array = pixel_array * float(ds.RescaleSlope) + float(ds.RescaleIntercept)
            
            # Store in 3D array
            array_3d[:, :, i] = pixel_array
        
        return array_3d, pixel_spacing, slice_thickness
    
    def get_pet_array(self):
        """Get the PET 3D array."""
        return self.pet_array
    
    def get_ct_array(self):
        """Get the CT 3D array."""
        return self.ct_array
    
    def get_pet_metadata(self):
        """Get PET metadata."""
        return self.pet_metadata
    
    def get_ct_metadata(self):
        """Get CT metadata."""
        return self.ct_metadata
    
    def get_patient_info(self):
        """Get patient information."""
        return self.patient_info
    
    def get_pet_series_list(self):
        """Get list of available PET series."""
        return [{'SeriesDescription': s['SeriesDescription'], 
                 'SeriesNumber': s['SeriesNumber'],
                 'SliceCount': s['SliceCount']} for s in self.pet_series]
    
    def get_ct_series_list(self):
        """Get list of available CT series."""
        return [{'SeriesDescription': s['SeriesDescription'], 
                 'SeriesNumber': s['SeriesNumber'],
                 'SliceCount': s['SliceCount']} for s in self.ct_series]
    
    def select_pet_series(self, series_number):
        """Select a specific PET series by series number."""
        for series in self.pet_series:
            if series['SeriesNumber'] == series_number:
                self.pet_array = series['Array']
                self.pet_pixel_spacing = series['PixelSpacing']
                self.pet_slice_thickness = series['SliceThickness']
                self.pet_metadata = {
                    'SeriesDescription': series['SeriesDescription'],
                    'SeriesNumber': series['SeriesNumber'],
                    'Rows': series['Rows'],
                    'Columns': series['Columns'],
                    'SliceCount': series['SliceCount']
                }
                return True
        return False
    
    def select_ct_series(self, series_number):
        """Select a specific CT series by series number."""
        for series in self.ct_series:
            if series['SeriesNumber'] == series_number:
                self.ct_array = series['Array']
                self.ct_pixel_spacing = series['PixelSpacing']
                self.ct_slice_thickness = series['SliceThickness']
                self.ct_metadata = {
                    'SeriesDescription': series['SeriesDescription'],
                    'SeriesNumber': series['SeriesNumber'],
                    'Rows': series['Rows'],
                    'Columns': series['Columns'],
                    'SliceCount': series['SliceCount']
                }
                return True
        return False
    
    def create_fusion_array(self, pet_weight=0.5, ct_weight=0.5):
        """
        Create a fused PET/CT array.
        
        Args:
            pet_weight (float): Weight for PET image (0.0-1.0)
            ct_weight (float): Weight for CT image (0.0-1.0)
            
        Returns:
            numpy.ndarray: Fused 3D array, or None if either PET or CT is missing
        """
        if self.pet_array is None or self.ct_array is None:
            logger.warning("Cannot create fusion: PET or CT data missing")
            return None
        
        # Check if arrays have the same dimensions
        if self.pet_array.shape != self.ct_array.shape:
            logger.warning("PET and CT arrays have different dimensions. Resampling required.")
            # In a real application, we would resample one to match the other
            # For simplicity, we'll just return None for now
            return None
        
        # Normalize arrays to 0-1 range for fusion
        pet_min, pet_max = np.min(self.pet_array), np.max(self.pet_array)
        ct_min, ct_max = np.min(self.ct_array), np.max(self.ct_array)
        
        pet_norm = (self.pet_array - pet_min) / (pet_max - pet_min) if pet_max > pet_min else np.zeros_like(self.pet_array)
        ct_norm = (self.ct_array - ct_min) / (ct_max - ct_min) if ct_max > ct_min else np.zeros_like(self.ct_array)
        
        # Create fusion with weights
        fusion_array = (pet_norm * pet_weight + ct_norm * ct_weight) / (pet_weight + ct_weight)
        
        return fusion_array
    
    def calculate_suv(self, pet_array=None, patient_weight=None, injected_dose=None, decay_factor=None):
        """
        Calculate SUV (Standardized Uptake Value) for PET data.
        
        Args:
            pet_array (numpy.ndarray, optional): PET array to use. If None, uses self.pet_array
            patient_weight (float, optional): Patient weight in kg. If None, tries to extract from DICOM
            injected_dose (float, optional): Injected dose in Bq. If None, tries to extract from DICOM
            decay_factor (float, optional): Decay factor. If None, tries to calculate from DICOM
            
        Returns:
            numpy.ndarray: SUV array, or None if calculation fails
        """
        if pet_array is None:
            pet_array = self.pet_array
            
        if pet_array is None:
            logger.warning("No PET data available for SUV calculation")
            return None
        
        # In a real application, we would extract these values from DICOM metadata
        # and perform the actual SUV calculation
        # For now, we'll just return the original PET array
        logger.warning("SUV calculation not fully implemented - returning original PET values")
        return pet_array
    
    def get_mip_projection(self, array=None, axis=2):
        """
        Create Maximum Intensity Projection (MIP) of a 3D array.
        
        Args:
            array (numpy.ndarray, optional): 3D array to use. If None, uses PET array
            axis (int): Axis along which to project (0=sagittal, 1=coronal, 2=axial)
            
        Returns:
            numpy.ndarray: 2D MIP projection, or None if calculation fails
        """
        if array is None:
            array = self.pet_array
            
        if array is None:
            logger.warning("No data available for MIP projection")
            return None
        
        try:
            # Create MIP by taking maximum along specified axis
            mip = np.max(array, axis=axis)
            return mip
        except Exception as e:
            logger.error(f"Error creating MIP projection: {str(e)}")
            return None


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    loader = DicomLoader()
    
    # Check if a directory path was provided
    if len(sys.argv) > 1:
        directory_path = sys.argv[1]
        result = loader.load_directory(directory_path)
        print(f"Load result: {result}")
        
        # Print some information about loaded data
        if result['status'] == 'success':
            if result['pet']:
                print("\nPET Series:")
                for i, series in enumerate(loader.get_pet_series_list()):
                    print(f"  {i+1}. {series['SeriesDescription']} - {series['SliceCount']} slices")
            
            if result['ct']:
                print("\nCT Series:")
                for i, series in enumerate(loader.get_ct_series_list()):
                    print(f"  {i+1}. {series['SeriesDescription']} - {series['SliceCount']} slices")
            
            print("\nPatient Info:")
            for key, value in loader.get_patient_info().items():
                print(f"  {key}: {value}")
    else:
        print("Usage: python dicom_loader.py <dicom_directory>")
