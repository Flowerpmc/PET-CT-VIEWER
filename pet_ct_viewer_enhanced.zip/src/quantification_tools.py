#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Quantification Tools Module for PET/CT Viewer
------------------------------------------
This module provides enhanced quantification tools with statistics display.
"""

import os
import sys
import logging
import numpy as np
import vtk
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('QuantificationTools')

class MeasurementData:
    """
    Class for storing measurement data.
    """
    
    def __init__(self, measurement_type, points=None, values=None, metadata=None):
        """
        Initialize the MeasurementData.
        
        Args:
            measurement_type (str): Type of measurement ('distance', 'angle', 'roi', 'suv', etc.)
            points (list, optional): List of measurement points
            values (dict, optional): Dictionary of measurement values
            metadata (dict, optional): Additional metadata
        """
        self.measurement_type = measurement_type
        self.points = points or []
        self.values = values or {}
        self.metadata = metadata or {}
        self.timestamp = QtCore.QDateTime.currentDateTime()
        self.id = f"{measurement_type}_{self.timestamp.toString('yyyyMMdd_hhmmss_zzz')}"
    
    def to_dict(self):
        """
        Convert measurement data to dictionary.
        
        Returns:
            dict: Measurement data as dictionary
        """
        return {
            'id': self.id,
            'type': self.measurement_type,
            'points': self.points,
            'values': self.values,
            'metadata': self.metadata,
            'timestamp': self.timestamp.toString(QtCore.Qt.ISODate)
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        Create measurement data from dictionary.
        
        Args:
            data (dict): Measurement data as dictionary
            
        Returns:
            MeasurementData: Created measurement data
        """
        measurement = cls(
            data.get('type', 'unknown'),
            data.get('points', []),
            data.get('values', {}),
            data.get('metadata', {})
        )
        measurement.id = data.get('id', measurement.id)
        measurement.timestamp = QtCore.QDateTime.fromString(data.get('timestamp', ''), QtCore.Qt.ISODate)
        return measurement


class QuantificationManager:
    """
    Class for managing quantification tools and measurements.
    """
    
    # Constants for measurement types
    MEASUREMENT_DISTANCE = 'distance'
    MEASUREMENT_ANGLE = 'angle'
    MEASUREMENT_ROI = 'roi'
    MEASUREMENT_SUV = 'suv'
    MEASUREMENT_VOLUME = 'volume'
    
    def __init__(self):
        """Initialize the QuantificationManager."""
        # Initialize variables
        self.measurements = {}
        self.current_measurement = None
        self.image_data = None
        self.pixel_spacing = (1.0, 1.0, 1.0)  # Default pixel spacing in mm
        self.suv_factor = 1.0  # Default SUV factor
    
    def set_image_data(self, image_data, pixel_spacing=None, suv_factor=None):
        """
        Set the image data for quantification.
        
        Args:
            image_data (vtkImageData): Image data
            pixel_spacing (tuple, optional): Pixel spacing in mm (x, y, z)
            suv_factor (float, optional): SUV factor
        """
        self.image_data = image_data
        
        if pixel_spacing:
            self.pixel_spacing = pixel_spacing
        
        if suv_factor:
            self.suv_factor = suv_factor
    
    def start_measurement(self, measurement_type):
        """
        Start a new measurement.
        
        Args:
            measurement_type (str): Type of measurement
            
        Returns:
            MeasurementData: Created measurement data
        """
        self.current_measurement = MeasurementData(measurement_type)
        return self.current_measurement
    
    def add_measurement_point(self, point, world_point=None):
        """
        Add a point to the current measurement.
        
        Args:
            point (tuple): Point coordinates (x, y) in display coordinates
            world_point (tuple, optional): Point coordinates (x, y, z) in world coordinates
            
        Returns:
            bool: True if point was added, False otherwise
        """
        if not self.current_measurement:
            logger.warning("No active measurement")
            return False
        
        # Add point
        if world_point:
            self.current_measurement.points.append(world_point)
        else:
            self.current_measurement.points.append(point)
        
        return True
    
    def complete_measurement(self):
        """
        Complete the current measurement.
        
        Returns:
            MeasurementData: Completed measurement data, or None if no active measurement
        """
        if not self.current_measurement:
            logger.warning("No active measurement")
            return None
        
        # Calculate measurement values
        self._calculate_measurement_values()
        
        # Store measurement
        self.measurements[self.current_measurement.id] = self.current_measurement
        
        # Get completed measurement
        completed = self.current_measurement
        
        # Reset current measurement
        self.current_measurement = None
        
        return completed
    
    def cancel_measurement(self):
        """Cancel the current measurement."""
        self.current_measurement = None
    
    def get_measurement(self, measurement_id):
        """
        Get a measurement by ID.
        
        Args:
            measurement_id (str): Measurement ID
            
        Returns:
            MeasurementData: Measurement data, or None if not found
        """
        return self.measurements.get(measurement_id)
    
    def get_measurements(self, measurement_type=None):
        """
        Get all measurements of a specific type.
        
        Args:
            measurement_type (str, optional): Type of measurement, or None for all
            
        Returns:
            list: List of measurement data
        """
        if measurement_type:
            return [m for m in self.measurements.values() if m.measurement_type == measurement_type]
        else:
            return list(self.measurements.values())
    
    def remove_measurement(self, measurement_id):
        """
        Remove a measurement.
        
        Args:
            measurement_id (str): Measurement ID
            
        Returns:
            bool: True if measurement was removed, False otherwise
        """
        if measurement_id in self.measurements:
            del self.measurements[measurement_id]
            return True
        return False
    
    def clear_measurements(self, measurement_type=None):
        """
        Clear all measurements of a specific type.
        
        Args:
            measurement_type (str, optional): Type of measurement, or None for all
        """
        if measurement_type:
            self.measurements = {k: v for k, v in self.measurements.items() if v.measurement_type != measurement_type}
        else:
            self.measurements = {}
    
    def _calculate_measurement_values(self):
        """Calculate values for the current measurement."""
        if not self.current_measurement:
            return
        
        measurement_type = self.current_measurement.measurement_type
        points = self.current_measurement.points
        
        if measurement_type == self.MEASUREMENT_DISTANCE:
            self._calculate_distance(points)
        elif measurement_type == self.MEASUREMENT_ANGLE:
            self._calculate_angle(points)
        elif measurement_type == self.MEASUREMENT_ROI:
            self._calculate_roi_statistics(points)
        elif measurement_type == self.MEASUREMENT_SUV:
            self._calculate_suv_statistics(points)
        elif measurement_type == self.MEASUREMENT_VOLUME:
            self._calculate_volume_statistics(points)
    
    def _calculate_distance(self, points):
        """
        Calculate distance between points.
        
        Args:
            points (list): List of points
        """
        if len(points) < 2:
            return
        
        # Get points
        p1 = np.array(points[0])
        p2 = np.array(points[-1])
        
        # Calculate distance
        if len(p1) == 3 and len(p2) == 3:
            # 3D distance
            distance_mm = np.sqrt(np.sum((p2 - p1) ** 2))
        else:
            # 2D distance with pixel spacing
            dx = (p2[0] - p1[0]) * self.pixel_spacing[0]
            dy = (p2[1] - p1[1]) * self.pixel_spacing[1]
            distance_mm = np.sqrt(dx*dx + dy*dy)
        
        # Store values
        self.current_measurement.values['distance_mm'] = float(distance_mm)
        self.current_measurement.values['distance_cm'] = float(distance_mm / 10.0)
        self.current_measurement.values['start_point'] = points[0]
        self.current_measurement.values['end_point'] = points[-1]
    
    def _calculate_angle(self, points):
        """
        Calculate angle between three points.
        
        Args:
            points (list): List of points
        """
        if len(points) < 3:
            return
        
        # Get points
        p1 = np.array(points[0])
        p2 = np.array(points[1])
        p3 = np.array(points[2])
        
        # Calculate vectors
        v1 = p1 - p2
        v2 = p3 - p2
        
        # Calculate angle
        dot_product = np.dot(v1, v2)
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        if norm_v1 == 0 or norm_v2 == 0:
            angle_rad = 0
        else:
            cos_angle = dot_product / (norm_v1 * norm_v2)
            cos_angle = max(-1, min(1, cos_angle))  # Clamp to [-1, 1]
            angle_rad = np.arccos(cos_angle)
        
        angle_deg = np.degrees(angle_rad)
        
        # Store values
        self.current_measurement.values['angle_rad'] = float(angle_rad)
        self.current_measurement.values['angle_deg'] = float(angle_deg)
        self.current_measurement.values['vertex_point'] = points[1]
    
    def _calculate_roi_statistics(self, points):
        """
        Calculate statistics for a region of interest.
        
        Args:
            points (list): List of points defining the ROI
        """
        if len(points) < 3 or not self.image_data:
            return
        
        try:
            # Convert points to numpy array
            roi_points = np.array(points)
            
            # Get image data as numpy array
            vtk_array = self.image_data.GetPointData().GetScalars()
            dims = self.image_data.GetDimensions()
            numpy_array = vtk.util.numpy_support.vtk_to_numpy(vtk_array)
            numpy_array = numpy_array.reshape(dims[2], dims[1], dims[0])
            
            # Create mask for ROI
            mask = self._create_roi_mask(roi_points, dims)
            
            # Apply mask to image data
            masked_data = numpy_array[mask]
            
            # Calculate statistics
            if len(masked_data) > 0:
                min_value = float(np.min(masked_data))
                max_value = float(np.max(masked_data))
                mean_value = float(np.mean(masked_data))
                median_value = float(np.median(masked_data))
                std_value = float(np.std(masked_data))
                
                # Calculate area
                area_pixels = len(masked_data)
                area_mm2 = area_pixels * self.pixel_spacing[0] * self.pixel_spacing[1]
                
                # Store values
                self.current_measurement.values['min'] = min_value
                self.current_measurement.values['max'] = max_value
                self.current_measurement.values['mean'] = mean_value
                self.current_measurement.values['median'] = median_value
                self.current_measurement.values['std'] = std_value
                self.current_measurement.values['area_pixels'] = area_pixels
                self.current_measurement.values['area_mm2'] = float(area_mm2)
                self.current_measurement.values['area_cm2'] = float(area_mm2 / 100.0)
        except Exception as e:
            logger.error(f"Error calculating ROI statistics: {str(e)}")
    
    def _create_roi_mask(self, points, dims):
        """
        Create a mask for a region of interest.
        
        Args:
            points (numpy.ndarray): Array of points defining the ROI
            dims (tuple): Image dimensions
            
        Returns:
            numpy.ndarray: Boolean mask
        """
        # Create empty mask
        mask = np.zeros((dims[2], dims[1], dims[0]), dtype=bool)
        
        # Get current slice
        current_slice = 0  # Assuming 2D ROI on first slice
        
        # Create 2D mask for current slice
        slice_mask = np.zeros((dims[1], dims[0]), dtype=bool)
        
        # Convert points to pixel coordinates
        pixel_points = []
        for point in points:
            if len(point) >= 2:
                x = int(point[0])
                y = int(point[1])
                pixel_points.append((x, y))
        
        # Create polygon
        from PIL import Image, ImageDraw
        polygon = Image.new('L', (dims[0], dims[1]), 0)
        ImageDraw.Draw(polygon).polygon(pixel_points, outline=1, fill=1)
        polygon_mask = np.array(polygon, dtype=bool)
        
        # Apply polygon mask to slice
        slice_mask = polygon_mask
        
        # Apply slice mask to 3D mask
        mask[current_slice] = slice_mask
        
        return mask
    
    def _calculate_suv_statistics(self, points):
        """
        Calculate SUV statistics for a point or region.
        
        Args:
            points (list): List of points
        """
        if len(points) < 1 or not self.image_data:
            return
        
        try:
            # Get image data as numpy array
            vtk_array = self.image_data.GetPointData().GetScalars()
            dims = self.image_data.GetDimensions()
            numpy_array = vtk.util.numpy_support.vtk_to_numpy(vtk_array)
            numpy_array = numpy_array.reshape(dims[2], dims[1], dims[0])
            
            if len(points) == 1:
                # Single point SUV
                point = points[0]
                if len(point) >= 3:
                    # 3D point
                    x, y, z = int(point[0]), int(point[1]), int(point[2])
                else:
                    # 2D point, assume current slice is 0
                    x, y = int(point[0]), int(point[1])
                    z = 0
                
                # Check bounds
                if 0 <= x < dims[0] and 0 <= y < dims[1] and 0 <= z < dims[2]:
                    # Get value at point
                    value = float(numpy_array[z, y, x])
                    
                    # Calculate SUV
                    suv = value * self.suv_factor
                    
                    # Store values
                    self.current_measurement.values['value'] = value
                    self.current_measurement.values['suv'] = suv
                    self.current_measurement.values['point'] = (x, y, z)
            else:
                # ROI SUV statistics
                # Create mask for ROI
                mask = self._create_roi_mask(points, dims)
                
                # Apply mask to image data
                masked_data = numpy_array[mask]
                
                # Calculate statistics
                if len(masked_data) > 0:
                    min_value = float(np.min(masked_data))
                    max_value = float(np.max(masked_data))
                    mean_value = float(np.mean(masked_data))
                    
                    # Calculate SUV values
                    min_suv = min_value * self.suv_factor
                    max_suv = max_value * self.suv_factor
                    mean_suv = mean_value * self.suv_factor
                    
                    # Store values
                    self.current_measurement.values['min_value'] = min_value
                    self.current_measurement.values['max_value'] = max_value
                    self.current_measurement.values['mean_value'] = mean_value
                    self.current_measurement.values['min_suv'] = min_suv
                    self.current_measurement.values['max_suv'] = max_suv
                    self.current_measurement.values['mean_suv'] = mean_suv
                    self.current_measurement.values['suv_factor'] = self.suv_factor
        except Exception as e:
            logger.error(f"Error calculating SUV statistics: {str(e)}")
    
    def _calculate_volume_statistics(self, points):
        """
        Calculate volume statistics for a 3D region.
        
        Args:
            points (list): List of points defining the 3D region
        """
        if len(points) < 4 or not self.image_data:
            return
        
        try:
            # This is a simplified implementation
            # A real implementation would use more sophisticated 3D segmentation
            
            # Get image data as numpy array
            vtk_array = self.image_data.GetPointData().GetScalars()
            dims = self.image_data.GetDimensions()
            numpy_array = vtk.util.numpy_support.vtk_to_numpy(vtk_array)
            numpy_array = numpy_array.reshape(dims[2], dims[1], dims[0])
            
            # Create bounding box from points
            x_coords = [p[0] for p in points if len(p) >= 1]
            y_coords = [p[1] for p in points if len(p) >= 2]
            z_coords = [p[2] for p in points if len(p) >= 3]
            
            min_x, max_x = int(min(x_coords)), int(max(x_coords))
            min_y, max_y = int(min(y_coords)), int(max(y_coords))
            min_z, max_z = int(min(z_coords)), int(max(z_coords))
            
            # Clip to image bounds
            min_x = max(0, min_x)
            min_y = max(0, min_y)
            min_z = max(0, min_z)
            max_x = min(dims[0] - 1, max_x)
            max_y = min(dims[1] - 1, max_y)
            max_z = min(dims[2] - 1, max_z)
            
            # Extract volume data
            volume_data = numpy_array[min_z:max_z+1, min_y:max_y+1, min_x:max_x+1]
            
            # Calculate statistics
            min_value = float(np.min(volume_data))
            max_value = float(np.max(volume_data))
            mean_value = float(np.mean(volume_data))
            
            # Calculate volume
            voxel_count = volume_data.size
            voxel_volume = self.pixel_spacing[0] * self.pixel_spacing[1] * self.pixel_spacing[2]
            volume_mm3 = voxel_count * voxel_volume
            
            # Store values
            self.current_measurement.values['min'] = min_value
            self.current_measurement.values['max'] = max_value
            self.current_measurement.values['mean'] = mean_value
            self.current_measurement.values['voxel_count'] = voxel_count
            self.current_measurement.values['volume_mm3'] = float(volume_mm3)
            self.current_measurement.values['volume_cm3'] = float(volume_mm3 / 1000.0)
            self.current_measurement.values['bounds'] = ((min_x, min_y, min_z), (max_x, max_y, max_z))
        except Exception as e:
            logger.error(f"Error calculating volume statistics: {str(e)}")


class MeasurementActor:
    """
    Class for creating and managing measurement actors.
    """
    
    def __init__(self, renderer):
        """
        Initialize the MeasurementActor.
        
        Args:
            renderer (vtkRenderer): VTK renderer
        """
        self.renderer = renderer
        self.actors = {}
        self.text_actors = {}
    
    def create_distance_actor(self, measurement):
        """
        Create actors for a distance measurement.
        
        Args:
            measurement (MeasurementData): Measurement data
            
        Returns:
            list: List of created actors
        """
        if measurement.measurement_type != QuantificationManager.MEASUREMENT_DISTANCE:
            return []
        
        if len(measurement.points) < 2:
            return []
        
        # Get points
        p1 = measurement.points[0]
        p2 = measurement.points[-1]
        
        # Create line
        line = vtk.vtkLineSource()
        line.SetPoint1(p1[0], p1[1], 0)
        line.SetPoint2(p2[0], p2[1], 0)
        
        # Create mapper
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(line.GetOutputPort())
        
        # Create actor
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)  # Red
        actor.GetProperty().SetLineWidth(2)
        
        # Add to renderer
        self.renderer.AddActor(actor)
        
        # Create text actor
        distance_mm = measurement.values.get('distance_mm', 0)
        text = f"{distance_mm:.2f} mm"
        
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(text)
        
        # Calculate text position (midpoint of line)
        mid_x = (p1[0] + p2[0]) / 2
        mid_y = (p1[1] + p2[1]) / 2
        text_actor.SetPosition(mid_x, mid_y)
        
        # Set text properties
        text_property = text_actor.GetTextProperty()
        text_property.SetColor(1, 1, 0)  # Yellow
        text_property.SetFontSize(14)
        text_property.SetBold(True)
        text_property.SetShadow(True)
        
        # Add to renderer
        self.renderer.AddActor(text_actor)
        
        # Store actors
        self.actors[measurement.id] = [actor]
        self.text_actors[measurement.id] = [text_actor]
        
        return [actor, text_actor]
    
    def create_angle_actor(self, measurement):
        """
        Create actors for an angle measurement.
        
        Args:
            measurement (MeasurementData): Measurement data
            
        Returns:
            list: List of created actors
        """
        if measurement.measurement_type != QuantificationManager.MEASUREMENT_ANGLE:
            return []
        
        if len(measurement.points) < 3:
            return []
        
        # Get points
        p1 = measurement.points[0]
        p2 = measurement.points[1]
        p3 = measurement.points[2]
        
        # Create lines
        line1 = vtk.vtkLineSource()
        line1.SetPoint1(p2[0], p2[1], 0)
        line1.SetPoint2(p1[0], p1[1], 0)
        
        line2 = vtk.vtkLineSource()
        line2.SetPoint1(p2[0], p2[1], 0)
        line2.SetPoint2(p3[0], p3[1], 0)
        
        # Create mappers
        mapper1 = vtk.vtkPolyDataMapper()
        mapper1.SetInputConnection(line1.GetOutputPort())
        
        mapper2 = vtk.vtkPolyDataMapper()
        mapper2.SetInputConnection(line2.GetOutputPort())
        
        # Create actors
        actor1 = vtk.vtkActor()
        actor1.SetMapper(mapper1)
        actor1.GetProperty().SetColor(1, 0, 0)  # Red
        actor1.GetProperty().SetLineWidth(2)
        
        actor2 = vtk.vtkActor()
        actor2.SetMapper(mapper2)
        actor2.GetProperty().SetColor(1, 0, 0)  # Red
        actor2.GetProperty().SetLineWidth(2)
        
        # Add to renderer
        self.renderer.AddActor(actor1)
        self.renderer.AddActor(actor2)
        
        # Create text actor
        angle_deg = measurement.values.get('angle_deg', 0)
        text = f"{angle_deg:.1f}°"
        
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(text)
        
        # Set text position (at vertex)
        text_actor.SetPosition(p2[0], p2[1])
        
        # Set text properties
        text_property = text_actor.GetTextProperty()
        text_property.SetColor(1, 1, 0)  # Yellow
        text_property.SetFontSize(14)
        text_property.SetBold(True)
        text_property.SetShadow(True)
        
        # Add to renderer
        self.renderer.AddActor(text_actor)
        
        # Store actors
        self.actors[measurement.id] = [actor1, actor2]
        self.text_actors[measurement.id] = [text_actor]
        
        return [actor1, actor2, text_actor]
    
    def create_roi_actor(self, measurement):
        """
        Create actors for a region of interest measurement.
        
        Args:
            measurement (MeasurementData): Measurement data
            
        Returns:
            list: List of created actors
        """
        if measurement.measurement_type != QuantificationManager.MEASUREMENT_ROI:
            return []
        
        if len(measurement.points) < 3:
            return []
        
        # Create polygon
        polygon = vtk.vtkPolygon()
        polygon.GetPointIds().SetNumberOfIds(len(measurement.points))
        
        points = vtk.vtkPoints()
        for i, point in enumerate(measurement.points):
            points.InsertPoint(i, point[0], point[1], 0)
            polygon.GetPointIds().SetId(i, i)
        
        # Create cell array
        polygons = vtk.vtkCellArray()
        polygons.InsertNextCell(polygon)
        
        # Create polydata
        polydata = vtk.vtkPolyData()
        polydata.SetPoints(points)
        polydata.SetPolys(polygons)
        
        # Create mapper
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(polydata)
        
        # Create actor
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(0, 1, 0)  # Green
        actor.GetProperty().SetOpacity(0.3)
        
        # Add to renderer
        self.renderer.AddActor(actor)
        
        # Create text actor
        mean_value = measurement.values.get('mean', 0)
        area_mm2 = measurement.values.get('area_mm2', 0)
        text = f"Mean: {mean_value:.1f}\nArea: {area_mm2:.1f} mm²"
        
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(text)
        
        # Calculate text position (centroid of polygon)
        centroid_x = sum(p[0] for p in measurement.points) / len(measurement.points)
        centroid_y = sum(p[1] for p in measurement.points) / len(measurement.points)
        text_actor.SetPosition(centroid_x, centroid_y)
        
        # Set text properties
        text_property = text_actor.GetTextProperty()
        text_property.SetColor(1, 1, 0)  # Yellow
        text_property.SetFontSize(14)
        text_property.SetBold(True)
        text_property.SetShadow(True)
        
        # Add to renderer
        self.renderer.AddActor(text_actor)
        
        # Store actors
        self.actors[measurement.id] = [actor]
        self.text_actors[measurement.id] = [text_actor]
        
        return [actor, text_actor]
    
    def create_suv_actor(self, measurement):
        """
        Create actors for a SUV measurement.
        
        Args:
            measurement (MeasurementData): Measurement data
            
        Returns:
            list: List of created actors
        """
        if measurement.measurement_type != QuantificationManager.MEASUREMENT_SUV:
            return []
        
        if len(measurement.points) < 1:
            return []
        
        # Get point
        point = measurement.points[0]
        
        # Create sphere
        sphere = vtk.vtkSphereSource()
        sphere.SetCenter(point[0], point[1], 0)
        sphere.SetRadius(3)
        sphere.SetPhiResolution(10)
        sphere.SetThetaResolution(10)
        
        # Create mapper
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(sphere.GetOutputPort())
        
        # Create actor
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 1)  # Magenta
        
        # Add to renderer
        self.renderer.AddActor(actor)
        
        # Create text actor
        suv = measurement.values.get('suv', 0)
        text = f"SUV: {suv:.2f}"
        
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(text)
        
        # Set text position
        text_actor.SetPosition(point[0] + 5, point[1] + 5)
        
        # Set text properties
        text_property = text_actor.GetTextProperty()
        text_property.SetColor(1, 1, 0)  # Yellow
        text_property.SetFontSize(14)
        text_property.SetBold(True)
        text_property.SetShadow(True)
        
        # Add to renderer
        self.renderer.AddActor(text_actor)
        
        # Store actors
        self.actors[measurement.id] = [actor]
        self.text_actors[measurement.id] = [text_actor]
        
        return [actor, text_actor]
    
    def create_volume_actor(self, measurement):
        """
        Create actors for a volume measurement.
        
        Args:
            measurement (MeasurementData): Measurement data
            
        Returns:
            list: List of created actors
        """
        if measurement.measurement_type != QuantificationManager.MEASUREMENT_VOLUME:
            return []
        
        if 'bounds' not in measurement.values:
            return []
        
        # Get bounds
        bounds = measurement.values['bounds']
        min_point, max_point = bounds
        
        # Create box
        box = vtk.vtkCubeSource()
        box.SetBounds(
            min_point[0], max_point[0],
            min_point[1], max_point[1],
            min_point[2], max_point[2]
        )
        
        # Create mapper
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(box.GetOutputPort())
        
        # Create actor
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(0, 0, 1)  # Blue
        actor.GetProperty().SetOpacity(0.3)
        actor.GetProperty().SetRepresentationToWireframe()
        
        # Add to renderer
        self.renderer.AddActor(actor)
        
        # Create text actor
        volume_cm3 = measurement.values.get('volume_cm3', 0)
        mean_value = measurement.values.get('mean', 0)
        text = f"Volume: {volume_cm3:.2f} cm³\nMean: {mean_value:.1f}"
        
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(text)
        
        # Set text position
        center_x = (min_point[0] + max_point[0]) / 2
        center_y = (min_point[1] + max_point[1]) / 2
        text_actor.SetPosition(center_x, center_y)
        
        # Set text properties
        text_property = text_actor.GetTextProperty()
        text_property.SetColor(1, 1, 0)  # Yellow
        text_property.SetFontSize(14)
        text_property.SetBold(True)
        text_property.SetShadow(True)
        
        # Add to renderer
        self.renderer.AddActor(text_actor)
        
        # Store actors
        self.actors[measurement.id] = [actor]
        self.text_actors[measurement.id] = [text_actor]
        
        return [actor, text_actor]
    
    def create_measurement_actor(self, measurement):
        """
        Create actors for a measurement.
        
        Args:
            measurement (MeasurementData): Measurement data
            
        Returns:
            list: List of created actors
        """
        if measurement.measurement_type == QuantificationManager.MEASUREMENT_DISTANCE:
            return self.create_distance_actor(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_ANGLE:
            return self.create_angle_actor(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_ROI:
            return self.create_roi_actor(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_SUV:
            return self.create_suv_actor(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_VOLUME:
            return self.create_volume_actor(measurement)
        else:
            return []
    
    def remove_measurement_actor(self, measurement_id):
        """
        Remove actors for a measurement.
        
        Args:
            measurement_id (str): Measurement ID
            
        Returns:
            bool: True if actors were removed, False otherwise
        """
        # Remove actors
        if measurement_id in self.actors:
            for actor in self.actors[measurement_id]:
                self.renderer.RemoveActor(actor)
            del self.actors[measurement_id]
        
        # Remove text actors
        if measurement_id in self.text_actors:
            for actor in self.text_actors[measurement_id]:
                self.renderer.RemoveActor(actor)
            del self.text_actors[measurement_id]
        
        return True
    
    def clear_all_actors(self):
        """Remove all measurement actors."""
        # Remove all actors
        for measurement_id in list(self.actors.keys()):
            self.remove_measurement_actor(measurement_id)


class StatisticsWidget(QtWidgets.QWidget):
    """
    Widget for displaying measurement statistics.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the StatisticsWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(StatisticsWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Create statistics label
        self.stats_label = QtWidgets.QLabel("No measurements")
        self.stats_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        self.stats_label.setWordWrap(True)
        layout.addWidget(self.stats_label)
        
        # Set style
        self.setStyleSheet("""
            QWidget {
                background-color: rgba(0, 0, 0, 128);
                color: white;
                border-radius: 5px;
            }
            QLabel {
                font-size: 12px;
                font-weight: bold;
            }
        """)
        
        # Set size policy
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
    
    def update_statistics(self, measurement=None):
        """
        Update statistics display.
        
        Args:
            measurement (MeasurementData, optional): Measurement data, or None to clear
        """
        if not measurement:
            self.stats_label.setText("No measurements")
            return
        
        # Format statistics based on measurement type
        if measurement.measurement_type == QuantificationManager.MEASUREMENT_DISTANCE:
            self._format_distance_stats(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_ANGLE:
            self._format_angle_stats(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_ROI:
            self._format_roi_stats(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_SUV:
            self._format_suv_stats(measurement)
        elif measurement.measurement_type == QuantificationManager.MEASUREMENT_VOLUME:
            self._format_volume_stats(measurement)
        else:
            self.stats_label.setText(f"Unknown measurement type: {measurement.measurement_type}")
    
    def _format_distance_stats(self, measurement):
        """
        Format distance measurement statistics.
        
        Args:
            measurement (MeasurementData): Measurement data
        """
        distance_mm = measurement.values.get('distance_mm', 0)
        distance_cm = measurement.values.get('distance_cm', 0)
        
        text = f"Distance: {distance_mm:.2f} mm ({distance_cm:.2f} cm)"
        self.stats_label.setText(text)
    
    def _format_angle_stats(self, measurement):
        """
        Format angle measurement statistics.
        
        Args:
            measurement (MeasurementData): Measurement data
        """
        angle_deg = measurement.values.get('angle_deg', 0)
        
        text = f"Angle: {angle_deg:.1f}°"
        self.stats_label.setText(text)
    
    def _format_roi_stats(self, measurement):
        """
        Format ROI measurement statistics.
        
        Args:
            measurement (MeasurementData): Measurement data
        """
        min_value = measurement.values.get('min', 0)
        max_value = measurement.values.get('max', 0)
        mean_value = measurement.values.get('mean', 0)
        median_value = measurement.values.get('median', 0)
        std_value = measurement.values.get('std', 0)
        area_mm2 = measurement.values.get('area_mm2', 0)
        area_cm2 = measurement.values.get('area_cm2', 0)
        
        text = (
            f"ROI Statistics:\n"
            f"Min: {min_value:.1f}\n"
            f"Max: {max_value:.1f}\n"
            f"Mean: {mean_value:.1f}\n"
            f"Median: {median_value:.1f}\n"
            f"StdDev: {std_value:.1f}\n"
            f"Area: {area_mm2:.1f} mm² ({area_cm2:.2f} cm²)"
        )
        self.stats_label.setText(text)
    
    def _format_suv_stats(self, measurement):
        """
        Format SUV measurement statistics.
        
        Args:
            measurement (MeasurementData): Measurement data
        """
        if 'suv' in measurement.values:
            # Single point SUV
            value = measurement.values.get('value', 0)
            suv = measurement.values.get('suv', 0)
            
            text = f"SUV: {suv:.2f} (Raw: {value:.1f})"
        else:
            # ROI SUV statistics
            min_suv = measurement.values.get('min_suv', 0)
            max_suv = measurement.values.get('max_suv', 0)
            mean_suv = measurement.values.get('mean_suv', 0)
            
            text = (
                f"SUV Statistics:\n"
                f"Min SUV: {min_suv:.2f}\n"
                f"Max SUV: {max_suv:.2f}\n"
                f"Mean SUV: {mean_suv:.2f}"
            )
        
        self.stats_label.setText(text)
    
    def _format_volume_stats(self, measurement):
        """
        Format volume measurement statistics.
        
        Args:
            measurement (MeasurementData): Measurement data
        """
        min_value = measurement.values.get('min', 0)
        max_value = measurement.values.get('max', 0)
        mean_value = measurement.values.get('mean', 0)
        volume_mm3 = measurement.values.get('volume_mm3', 0)
        volume_cm3 = measurement.values.get('volume_cm3', 0)
        
        text = (
            f"Volume Statistics:\n"
            f"Min: {min_value:.1f}\n"
            f"Max: {max_value:.1f}\n"
            f"Mean: {mean_value:.1f}\n"
            f"Volume: {volume_mm3:.1f} mm³ ({volume_cm3:.2f} cm³)"
        )
        self.stats_label.setText(text)


class QuantificationToolsWidget(QtWidgets.QWidget):
    """
    Widget for quantification tools.
    """
    
    # Signal emitted when a tool is selected
    toolSelected = QtCore.pyqtSignal(str)
    
    # Signal emitted when a measurement is completed
    measurementCompleted = QtCore.pyqtSignal(object)
    
    def __init__(self, parent=None):
        """
        Initialize the QuantificationToolsWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(QuantificationToolsWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create tool buttons
        self.tool_buttons = {}
        
        # Create button group
        self.button_group = QtWidgets.QButtonGroup(self)
        self.button_group.setExclusive(True)
        
        # Create tools
        tools_layout = QtWidgets.QHBoxLayout()
        
        self._add_tool_button(tools_layout, "pointer", "Pointer", "Select tool")
        self._add_tool_button(tools_layout, "distance", "Distance", "Measure distance")
        self._add_tool_button(tools_layout, "angle", "Angle", "Measure angle")
        self._add_tool_button(tools_layout, "roi", "ROI", "Region of interest")
        self._add_tool_button(tools_layout, "suv", "SUV", "SUV measurement")
        self._add_tool_button(tools_layout, "volume", "Volume", "Volume measurement")
        
        layout.addLayout(tools_layout)
        
        # Create statistics widget
        self.stats_widget = StatisticsWidget()
        layout.addWidget(self.stats_widget)
        
        # Initialize quantification manager
        self.quant_manager = QuantificationManager()
        
        # Initialize variables
        self.current_tool = "pointer"
        self.current_measurement = None
        self.renderer = None
        self.measurement_actor = None
        
        # Select default tool
        self.select_tool("pointer")
    
    def _add_tool_button(self, layout, tool_id, text, tooltip):
        """
        Add a tool button.
        
        Args:
            layout (QLayout): Layout to add button to
            tool_id (str): Tool identifier
            text (str): Button text
            tooltip (str): Button tooltip
        """
        button = QtWidgets.QPushButton(text)
        button.setCheckable(True)
        button.setToolTip(tooltip)
        button.clicked.connect(lambda checked, tid=tool_id: self.select_tool(tid))
        
        layout.addWidget(button)
        self.tool_buttons[tool_id] = button
        self.button_group.addButton(button)
    
    def select_tool(self, tool_id):
        """
        Select a tool.
        
        Args:
            tool_id (str): Tool identifier
        """
        if tool_id in self.tool_buttons:
            self.tool_buttons[tool_id].setChecked(True)
            self.current_tool = tool_id
            self.toolSelected.emit(tool_id)
            
            # Cancel current measurement if any
            if self.current_measurement:
                self.quant_manager.cancel_measurement()
                self.current_measurement = None
    
    def set_renderer(self, renderer):
        """
        Set the VTK renderer.
        
        Args:
            renderer (vtkRenderer): VTK renderer
        """
        self.renderer = renderer
        
        # Create measurement actor
        if self.renderer:
            self.measurement_actor = MeasurementActor(self.renderer)
    
    def set_image_data(self, image_data, pixel_spacing=None, suv_factor=None):
        """
        Set the image data for quantification.
        
        Args:
            image_data (vtkImageData): Image data
            pixel_spacing (tuple, optional): Pixel spacing in mm (x, y, z)
            suv_factor (float, optional): SUV factor
        """
        self.quant_manager.set_image_data(image_data, pixel_spacing, suv_factor)
    
    def handle_mouse_press(self, event_pos, world_pos=None):
        """
        Handle mouse press event.
        
        Args:
            event_pos (tuple): Event position (x, y) in display coordinates
            world_pos (tuple, optional): World position (x, y, z)
            
        Returns:
            bool: True if event was handled, False otherwise
        """
        if self.current_tool == "pointer":
            return False
        
        # Start new measurement if none is active
        if not self.current_measurement:
            measurement_type = self._get_measurement_type()
            self.current_measurement = self.quant_manager.start_measurement(measurement_type)
        
        # Add point to measurement
        if world_pos:
            self.quant_manager.add_measurement_point(event_pos, world_pos)
        else:
            self.quant_manager.add_measurement_point(event_pos)
        
        # Check if measurement is complete
        if self._is_measurement_complete():
            self._complete_measurement()
        
        return True
    
    def handle_mouse_move(self, event_pos, world_pos=None):
        """
        Handle mouse move event.
        
        Args:
            event_pos (tuple): Event position (x, y) in display coordinates
            world_pos (tuple, optional): World position (x, y, z)
            
        Returns:
            bool: True if event was handled, False otherwise
        """
        # Nothing to do if no active measurement
        if not self.current_measurement:
            return False
        
        # TODO: Implement preview of measurement
        
        return True
    
    def handle_key_press(self, key):
        """
        Handle key press event.
        
        Args:
            key (str): Key pressed
            
        Returns:
            bool: True if event was handled, False otherwise
        """
        if key == "Escape":
            # Cancel current measurement
            if self.current_measurement:
                self.quant_manager.cancel_measurement()
                self.current_measurement = None
                return True
        elif key == "Enter" or key == "Return":
            # Complete current measurement
            if self.current_measurement:
                self._complete_measurement()
                return True
        
        return False
    
    def _get_measurement_type(self):
        """
        Get measurement type based on current tool.
        
        Returns:
            str: Measurement type
        """
        if self.current_tool == "distance":
            return QuantificationManager.MEASUREMENT_DISTANCE
        elif self.current_tool == "angle":
            return QuantificationManager.MEASUREMENT_ANGLE
        elif self.current_tool == "roi":
            return QuantificationManager.MEASUREMENT_ROI
        elif self.current_tool == "suv":
            return QuantificationManager.MEASUREMENT_SUV
        elif self.current_tool == "volume":
            return QuantificationManager.MEASUREMENT_VOLUME
        else:
            return "unknown"
    
    def _is_measurement_complete(self):
        """
        Check if the current measurement is complete.
        
        Returns:
            bool: True if measurement is complete, False otherwise
        """
        if not self.current_measurement:
            return False
        
        measurement_type = self.current_measurement.measurement_type
        num_points = len(self.current_measurement.points)
        
        if measurement_type == QuantificationManager.MEASUREMENT_DISTANCE:
            return num_points >= 2
        elif measurement_type == QuantificationManager.MEASUREMENT_ANGLE:
            return num_points >= 3
        elif measurement_type == QuantificationManager.MEASUREMENT_ROI:
            return num_points >= 3 and num_points % 3 == 0  # Complete after every 3 points
        elif measurement_type == QuantificationManager.MEASUREMENT_SUV:
            return num_points >= 1
        elif measurement_type == QuantificationManager.MEASUREMENT_VOLUME:
            return num_points >= 8  # 8 points for a box (2 points per dimension)
        
        return False
    
    def _complete_measurement(self):
        """Complete the current measurement."""
        if not self.current_measurement:
            return
        
        # Complete measurement
        measurement = self.quant_manager.complete_measurement()
        
        # Create actors
        if self.measurement_actor:
            self.measurement_actor.create_measurement_actor(measurement)
        
        # Update statistics
        self.stats_widget.update_statistics(measurement)
        
        # Emit signal
        self.measurementCompleted.emit(measurement)
        
        # Reset current measurement
        self.current_measurement = None
    
    def clear_measurements(self):
        """Clear all measurements."""
        # Clear measurements
        self.quant_manager.clear_measurements()
        
        # Clear actors
        if self.measurement_actor:
            self.measurement_actor.clear_all_actors()
        
        # Clear statistics
        self.stats_widget.update_statistics(None)


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("Quantification Tools Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QVBoxLayout(central_widget)
    
    # Create quantification tools widget
    quant_tools = QuantificationToolsWidget()
    layout.addWidget(quant_tools)
    
    # Create statistics widget
    stats_widget = StatisticsWidget()
    layout.addWidget(stats_widget)
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
