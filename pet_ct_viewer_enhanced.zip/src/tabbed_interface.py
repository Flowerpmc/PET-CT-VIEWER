#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Tabbed Interface Module for PET/CT Viewer
---------------------------------------
This module provides a tabbed interface for multi-patient support.
"""

import os
import sys
import logging
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('TabbedInterface')

class PatientTab(QtWidgets.QWidget):
    """
    Widget representing a single patient tab.
    """
    
    def __init__(self, patient_id="", patient_name="", study_date="", parent=None):
        """
        Initialize the PatientTab.
        
        Args:
            patient_id (str): Patient ID
            patient_name (str): Patient name
            study_date (str): Study date
            parent (QWidget, optional): Parent widget
        """
        super(PatientTab, self).__init__(parent)
        
        # Store patient information
        self.patient_id = patient_id
        self.patient_name = patient_name
        self.study_date = study_date
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create placeholder for viewer content
        self.content_widget = QtWidgets.QWidget()
        layout.addWidget(self.content_widget)
        
        # Initialize variables
        self.pet_series = None
        self.ct_series = None
        self.is_modified = False
    
    def set_content_widget(self, widget):
        """
        Set the content widget for this tab.
        
        Args:
            widget (QWidget): Content widget
        """
        # Remove old content
        if self.content_widget:
            self.layout().removeWidget(self.content_widget)
            self.content_widget.deleteLater()
        
        # Add new content
        self.content_widget = widget
        self.layout().addWidget(self.content_widget)
    
    def set_pet_series(self, series):
        """
        Set the PET series for this tab.
        
        Args:
            series (dict): PET series information
        """
        self.pet_series = series
        self.is_modified = True
    
    def set_ct_series(self, series):
        """
        Set the CT series for this tab.
        
        Args:
            series (dict): CT series information
        """
        self.ct_series = series
        self.is_modified = True
    
    def get_patient_info(self):
        """
        Get patient information.
        
        Returns:
            dict: Patient information
        """
        return {
            'patient_id': self.patient_id,
            'patient_name': self.patient_name,
            'study_date': self.study_date
        }
    
    def set_patient_info(self, info):
        """
        Set patient information.
        
        Args:
            info (dict): Patient information
        """
        self.patient_id = info.get('patient_id', '')
        self.patient_name = info.get('patient_name', '')
        self.study_date = info.get('study_date', '')
    
    def mark_saved(self):
        """Mark the tab as saved (not modified)."""
        self.is_modified = False
    
    def is_saved(self):
        """
        Check if the tab is saved.
        
        Returns:
            bool: True if saved, False if modified
        """
        return not self.is_modified


class TabbedInterface(QtWidgets.QTabWidget):
    """
    Widget for managing multiple patient tabs.
    """
    
    # Signal emitted when a tab is selected
    tabSelected = QtCore.pyqtSignal(int)
    
    # Signal emitted when a tab is closed
    tabClosed = QtCore.pyqtSignal(int)
    
    # Signal emitted when a new tab is requested
    newTabRequested = QtCore.pyqtSignal()
    
    def __init__(self, parent=None):
        """
        Initialize the TabbedInterface.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(TabbedInterface, self).__init__(parent)
        
        # Enable tab closing
        self.setTabsClosable(True)
        
        # Enable tab reordering
        self.setMovable(True)
        
        # Add "+" tab for creating new tabs
        self.addTab(QtWidgets.QWidget(), "+")
        
        # Connect signals
        self.tabCloseRequested.connect(self._on_tab_close_requested)
        self.currentChanged.connect(self._on_current_changed)
        
        # Initialize variables
        self.tab_counter = 0
    
    def add_patient_tab(self, patient_id="", patient_name="", study_date=""):
        """
        Add a new patient tab.
        
        Args:
            patient_id (str): Patient ID
            patient_name (str): Patient name
            study_date (str): Study date
            
        Returns:
            PatientTab: The created patient tab
        """
        # Create tab
        tab = PatientTab(patient_id, patient_name, study_date)
        
        # Generate tab title
        if patient_name:
            title = patient_name
        elif patient_id:
            title = f"Patient {patient_id}"
        else:
            self.tab_counter += 1
            title = f"Patient {self.tab_counter}"
        
        # Insert tab before the "+" tab
        index = self.count() - 1
        self.insertTab(index, tab, title)
        
        # Select the new tab
        self.setCurrentIndex(index)
        
        return tab
    
    def get_current_patient_tab(self):
        """
        Get the current patient tab.
        
        Returns:
            PatientTab: Current patient tab, or None if no patient tab is selected
        """
        current_widget = self.currentWidget()
        if isinstance(current_widget, PatientTab):
            return current_widget
        return None
    
    def get_patient_tab(self, index):
        """
        Get the patient tab at the specified index.
        
        Args:
            index (int): Tab index
            
        Returns:
            PatientTab: Patient tab, or None if index is invalid or not a patient tab
        """
        if 0 <= index < self.count() - 1:  # Exclude "+" tab
            widget = self.widget(index)
            if isinstance(widget, PatientTab):
                return widget
        return None
    
    def get_patient_tabs(self):
        """
        Get all patient tabs.
        
        Returns:
            list: List of PatientTab objects
        """
        tabs = []
        for i in range(self.count() - 1):  # Exclude "+" tab
            widget = self.widget(i)
            if isinstance(widget, PatientTab):
                tabs.append(widget)
        return tabs
    
    def update_tab_title(self, index):
        """
        Update the title of a tab based on its patient information.
        
        Args:
            index (int): Tab index
        """
        tab = self.get_patient_tab(index)
        if tab:
            # Get patient info
            info = tab.get_patient_info()
            
            # Generate title
            if info['patient_name']:
                title = info['patient_name']
            elif info['patient_id']:
                title = f"Patient {info['patient_id']}"
            else:
                title = f"Patient {index + 1}"
            
            # Add asterisk if modified
            if not tab.is_saved():
                title += "*"
            
            # Set tab title
            self.setTabText(index, title)
    
    def _on_tab_close_requested(self, index):
        """
        Handle tab close request.
        
        Args:
            index (int): Tab index
        """
        # Check if it's the "+" tab
        if index == self.count() - 1:
            return
        
        # Get tab
        tab = self.get_patient_tab(index)
        if not tab:
            return
        
        # Check if tab is saved
        if not tab.is_saved():
            # Ask for confirmation
            reply = QtWidgets.QMessageBox.question(
                self,
                "Close Tab",
                "This tab has unsaved changes. Are you sure you want to close it?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No
            )
            
            if reply == QtWidgets.QMessageBox.No:
                return
        
        # Remove tab
        self.removeTab(index)
        
        # Emit signal
        self.tabClosed.emit(index)
    
    def _on_current_changed(self, index):
        """
        Handle current tab change.
        
        Args:
            index (int): New tab index
        """
        # Check if it's the "+" tab
        if index == self.count() - 1:
            # Reset to previous tab
            if self.count() > 1:
                self.setCurrentIndex(index - 1)
            
            # Emit signal to create new tab
            self.newTabRequested.emit()
            return
        
        # Emit signal
        self.tabSelected.emit(index)


class PatientTabManager:
    """
    Class for managing patient tabs and their content.
    """
    
    def __init__(self, tabbed_interface):
        """
        Initialize the PatientTabManager.
        
        Args:
            tabbed_interface (TabbedInterface): Tabbed interface to manage
        """
        self.tabbed_interface = tabbed_interface
        
        # Connect signals
        self.tabbed_interface.tabSelected.connect(self._on_tab_selected)
        self.tabbed_interface.tabClosed.connect(self._on_tab_closed)
        self.tabbed_interface.newTabRequested.connect(self._on_new_tab_requested)
        
        # Initialize variables
        self.current_tab_index = -1
        self.tab_content_widgets = {}
    
    def create_new_tab(self, patient_info=None):
        """
        Create a new patient tab.
        
        Args:
            patient_info (dict, optional): Patient information
            
        Returns:
            PatientTab: The created patient tab
        """
        # Extract patient info
        patient_id = ""
        patient_name = ""
        study_date = ""
        
        if patient_info:
            patient_id = patient_info.get('patient_id', '')
            patient_name = patient_info.get('patient_name', '')
            study_date = patient_info.get('study_date', '')
        
        # Create tab
        tab = self.tabbed_interface.add_patient_tab(patient_id, patient_name, study_date)
        
        # Get tab index
        index = self.tabbed_interface.indexOf(tab)
        
        # Update tab title
        self.tabbed_interface.update_tab_title(index)
        
        return tab
    
    def set_tab_content(self, index, widget):
        """
        Set the content widget for a tab.
        
        Args:
            index (int): Tab index
            widget (QWidget): Content widget
        """
        tab = self.tabbed_interface.get_patient_tab(index)
        if tab:
            tab.set_content_widget(widget)
            self.tab_content_widgets[index] = widget
    
    def get_tab_content(self, index):
        """
        Get the content widget for a tab.
        
        Args:
            index (int): Tab index
            
        Returns:
            QWidget: Content widget, or None if not found
        """
        return self.tab_content_widgets.get(index)
    
    def set_tab_patient_info(self, index, info):
        """
        Set patient information for a tab.
        
        Args:
            index (int): Tab index
            info (dict): Patient information
        """
        tab = self.tabbed_interface.get_patient_tab(index)
        if tab:
            tab.set_patient_info(info)
            self.tabbed_interface.update_tab_title(index)
    
    def get_tab_patient_info(self, index):
        """
        Get patient information for a tab.
        
        Args:
            index (int): Tab index
            
        Returns:
            dict: Patient information, or None if not found
        """
        tab = self.tabbed_interface.get_patient_tab(index)
        if tab:
            return tab.get_patient_info()
        return None
    
    def mark_tab_saved(self, index):
        """
        Mark a tab as saved.
        
        Args:
            index (int): Tab index
        """
        tab = self.tabbed_interface.get_patient_tab(index)
        if tab:
            tab.mark_saved()
            self.tabbed_interface.update_tab_title(index)
    
    def mark_tab_modified(self, index):
        """
        Mark a tab as modified.
        
        Args:
            index (int): Tab index
        """
        tab = self.tabbed_interface.get_patient_tab(index)
        if tab:
            tab.is_modified = True
            self.tabbed_interface.update_tab_title(index)
    
    def is_tab_saved(self, index):
        """
        Check if a tab is saved.
        
        Args:
            index (int): Tab index
            
        Returns:
            bool: True if saved, False if modified
        """
        tab = self.tabbed_interface.get_patient_tab(index)
        if tab:
            return tab.is_saved()
        return True
    
    def _on_tab_selected(self, index):
        """
        Handle tab selection.
        
        Args:
            index (int): Selected tab index
        """
        self.current_tab_index = index
    
    def _on_tab_closed(self, index):
        """
        Handle tab closure.
        
        Args:
            index (int): Closed tab index
        """
        # Remove content widget
        if index in self.tab_content_widgets:
            del self.tab_content_widgets[index]
        
        # Update current tab index
        if self.current_tab_index >= index:
            self.current_tab_index -= 1
    
    def _on_new_tab_requested(self):
        """Handle new tab request."""
        self.create_new_tab()


class TabContentWidget(QtWidgets.QWidget):
    """
    Base class for tab content widgets.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the TabContentWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(TabContentWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create placeholder
        label = QtWidgets.QLabel("Tab Content")
        label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(label)
    
    def save_state(self):
        """
        Save the widget state.
        
        Returns:
            dict: Widget state
        """
        return {}
    
    def restore_state(self, state):
        """
        Restore the widget state.
        
        Args:
            state (dict): Widget state
        """
        pass


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("Tabbed Interface Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create tabbed interface
    tabbed_interface = TabbedInterface()
    window.setCentralWidget(tabbed_interface)
    
    # Create tab manager
    tab_manager = PatientTabManager(tabbed_interface)
    
    # Create some test tabs
    tab1 = tab_manager.create_new_tab({
        'patient_id': '12345',
        'patient_name': 'John Doe',
        'study_date': '2025-05-18'
    })
    
    tab2 = tab_manager.create_new_tab({
        'patient_id': '67890',
        'patient_name': 'Jane Smith',
        'study_date': '2025-05-17'
    })
    
    # Create content widgets
    content1 = TabContentWidget()
    content2 = TabContentWidget()
    
    # Set content widgets
    tab_manager.set_tab_content(0, content1)
    tab_manager.set_tab_content(1, content2)
    
    # Mark tab as modified
    tab_manager.mark_tab_modified(0)
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
