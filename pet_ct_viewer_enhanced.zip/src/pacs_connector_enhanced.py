#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PACS Connector Module for PET/CT Viewer
-------------------------------------
This module provides enhanced PACS connectivity with credentials support.
"""

import os
import sys
import logging
import json
import socket
import time
import threading
import queue
from datetime import datetime
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('PACSConnector')

try:
    import pydicom
    import pynetdicom
    from pynetdicom import AE, evt, AllStoragePresentationContexts, StoragePresentationContexts
    from pynetdicom.sop_class import (
        PatientRootQueryRetrieveInformationModelFind,
        PatientRootQueryRetrieveInformationModelGet,
        PatientRootQueryRetrieveInformationModelMove,
        StudyRootQueryRetrieveInformationModelFind,
        StudyRootQueryRetrieveInformationModelGet,
        StudyRootQueryRetrieveInformationModelMove,
        ModalityWorklistInformationFind
    )
    HAVE_PYNETDICOM = True
except ImportError:
    logger.warning("pynetdicom not found, PACS connectivity will be limited")
    HAVE_PYNETDICOM = False


class PACSServer:
    """
    Class representing a PACS server configuration.
    """
    
    def __init__(self, name="", host="", port=104, aet="PYNETDICOM", aec="ANY-SCP", username="", password=""):
        """
        Initialize the PACSServer.
        
        Args:
            name (str): Server name
            host (str): Server host (IP address or hostname)
            port (int): Server port
            aet (str): Application Entity Title (local)
            aec (str): Called AE Title (remote)
            username (str): Username for authentication
            password (str): Password for authentication
        """
        self.name = name
        self.host = host
        self.port = port
        self.aet = aet
        self.aec = aec
        self.username = username
        self.password = password
    
    def to_dict(self):
        """
        Convert server configuration to dictionary.
        
        Returns:
            dict: Server configuration as dictionary
        """
        return {
            'name': self.name,
            'host': self.host,
            'port': self.port,
            'aet': self.aet,
            'aec': self.aec,
            'username': self.username,
            'password': self.password
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        Create server configuration from dictionary.
        
        Args:
            data (dict): Server configuration as dictionary
            
        Returns:
            PACSServer: Created server configuration
        """
        return cls(
            name=data.get('name', ''),
            host=data.get('host', ''),
            port=data.get('port', 104),
            aet=data.get('aet', 'PYNETDICOM'),
            aec=data.get('aec', 'ANY-SCP'),
            username=data.get('username', ''),
            password=data.get('password', '')
        )


class PACSServerManager:
    """
    Class for managing PACS server configurations.
    """
    
    def __init__(self, config_file=None):
        """
        Initialize the PACSServerManager.
        
        Args:
            config_file (str, optional): Path to configuration file
        """
        self.servers = {}
        self.config_file = config_file or os.path.expanduser("~/.pet_ct_viewer/pacs_servers.json")
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
        
        # Load servers
        self.load_servers()
    
    def add_server(self, server):
        """
        Add a server configuration.
        
        Args:
            server (PACSServer): Server configuration
            
        Returns:
            bool: True if server was added, False otherwise
        """
        if not server.name:
            logger.error("Server name cannot be empty")
            return False
        
        self.servers[server.name] = server
        self.save_servers()
        return True
    
    def update_server(self, server_name, server):
        """
        Update a server configuration.
        
        Args:
            server_name (str): Server name
            server (PACSServer): Server configuration
            
        Returns:
            bool: True if server was updated, False otherwise
        """
        if server_name not in self.servers:
            logger.error(f"Server '{server_name}' not found")
            return False
        
        # Update server
        self.servers[server_name] = server
        self.save_servers()
        return True
    
    def remove_server(self, server_name):
        """
        Remove a server configuration.
        
        Args:
            server_name (str): Server name
            
        Returns:
            bool: True if server was removed, False otherwise
        """
        if server_name not in self.servers:
            logger.error(f"Server '{server_name}' not found")
            return False
        
        # Remove server
        del self.servers[server_name]
        self.save_servers()
        return True
    
    def get_server(self, server_name):
        """
        Get a server configuration.
        
        Args:
            server_name (str): Server name
            
        Returns:
            PACSServer: Server configuration, or None if not found
        """
        return self.servers.get(server_name)
    
    def get_servers(self):
        """
        Get all server configurations.
        
        Returns:
            dict: Server configurations
        """
        return self.servers
    
    def load_servers(self):
        """
        Load server configurations from file.
        
        Returns:
            bool: True if servers were loaded, False otherwise
        """
        try:
            if os.path.isfile(self.config_file):
                with open(self.config_file, 'r') as f:
                    data = json.load(f)
                
                # Load servers
                self.servers = {}
                for server_name, server_data in data.items():
                    self.servers[server_name] = PACSServer.from_dict(server_data)
                
                return True
        except Exception as e:
            logger.error(f"Error loading servers: {str(e)}")
        
        return False
    
    def save_servers(self):
        """
        Save server configurations to file.
        
        Returns:
            bool: True if servers were saved, False otherwise
        """
        try:
            # Convert servers to dictionary
            data = {}
            for server_name, server in self.servers.items():
                data[server_name] = server.to_dict()
            
            # Save to file
            with open(self.config_file, 'w') as f:
                json.dump(data, f, indent=4)
            
            return True
        except Exception as e:
            logger.error(f"Error saving servers: {str(e)}")
        
        return False


class PACSQueryResult:
    """
    Class representing a PACS query result.
    """
    
    def __init__(self, dataset=None):
        """
        Initialize the PACSQueryResult.
        
        Args:
            dataset (pydicom.dataset.Dataset, optional): DICOM dataset
        """
        self.dataset = dataset or {}
        self.children = []
    
    def add_child(self, child):
        """
        Add a child result.
        
        Args:
            child (PACSQueryResult): Child result
        """
        self.children.append(child)
    
    def get_value(self, tag, default=""):
        """
        Get a value from the dataset.
        
        Args:
            tag (str): DICOM tag
            default (str, optional): Default value
            
        Returns:
            str: Value
        """
        if hasattr(self.dataset, tag):
            value = getattr(self.dataset, tag)
            if value:
                return str(value)
        return default
    
    def to_dict(self):
        """
        Convert result to dictionary.
        
        Returns:
            dict: Result as dictionary
        """
        # Convert dataset to dictionary
        result = {}
        
        # Add common fields
        for field in ['PatientID', 'PatientName', 'PatientBirthDate', 'PatientSex',
                     'StudyInstanceUID', 'StudyID', 'StudyDate', 'StudyTime', 'StudyDescription',
                     'SeriesInstanceUID', 'SeriesNumber', 'SeriesDate', 'SeriesTime', 'SeriesDescription',
                     'Modality', 'SOPInstanceUID', 'InstanceNumber']:
            if hasattr(self.dataset, field):
                result[field] = str(getattr(self.dataset, field))
        
        # Add children
        if self.children:
            result['children'] = [child.to_dict() for child in self.children]
        
        return result


class PACSConnector:
    """
    Class for connecting to PACS servers.
    """
    
    def __init__(self):
        """Initialize the PACSConnector."""
        # Check if pynetdicom is available
        if not HAVE_PYNETDICOM:
            logger.error("pynetdicom is required for PACS connectivity")
            return
        
        # Initialize variables
        self.ae = None
        self.assoc = None
        self.server = None
        self.status_callback = None
        self.progress_callback = None
        self.cancel_event = threading.Event()
    
    def set_status_callback(self, callback):
        """
        Set status callback function.
        
        Args:
            callback (callable): Callback function
        """
        self.status_callback = callback
    
    def set_progress_callback(self, callback):
        """
        Set progress callback function.
        
        Args:
            callback (callable): Callback function
        """
        self.progress_callback = callback
    
    def _update_status(self, status):
        """
        Update status.
        
        Args:
            status (str): Status message
        """
        if self.status_callback:
            self.status_callback(status)
        else:
            logger.info(status)
    
    def _update_progress(self, current, total):
        """
        Update progress.
        
        Args:
            current (int): Current progress
            total (int): Total progress
        """
        if self.progress_callback:
            self.progress_callback(current, total)
    
    def connect(self, server):
        """
        Connect to a PACS server.
        
        Args:
            server (PACSServer): Server configuration
            
        Returns:
            bool: True if connection was successful, False otherwise
        """
        if not HAVE_PYNETDICOM:
            self._update_status("pynetdicom is required for PACS connectivity")
            return False
        
        try:
            # Store server
            self.server = server
            
            # Create application entity
            self.ae = AE(ae_title=server.aet)
            
            # Add presentation contexts
            self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelFind)
            self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelGet)
            self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelMove)
            self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelFind)
            self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelGet)
            self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelMove)
            self.ae.add_requested_context(ModalityWorklistInformationFind)
            
            # Add storage presentation contexts
            for context in AllStoragePresentationContexts:
                self.ae.add_requested_context(context.abstract_syntax)
            
            # Connect to server
            self._update_status(f"Connecting to {server.host}:{server.port}...")
            self.assoc = self.ae.associate(server.host, server.port, ae_title=server.aec)
            
            if self.assoc.is_established:
                self._update_status(f"Connected to {server.host}:{server.port}")
                return True
            else:
                self._update_status(f"Failed to connect to {server.host}:{server.port}")
                return False
        except Exception as e:
            self._update_status(f"Error connecting to {server.host}:{server.port}: {str(e)}")
            return False
    
    def disconnect(self):
        """
        Disconnect from the PACS server.
        
        Returns:
            bool: True if disconnection was successful, False otherwise
        """
        if not self.assoc:
            return True
        
        try:
            # Release association
            self.assoc.release()
            self._update_status("Disconnected from PACS server")
            return True
        except Exception as e:
            self._update_status(f"Error disconnecting from PACS server: {str(e)}")
            return False
        finally:
            self.assoc = None
    
    def echo(self):
        """
        Send C-ECHO request to the PACS server.
        
        Returns:
            bool: True if echo was successful, False otherwise
        """
        if not self.assoc or not self.assoc.is_established:
            self._update_status("Not connected to PACS server")
            return False
        
        try:
            # Send C-ECHO
            self._update_status("Sending C-ECHO...")
            status = self.assoc.send_c_echo()
            
            if status:
                self._update_status("C-ECHO successful")
                return True
            else:
                self._update_status("C-ECHO failed")
                return False
        except Exception as e:
            self._update_status(f"Error sending C-ECHO: {str(e)}")
            return False
    
    def find_patients(self, query=None):
        """
        Find patients on the PACS server.
        
        Args:
            query (dict, optional): Query parameters
            
        Returns:
            list: List of patient results
        """
        if not self.assoc or not self.assoc.is_established:
            self._update_status("Not connected to PACS server")
            return []
        
        try:
            # Create dataset
            ds = pydicom.dataset.Dataset()
            ds.QueryRetrieveLevel = 'PATIENT'
            
            # Add query parameters
            if query:
                for key, value in query.items():
                    setattr(ds, key, value)
            
            # Add default query parameters
            if not hasattr(ds, 'PatientID'):
                ds.PatientID = ''
            if not hasattr(ds, 'PatientName'):
                ds.PatientName = ''
            
            # Send C-FIND
            self._update_status("Searching for patients...")
            responses = self.assoc.send_c_find(ds, PatientRootQueryRetrieveInformationModelFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status:
                    if status.Status == 0xFF00:  # Pending
                        if dataset:
                            results.append(PACSQueryResult(dataset))
                    elif status.Status == 0x0000:  # Success
                        pass
                    else:
                        self._update_status(f"C-FIND failed: {status}")
            
            self._update_status(f"Found {len(results)} patients")
            return results
        except Exception as e:
            self._update_status(f"Error finding patients: {str(e)}")
            return []
    
    def find_studies(self, patient_id=None, query=None):
        """
        Find studies on the PACS server.
        
        Args:
            patient_id (str, optional): Patient ID
            query (dict, optional): Query parameters
            
        Returns:
            list: List of study results
        """
        if not self.assoc or not self.assoc.is_established:
            self._update_status("Not connected to PACS server")
            return []
        
        try:
            # Create dataset
            ds = pydicom.dataset.Dataset()
            ds.QueryRetrieveLevel = 'STUDY'
            
            # Add patient ID
            if patient_id:
                ds.PatientID = patient_id
            
            # Add query parameters
            if query:
                for key, value in query.items():
                    setattr(ds, key, value)
            
            # Add default query parameters
            if not hasattr(ds, 'StudyInstanceUID'):
                ds.StudyInstanceUID = ''
            if not hasattr(ds, 'StudyDate'):
                ds.StudyDate = ''
            if not hasattr(ds, 'PatientName'):
                ds.PatientName = ''
            
            # Send C-FIND
            self._update_status("Searching for studies...")
            responses = self.assoc.send_c_find(ds, PatientRootQueryRetrieveInformationModelFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status:
                    if status.Status == 0xFF00:  # Pending
                        if dataset:
                            results.append(PACSQueryResult(dataset))
                    elif status.Status == 0x0000:  # Success
                        pass
                    else:
                        self._update_status(f"C-FIND failed: {status}")
            
            self._update_status(f"Found {len(results)} studies")
            return results
        except Exception as e:
            self._update_status(f"Error finding studies: {str(e)}")
            return []
    
    def find_series(self, study_instance_uid=None, query=None):
        """
        Find series on the PACS server.
        
        Args:
            study_instance_uid (str, optional): Study Instance UID
            query (dict, optional): Query parameters
            
        Returns:
            list: List of series results
        """
        if not self.assoc or not self.assoc.is_established:
            self._update_status("Not connected to PACS server")
            return []
        
        try:
            # Create dataset
            ds = pydicom.dataset.Dataset()
            ds.QueryRetrieveLevel = 'SERIES'
            
            # Add study instance UID
            if study_instance_uid:
                ds.StudyInstanceUID = study_instance_uid
            
            # Add query parameters
            if query:
                for key, value in query.items():
                    setattr(ds, key, value)
            
            # Add default query parameters
            if not hasattr(ds, 'SeriesInstanceUID'):
                ds.SeriesInstanceUID = ''
            if not hasattr(ds, 'SeriesNumber'):
                ds.SeriesNumber = ''
            if not hasattr(ds, 'Modality'):
                ds.Modality = ''
            
            # Send C-FIND
            self._update_status("Searching for series...")
            responses = self.assoc.send_c_find(ds, PatientRootQueryRetrieveInformationModelFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status:
                    if status.Status == 0xFF00:  # Pending
                        if dataset:
                            results.append(PACSQueryResult(dataset))
                    elif status.Status == 0x0000:  # Success
                        pass
                    else:
                        self._update_status(f"C-FIND failed: {status}")
            
            self._update_status(f"Found {len(results)} series")
            return results
        except Exception as e:
            self._update_status(f"Error finding series: {str(e)}")
            return []
    
    def find_instances(self, series_instance_uid=None, query=None):
        """
        Find instances on the PACS server.
        
        Args:
            series_instance_uid (str, optional): Series Instance UID
            query (dict, optional): Query parameters
            
        Returns:
            list: List of instance results
        """
        if not self.assoc or not self.assoc.is_established:
            self._update_status("Not connected to PACS server")
            return []
        
        try:
            # Create dataset
            ds = pydicom.dataset.Dataset()
            ds.QueryRetrieveLevel = 'IMAGE'
            
            # Add series instance UID
            if series_instance_uid:
                ds.SeriesInstanceUID = series_instance_uid
            
            # Add query parameters
            if query:
                for key, value in query.items():
                    setattr(ds, key, value)
            
            # Add default query parameters
            if not hasattr(ds, 'SOPInstanceUID'):
                ds.SOPInstanceUID = ''
            if not hasattr(ds, 'InstanceNumber'):
                ds.InstanceNumber = ''
            
            # Send C-FIND
            self._update_status("Searching for instances...")
            responses = self.assoc.send_c_find(ds, PatientRootQueryRetrieveInformationModelFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status:
                    if status.Status == 0xFF00:  # Pending
                        if dataset:
                            results.append(PACSQueryResult(dataset))
                    elif status.Status == 0x0000:  # Success
                        pass
                    else:
                        self._update_status(f"C-FIND failed: {status}")
            
            self._update_status(f"Found {len(results)} instances")
            return results
        except Exception as e:
            self._update_status(f"Error finding instances: {str(e)}")
            return []
    
    def retrieve_series(self, series_instance_uid, output_dir):
        """
        Retrieve a series from the PACS server.
        
        Args:
            series_instance_uid (str): Series Instance UID
            output_dir (str): Output directory
            
        Returns:
            bool: True if retrieval was successful, False otherwise
        """
        if not self.assoc or not self.assoc.is_established:
            self._update_status("Not connected to PACS server")
            return False
        
        try:
            # Create output directory
            os.makedirs(output_dir, exist_ok=True)
            
            # Create dataset
            ds = pydicom.dataset.Dataset()
            ds.QueryRetrieveLevel = 'SERIES'
            ds.SeriesInstanceUID = series_instance_uid
            
            # Find instances
            instances = self.find_instances(series_instance_uid)
            if not instances:
                self._update_status(f"No instances found for series {series_instance_uid}")
                return False
            
            # Reset cancel event
            self.cancel_event.clear()
            
            # Create storage SCP
            scp = self._create_storage_scp(output_dir)
            
            # Start SCP
            scp.start()
            
            # Wait for SCP to start
            time.sleep(1)
            
            # Send C-MOVE
            self._update_status(f"Retrieving series {series_instance_uid}...")
            responses = self.assoc.send_c_move(ds, self.server.aet, PatientRootQueryRetrieveInformationModelMove)
            
            # Process responses
            success = False
            for (status, dataset) in responses:
                if status:
                    if status.Status == 0xFF00:  # Pending
                        remaining = status.NumberOfRemainingSuboperations
                        completed = status.NumberOfCompletedSuboperations
                        failed = status.NumberOfFailedSuboperations
                        warning = status.NumberOfWarningSuboperations
                        total = remaining + completed + failed + warning
                        
                        if total > 0:
                            progress = (completed + failed + warning) / total * 100
                            self._update_progress(int(progress), 100)
                        
                        self._update_status(f"Retrieving series: {completed}/{total} instances")
                    elif status.Status == 0x0000:  # Success
                        success = True
                        self._update_status("Series retrieval completed successfully")
                    else:
                        self._update_status(f"C-MOVE failed: {status}")
            
            # Stop SCP
            scp.shutdown()
            
            return success
        except Exception as e:
            self._update_status(f"Error retrieving series: {str(e)}")
            return False
    
    def retrieve_study(self, study_instance_uid, output_dir):
        """
        Retrieve a study from the PACS server.
        
        Args:
            study_instance_uid (str): Study Instance UID
            output_dir (str): Output directory
            
        Returns:
            bool: True if retrieval was successful, False otherwise
        """
        if not self.assoc or not self.assoc.is_established:
            self._update_status("Not connected to PACS server")
            return False
        
        try:
            # Create output directory
            os.makedirs(output_dir, exist_ok=True)
            
            # Create dataset
            ds = pydicom.dataset.Dataset()
            ds.QueryRetrieveLevel = 'STUDY'
            ds.StudyInstanceUID = study_instance_uid
            
            # Find series
            series_list = self.find_series(study_instance_uid)
            if not series_list:
                self._update_status(f"No series found for study {study_instance_uid}")
                return False
            
            # Reset cancel event
            self.cancel_event.clear()
            
            # Create storage SCP
            scp = self._create_storage_scp(output_dir)
            
            # Start SCP
            scp.start()
            
            # Wait for SCP to start
            time.sleep(1)
            
            # Send C-MOVE
            self._update_status(f"Retrieving study {study_instance_uid}...")
            responses = self.assoc.send_c_move(ds, self.server.aet, PatientRootQueryRetrieveInformationModelMove)
            
            # Process responses
            success = False
            for (status, dataset) in responses:
                if status:
                    if status.Status == 0xFF00:  # Pending
                        remaining = status.NumberOfRemainingSuboperations
                        completed = status.NumberOfCompletedSuboperations
                        failed = status.NumberOfFailedSuboperations
                        warning = status.NumberOfWarningSuboperations
                        total = remaining + completed + failed + warning
                        
                        if total > 0:
                            progress = (completed + failed + warning) / total * 100
                            self._update_progress(int(progress), 100)
                        
                        self._update_status(f"Retrieving study: {completed}/{total} instances")
                    elif status.Status == 0x0000:  # Success
                        success = True
                        self._update_status("Study retrieval completed successfully")
                    else:
                        self._update_status(f"C-MOVE failed: {status}")
            
            # Stop SCP
            scp.shutdown()
            
            return success
        except Exception as e:
            self._update_status(f"Error retrieving study: {str(e)}")
            return False
    
    def cancel_retrieval(self):
        """
        Cancel the current retrieval operation.
        
        Returns:
            bool: True if cancellation was successful, False otherwise
        """
        self.cancel_event.set()
        self._update_status("Retrieval cancelled")
        return True
    
    def _create_storage_scp(self, output_dir):
        """
        Create a storage SCP for receiving DICOM files.
        
        Args:
            output_dir (str): Output directory
            
        Returns:
            pynetdicom.ae.ApplicationEntity: Storage SCP
        """
        # Create application entity
        scp = AE(ae_title=self.server.aet)
        
        # Add storage presentation contexts
        for context in StoragePresentationContexts:
            scp.add_supported_context(context.abstract_syntax)
        
        # Define handler for C-STORE
        def handle_store(event):
            """Handle C-STORE request."""
            try:
                # Get dataset
                dataset = event.dataset
                
                # Add file meta information
                dataset.file_meta = event.file_meta
                
                # Get SOP instance UID
                sop_instance_uid = dataset.SOPInstanceUID
                
                # Create filename
                filename = os.path.join(output_dir, f"{sop_instance_uid}.dcm")
                
                # Save dataset
                dataset.save_as(filename, write_like_original=False)
                
                return 0x0000  # Success
            except Exception as e:
                logger.error(f"Error handling C-STORE: {str(e)}")
                return 0xC000  # Failed
        
        # Add handler for C-STORE
        scp.add_handler(evt.EVT_C_STORE, handle_store)
        
        # Start SCP
        scp.start_server(('', 0), block=False)
        
        return scp


class PACSServerDialog(QtWidgets.QDialog):
    """
    Dialog for configuring PACS servers.
    """
    
    def __init__(self, server=None, parent=None):
        """
        Initialize the PACSServerDialog.
        
        Args:
            server (PACSServer, optional): Server configuration
            parent (QWidget, optional): Parent widget
        """
        super(PACSServerDialog, self).__init__(parent)
        
        # Set window properties
        self.setWindowTitle("PACS Server Configuration")
        self.setMinimumSize(400, 300)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create form layout
        form_layout = QtWidgets.QFormLayout()
        
        # Create name input
        self.name_input = QtWidgets.QLineEdit()
        form_layout.addRow("Name:", self.name_input)
        
        # Create host input
        self.host_input = QtWidgets.QLineEdit()
        form_layout.addRow("Host:", self.host_input)
        
        # Create port input
        self.port_input = QtWidgets.QSpinBox()
        self.port_input.setRange(1, 65535)
        self.port_input.setValue(104)
        form_layout.addRow("Port:", self.port_input)
        
        # Create AET input
        self.aet_input = QtWidgets.QLineEdit()
        self.aet_input.setText("PYNETDICOM")
        form_layout.addRow("AE Title (local):", self.aet_input)
        
        # Create AEC input
        self.aec_input = QtWidgets.QLineEdit()
        self.aec_input.setText("ANY-SCP")
        form_layout.addRow("Called AE Title (remote):", self.aec_input)
        
        # Create username input
        self.username_input = QtWidgets.QLineEdit()
        form_layout.addRow("Username:", self.username_input)
        
        # Create password input
        self.password_input = QtWidgets.QLineEdit()
        self.password_input.setEchoMode(QtWidgets.QLineEdit.Password)
        form_layout.addRow("Password:", self.password_input)
        
        # Add form layout to main layout
        layout.addLayout(form_layout)
        
        # Create test button
        self.test_button = QtWidgets.QPushButton("Test Connection")
        self.test_button.clicked.connect(self._on_test_clicked)
        layout.addWidget(self.test_button)
        
        # Create buttons
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()
        
        self.cancel_button = QtWidgets.QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_button)
        
        self.ok_button = QtWidgets.QPushButton("OK")
        self.ok_button.clicked.connect(self.accept)
        self.ok_button.setDefault(True)
        button_layout.addWidget(self.ok_button)
        
        layout.addLayout(button_layout)
        
        # Set server
        if server:
            self.set_server(server)
    
    def set_server(self, server):
        """
        Set server configuration.
        
        Args:
            server (PACSServer): Server configuration
        """
        self.name_input.setText(server.name)
        self.host_input.setText(server.host)
        self.port_input.setValue(server.port)
        self.aet_input.setText(server.aet)
        self.aec_input.setText(server.aec)
        self.username_input.setText(server.username)
        self.password_input.setText(server.password)
    
    def get_server(self):
        """
        Get server configuration.
        
        Returns:
            PACSServer: Server configuration
        """
        return PACSServer(
            name=self.name_input.text(),
            host=self.host_input.text(),
            port=self.port_input.value(),
            aet=self.aet_input.text(),
            aec=self.aec_input.text(),
            username=self.username_input.text(),
            password=self.password_input.text()
        )
    
    def _on_test_clicked(self):
        """Handle test button click."""
        # Get server
        server = self.get_server()
        
        # Check if host is empty
        if not server.host:
            QtWidgets.QMessageBox.warning(
                self,
                "Test Connection",
                "Host cannot be empty."
            )
            return
        
        # Create connector
        connector = PACSConnector()
        
        # Connect to server
        if connector.connect(server):
            # Send C-ECHO
            if connector.echo():
                QtWidgets.QMessageBox.information(
                    self,
                    "Test Connection",
                    "Connection successful."
                )
            else:
                QtWidgets.QMessageBox.warning(
                    self,
                    "Test Connection",
                    "Connection established, but C-ECHO failed."
                )
            
            # Disconnect
            connector.disconnect()
        else:
            QtWidgets.QMessageBox.critical(
                self,
                "Test Connection",
                "Connection failed."
            )


class PACSServerListDialog(QtWidgets.QDialog):
    """
    Dialog for managing PACS server configurations.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the PACSServerListDialog.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(PACSServerListDialog, self).__init__(parent)
        
        # Set window properties
        self.setWindowTitle("PACS Servers")
        self.setMinimumSize(500, 300)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create server list
        self.server_list = QtWidgets.QListWidget()
        self.server_list.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.server_list.itemSelectionChanged.connect(self._on_selection_changed)
        layout.addWidget(self.server_list, 1)
        
        # Create buttons
        button_layout = QtWidgets.QHBoxLayout()
        
        self.add_button = QtWidgets.QPushButton("Add")
        self.add_button.clicked.connect(self._on_add_clicked)
        button_layout.addWidget(self.add_button)
        
        self.edit_button = QtWidgets.QPushButton("Edit")
        self.edit_button.clicked.connect(self._on_edit_clicked)
        self.edit_button.setEnabled(False)
        button_layout.addWidget(self.edit_button)
        
        self.remove_button = QtWidgets.QPushButton("Remove")
        self.remove_button.clicked.connect(self._on_remove_clicked)
        self.remove_button.setEnabled(False)
        button_layout.addWidget(self.remove_button)
        
        button_layout.addStretch()
        
        self.close_button = QtWidgets.QPushButton("Close")
        self.close_button.clicked.connect(self.accept)
        button_layout.addWidget(self.close_button)
        
        layout.addLayout(button_layout)
        
        # Initialize server manager
        self.server_manager = PACSServerManager()
        
        # Load servers
        self._load_servers()
    
    def _load_servers(self):
        """Load server configurations."""
        # Clear list
        self.server_list.clear()
        
        # Add servers
        for server_name, server in self.server_manager.get_servers().items():
            item = QtWidgets.QListWidgetItem(server_name)
            item.setData(QtCore.Qt.UserRole, server)
            self.server_list.addItem(item)
    
    def _on_selection_changed(self):
        """Handle selection change."""
        # Enable/disable buttons
        selected = len(self.server_list.selectedItems()) > 0
        self.edit_button.setEnabled(selected)
        self.remove_button.setEnabled(selected)
    
    def _on_add_clicked(self):
        """Handle add button click."""
        # Show server dialog
        dialog = PACSServerDialog(parent=self)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            # Get server
            server = dialog.get_server()
            
            # Add server
            if self.server_manager.add_server(server):
                # Reload servers
                self._load_servers()
    
    def _on_edit_clicked(self):
        """Handle edit button click."""
        # Get selected item
        selected_items = self.server_list.selectedItems()
        if not selected_items:
            return
        
        # Get server
        server = selected_items[0].data(QtCore.Qt.UserRole)
        
        # Show server dialog
        dialog = PACSServerDialog(server, parent=self)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            # Get updated server
            updated_server = dialog.get_server()
            
            # Update server
            if self.server_manager.update_server(server.name, updated_server):
                # Reload servers
                self._load_servers()
    
    def _on_remove_clicked(self):
        """Handle remove button click."""
        # Get selected item
        selected_items = self.server_list.selectedItems()
        if not selected_items:
            return
        
        # Get server
        server = selected_items[0].data(QtCore.Qt.UserRole)
        
        # Confirm removal
        result = QtWidgets.QMessageBox.question(
            self,
            "Remove Server",
            f"Are you sure you want to remove the server '{server.name}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No
        )
        
        if result == QtWidgets.QMessageBox.Yes:
            # Remove server
            if self.server_manager.remove_server(server.name):
                # Reload servers
                self._load_servers()


class PACSQueryDialog(QtWidgets.QDialog):
    """
    Dialog for querying PACS servers.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the PACSQueryDialog.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(PACSQueryDialog, self).__init__(parent)
        
        # Set window properties
        self.setWindowTitle("PACS Query")
        self.setMinimumSize(800, 600)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create server selection
        server_layout = QtWidgets.QHBoxLayout()
        server_layout.addWidget(QtWidgets.QLabel("Server:"))
        
        self.server_combo = QtWidgets.QComboBox()
        server_layout.addWidget(self.server_combo, 1)
        
        self.connect_button = QtWidgets.QPushButton("Connect")
        self.connect_button.clicked.connect(self._on_connect_clicked)
        server_layout.addWidget(self.connect_button)
        
        self.disconnect_button = QtWidgets.QPushButton("Disconnect")
        self.disconnect_button.clicked.connect(self._on_disconnect_clicked)
        self.disconnect_button.setEnabled(False)
        server_layout.addWidget(self.disconnect_button)
        
        layout.addLayout(server_layout)
        
        # Create query form
        form_layout = QtWidgets.QFormLayout()
        
        self.patient_id_input = QtWidgets.QLineEdit()
        form_layout.addRow("Patient ID:", self.patient_id_input)
        
        self.patient_name_input = QtWidgets.QLineEdit()
        form_layout.addRow("Patient Name:", self.patient_name_input)
        
        self.study_date_from_input = QtWidgets.QDateEdit(QtCore.QDate.currentDate().addDays(-30))
        self.study_date_from_input.setCalendarPopup(True)
        form_layout.addRow("Study Date From:", self.study_date_from_input)
        
        self.study_date_to_input = QtWidgets.QDateEdit(QtCore.QDate.currentDate())
        self.study_date_to_input.setCalendarPopup(True)
        form_layout.addRow("Study Date To:", self.study_date_to_input)
        
        self.modality_input = QtWidgets.QLineEdit()
        form_layout.addRow("Modality:", self.modality_input)
        
        layout.addLayout(form_layout)
        
        # Create query button
        self.query_button = QtWidgets.QPushButton("Query")
        self.query_button.clicked.connect(self._on_query_clicked)
        self.query_button.setEnabled(False)
        layout.addWidget(self.query_button)
        
        # Create results tree
        self.results_tree = QtWidgets.QTreeWidget()
        self.results_tree.setHeaderLabels(["Name", "ID", "Date", "Description", "Modality"])
        self.results_tree.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.results_tree.itemSelectionChanged.connect(self._on_selection_changed)
        layout.addWidget(self.results_tree, 1)
        
        # Create status label
        self.status_label = QtWidgets.QLabel("Not connected")
        layout.addWidget(self.status_label)
        
        # Create progress bar
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Create buttons
        button_layout = QtWidgets.QHBoxLayout()
        
        self.retrieve_button = QtWidgets.QPushButton("Retrieve")
        self.retrieve_button.clicked.connect(self._on_retrieve_clicked)
        self.retrieve_button.setEnabled(False)
        button_layout.addWidget(self.retrieve_button)
        
        self.cancel_button = QtWidgets.QPushButton("Cancel")
        self.cancel_button.clicked.connect(self._on_cancel_clicked)
        self.cancel_button.setEnabled(False)
        button_layout.addWidget(self.cancel_button)
        
        button_layout.addStretch()
        
        self.close_button = QtWidgets.QPushButton("Close")
        self.close_button.clicked.connect(self.reject)
        button_layout.addWidget(self.close_button)
        
        layout.addLayout(button_layout)
        
        # Initialize variables
        self.server_manager = PACSServerManager()
        self.connector = PACSConnector()
        self.connector.set_status_callback(self._update_status)
        self.connector.set_progress_callback(self._update_progress)
        self.current_server = None
        self.retrieved_series = []
        
        # Load servers
        self._load_servers()
    
    def _load_servers(self):
        """Load server configurations."""
        # Clear combo
        self.server_combo.clear()
        
        # Add servers
        for server_name in self.server_manager.get_servers().keys():
            self.server_combo.addItem(server_name)
    
    def _update_status(self, status):
        """
        Update status label.
        
        Args:
            status (str): Status message
        """
        self.status_label.setText(status)
        QtWidgets.QApplication.processEvents()
    
    def _update_progress(self, current, total):
        """
        Update progress bar.
        
        Args:
            current (int): Current progress
            total (int): Total progress
        """
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(current)
        QtWidgets.QApplication.processEvents()
    
    def _on_connect_clicked(self):
        """Handle connect button click."""
        # Get selected server
        server_name = self.server_combo.currentText()
        if not server_name:
            return
        
        # Get server
        server = self.server_manager.get_server(server_name)
        if not server:
            return
        
        # Connect to server
        if self.connector.connect(server):
            # Update UI
            self.current_server = server
            self.connect_button.setEnabled(False)
            self.disconnect_button.setEnabled(True)
            self.query_button.setEnabled(True)
        else:
            # Show error
            QtWidgets.QMessageBox.critical(
                self,
                "Connection Error",
                "Failed to connect to PACS server."
            )
    
    def _on_disconnect_clicked(self):
        """Handle disconnect button click."""
        # Disconnect from server
        if self.connector.disconnect():
            # Update UI
            self.current_server = None
            self.connect_button.setEnabled(True)
            self.disconnect_button.setEnabled(False)
            self.query_button.setEnabled(False)
            self.retrieve_button.setEnabled(False)
            self.cancel_button.setEnabled(False)
            self.progress_bar.setVisible(False)
            self._update_status("Not connected")
    
    def _on_query_clicked(self):
        """Handle query button click."""
        # Clear results
        self.results_tree.clear()
        
        # Get query parameters
        patient_id = self.patient_id_input.text()
        patient_name = self.patient_name_input.text()
        study_date_from = self.study_date_from_input.date().toString("yyyyMMdd")
        study_date_to = self.study_date_to_input.date().toString("yyyyMMdd")
        modality = self.modality_input.text()
        
        # Create query
        query = {}
        if patient_id:
            query['PatientID'] = patient_id
        if patient_name:
            query['PatientName'] = patient_name
        if study_date_from and study_date_to:
            query['StudyDate'] = f"{study_date_from}-{study_date_to}"
        if modality:
            query['Modality'] = modality
        
        # Find studies
        studies = self.connector.find_studies(query=query)
        
        # Process studies
        for study in studies:
            # Create study item
            study_item = QtWidgets.QTreeWidgetItem()
            study_item.setText(0, study.get_value('PatientName'))
            study_item.setText(1, study.get_value('PatientID'))
            study_item.setText(2, study.get_value('StudyDate'))
            study_item.setText(3, study.get_value('StudyDescription'))
            study_item.setText(4, "")
            study_item.setData(0, QtCore.Qt.UserRole, study.to_dict())
            
            # Add to tree
            self.results_tree.addTopLevelItem(study_item)
            
            # Find series
            series_list = self.connector.find_series(study.get_value('StudyInstanceUID'))
            
            # Process series
            for series in series_list:
                # Create series item
                series_item = QtWidgets.QTreeWidgetItem()
                series_item.setText(0, "")
                series_item.setText(1, series.get_value('SeriesNumber'))
                series_item.setText(2, series.get_value('SeriesDate'))
                series_item.setText(3, series.get_value('SeriesDescription'))
                series_item.setText(4, series.get_value('Modality'))
                series_item.setData(0, QtCore.Qt.UserRole, series.to_dict())
                
                # Add to study item
                study_item.addChild(series_item)
            
            # Expand study item
            study_item.setExpanded(True)
    
    def _on_selection_changed(self):
        """Handle selection change."""
        # Get selected item
        selected_items = self.results_tree.selectedItems()
        if not selected_items:
            self.retrieve_button.setEnabled(False)
            return
        
        # Enable retrieve button
        self.retrieve_button.setEnabled(True)
    
    def _on_retrieve_clicked(self):
        """Handle retrieve button click."""
        # Get selected item
        selected_items = self.results_tree.selectedItems()
        if not selected_items:
            return
        
        # Get item data
        item_data = selected_items[0].data(0, QtCore.Qt.UserRole)
        
        # Check if item is a study or series
        if 'StudyInstanceUID' in item_data and 'SeriesInstanceUID' not in item_data:
            # Study
            study_instance_uid = item_data.get('StudyInstanceUID')
            
            # Get output directory
            output_dir = QtWidgets.QFileDialog.getExistingDirectory(
                self,
                "Select Output Directory",
                os.path.expanduser("~")
            )
            
            if not output_dir:
                return
            
            # Disable UI
            self.setEnabled(False)
            self.cancel_button.setEnabled(True)
            
            # Retrieve study
            success = self.connector.retrieve_study(study_instance_uid, output_dir)
            
            # Enable UI
            self.setEnabled(True)
            self.cancel_button.setEnabled(False)
            self.progress_bar.setVisible(False)
            
            if success:
                # Show success message
                QtWidgets.QMessageBox.information(
                    self,
                    "Retrieval Complete",
                    "Study retrieval completed successfully."
                )
                
                # Add to retrieved series
                self.retrieved_series.append({
                    'type': 'study',
                    'uid': study_instance_uid,
                    'path': output_dir
                })
        elif 'SeriesInstanceUID' in item_data:
            # Series
            series_instance_uid = item_data.get('SeriesInstanceUID')
            
            # Get output directory
            output_dir = QtWidgets.QFileDialog.getExistingDirectory(
                self,
                "Select Output Directory",
                os.path.expanduser("~")
            )
            
            if not output_dir:
                return
            
            # Disable UI
            self.setEnabled(False)
            self.cancel_button.setEnabled(True)
            
            # Retrieve series
            success = self.connector.retrieve_series(series_instance_uid, output_dir)
            
            # Enable UI
            self.setEnabled(True)
            self.cancel_button.setEnabled(False)
            self.progress_bar.setVisible(False)
            
            if success:
                # Show success message
                QtWidgets.QMessageBox.information(
                    self,
                    "Retrieval Complete",
                    "Series retrieval completed successfully."
                )
                
                # Add to retrieved series
                self.retrieved_series.append({
                    'type': 'series',
                    'uid': series_instance_uid,
                    'path': output_dir,
                    'modality': item_data.get('Modality', '')
                })
    
    def _on_cancel_clicked(self):
        """Handle cancel button click."""
        # Cancel retrieval
        self.connector.cancel_retrieval()
    
    def get_retrieved_series(self):
        """
        Get retrieved series.
        
        Returns:
            list: List of retrieved series
        """
        return self.retrieved_series


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("PACS Connector Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QVBoxLayout(central_widget)
    
    # Create buttons
    button_layout = QtWidgets.QHBoxLayout()
    
    server_list_button = QtWidgets.QPushButton("Server List")
    server_list_button.clicked.connect(lambda: PACSServerListDialog(window).exec_())
    button_layout.addWidget(server_list_button)
    
    query_button = QtWidgets.QPushButton("Query PACS")
    query_button.clicked.connect(lambda: PACSQueryDialog(window).exec_())
    button_layout.addWidget(query_button)
    
    layout.addLayout(button_layout)
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
