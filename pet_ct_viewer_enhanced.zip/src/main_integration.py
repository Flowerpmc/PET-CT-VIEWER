#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Main Integration Module for PET/CT Viewer
---------------------------------------
This module integrates all components and validates enhancements.
"""

import os
import sys
import logging
import time
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('MainIntegration')

# Import custom modules
try:
    from dicom_loader import DicomLoader
    from enhanced_dicom_loader import EnhancedDicomLoader
    from dicom_visualizer import DicomVisualizer
    from dicom_visualizer_enhanced import EnhancedDicomVisualizer
    from dicom_quantification import DicomQuantification
    from dicom_search import DicomSearch
    from dicom_validator import DicomValidator
    from pacs_connector_enhanced import PACSConnector, PACSServerListDialog, PACSQueryDialog
    from report_generator import ReportGenerator
    from texture_optimizer import TextureOptimizer
    from progress_indicator import ProgressIndicator
    from series_selector import SeriesSelectionDialog
    from fusion_handler import FusionHandler
    from orientation_handler import OrientationHandler
    from interaction_handler import InteractionHandler
    from color_map_handler import ColorMapHandler
    from tabbed_interface import TabbedInterface
    from layout_manager import LayoutManager
    from high_value_lut import HighValueLUT
    from search_tools_ui import TopMenuBar
    from quantification_tools import QuantificationToolsWidget
except ImportError as e:
    logger.error(f"Error importing modules: {str(e)}")
    # Continue with available modules


class MainWindow(QtWidgets.QMainWindow):
    """
    Main window for the PET/CT DICOM viewer.
    """
    
    def __init__(self):
        """Initialize the MainWindow."""
        super(MainWindow, self).__init__()
        
        # Set window properties
        self.setWindowTitle("PET/CT DICOM Viewer")
        self.setMinimumSize(1200, 800)
        
        # Create central widget
        self.central_widget = QtWidgets.QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Create main layout
        self.main_layout = QtWidgets.QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        
        # Create top menu bar
        self.top_menu_bar = TopMenuBar()
        self.main_layout.addWidget(self.top_menu_bar)
        
        # Create tabbed interface
        self.tabbed_interface = TabbedInterface()
        self.main_layout.addWidget(self.tabbed_interface, 1)
        
        # Create status bar
        self.statusBar().showMessage("Ready")
        
        # Create progress bar in status bar
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        self.progress_bar.setMaximumWidth(200)
        self.statusBar().addPermanentWidget(self.progress_bar)
        
        # Initialize components
        self._init_components()
        
        # Create menus
        self._create_menus()
        
        # Connect signals
        self._connect_signals()
    
    def _init_components(self):
        """Initialize components."""
        try:
            # Initialize DICOM loader
            self.dicom_loader = EnhancedDicomLoader()
            
            # Initialize texture optimizer
            self.texture_optimizer = TextureOptimizer()
            
            # Initialize progress indicator
            self.progress_indicator = ProgressIndicator()
            self.progress_indicator.set_progress_bar(self.progress_bar)
            
            # Initialize DICOM validator
            self.dicom_validator = DicomValidator()
            
            # Initialize layout manager
            self.layout_manager = LayoutManager()
            
            # Initialize high value LUT
            self.high_value_lut = HighValueLUT()
            
            # Initialize fusion handler
            self.fusion_handler = FusionHandler()
            
            # Initialize orientation handler
            self.orientation_handler = OrientationHandler()
            
            # Initialize color map handler
            self.color_map_handler = ColorMapHandler()
            
            # Initialize report generator
            self.report_generator = ReportGenerator()
            
            logger.info("Components initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing components: {str(e)}")
    
    def _create_menus(self):
        """Create menus."""
        # Create file menu
        file_menu = self.menuBar().addMenu("&File")
        
        # Add open action
        open_action = QtWidgets.QAction("&Open", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self._on_open)
        file_menu.addAction(open_action)
        
        # Add save action
        save_action = QtWidgets.QAction("&Save", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self._on_save)
        file_menu.addAction(save_action)
        
        # Add save as action
        save_as_action = QtWidgets.QAction("Save &As...", self)
        save_as_action.setShortcut("Ctrl+Shift+S")
        save_as_action.triggered.connect(self._on_save_as)
        file_menu.addAction(save_as_action)
        
        # Add separator
        file_menu.addSeparator()
        
        # Add exit action
        exit_action = QtWidgets.QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Create view menu
        view_menu = self.menuBar().addMenu("&View")
        
        # Add layout actions
        layout_menu = view_menu.addMenu("&Layout")
        
        layout_3x3_action = QtWidgets.QAction("3x3 Layout", self)
        layout_3x3_action.triggered.connect(lambda: self._on_layout_change("3x3"))
        layout_menu.addAction(layout_3x3_action)
        
        layout_2x2_action = QtWidgets.QAction("2x2 Layout", self)
        layout_2x2_action.triggered.connect(lambda: self._on_layout_change("2x2"))
        layout_menu.addAction(layout_2x2_action)
        
        layout_1x3_action = QtWidgets.QAction("1x3 Layout", self)
        layout_1x3_action.triggered.connect(lambda: self._on_layout_change("1x3"))
        layout_menu.addAction(layout_1x3_action)
        
        # Add orientation actions
        orientation_menu = view_menu.addMenu("&Orientation")
        
        axial_action = QtWidgets.QAction("Axial", self)
        axial_action.triggered.connect(lambda: self._on_orientation_change("axial"))
        orientation_menu.addAction(axial_action)
        
        coronal_action = QtWidgets.QAction("Coronal", self)
        coronal_action.triggered.connect(lambda: self._on_orientation_change("coronal"))
        orientation_menu.addAction(coronal_action)
        
        sagittal_action = QtWidgets.QAction("Sagittal", self)
        sagittal_action.triggered.connect(lambda: self._on_orientation_change("sagittal"))
        orientation_menu.addAction(sagittal_action)
        
        # Add window preset actions
        window_menu = view_menu.addMenu("&Window")
        
        soft_tissue_action = QtWidgets.QAction("Soft Tissue", self)
        soft_tissue_action.triggered.connect(lambda: self._on_window_preset("soft_tissue"))
        window_menu.addAction(soft_tissue_action)
        
        lung_action = QtWidgets.QAction("Lung", self)
        lung_action.triggered.connect(lambda: self._on_window_preset("lung"))
        window_menu.addAction(lung_action)
        
        bone_action = QtWidgets.QAction("Bone", self)
        bone_action.triggered.connect(lambda: self._on_window_preset("bone"))
        window_menu.addAction(bone_action)
        
        brain_action = QtWidgets.QAction("Brain", self)
        brain_action.triggered.connect(lambda: self._on_window_preset("brain"))
        window_menu.addAction(brain_action)
        
        # Create tools menu
        tools_menu = self.menuBar().addMenu("&Tools")
        
        # Add measurement actions
        measurement_menu = tools_menu.addMenu("&Measurement")
        
        distance_action = QtWidgets.QAction("Distance", self)
        distance_action.triggered.connect(lambda: self._on_tool_select("distance"))
        measurement_menu.addAction(distance_action)
        
        angle_action = QtWidgets.QAction("Angle", self)
        angle_action.triggered.connect(lambda: self._on_tool_select("angle"))
        measurement_menu.addAction(angle_action)
        
        roi_action = QtWidgets.QAction("ROI", self)
        roi_action.triggered.connect(lambda: self._on_tool_select("roi"))
        measurement_menu.addAction(roi_action)
        
        suv_action = QtWidgets.QAction("SUV", self)
        suv_action.triggered.connect(lambda: self._on_tool_select("suv"))
        measurement_menu.addAction(suv_action)
        
        volume_action = QtWidgets.QAction("Volume", self)
        volume_action.triggered.connect(lambda: self._on_tool_select("volume"))
        measurement_menu.addAction(volume_action)
        
        # Add annotation action
        annotation_action = QtWidgets.QAction("&Annotation", self)
        annotation_action.triggered.connect(self._on_annotation)
        tools_menu.addAction(annotation_action)
        
        # Add report action
        report_action = QtWidgets.QAction("&Report", self)
        report_action.triggered.connect(self._on_report)
        tools_menu.addAction(report_action)
        
        # Add patient info action
        patient_info_action = QtWidgets.QAction("&Patient Information", self)
        patient_info_action.triggered.connect(self._on_patient_info)
        tools_menu.addAction(patient_info_action)
        
        # Create PACS menu
        pacs_menu = self.menuBar().addMenu("&PACS")
        
        # Add server list action
        server_list_action = QtWidgets.QAction("Server &List", self)
        server_list_action.triggered.connect(self._on_server_list)
        pacs_menu.addAction(server_list_action)
        
        # Add query action
        query_action = QtWidgets.QAction("&Query", self)
        query_action.triggered.connect(self._on_query)
        pacs_menu.addAction(query_action)
        
        # Create help menu
        help_menu = self.menuBar().addMenu("&Help")
        
        # Add about action
        about_action = QtWidgets.QAction("&About", self)
        about_action.triggered.connect(self._on_about)
        help_menu.addAction(about_action)
    
    def _connect_signals(self):
        """Connect signals."""
        # Connect top menu bar signals
        self.top_menu_bar.toolbar.toolSelected.connect(self._on_toolbar_tool_selected)
        
        # Connect tabbed interface signals
        self.tabbed_interface.currentChanged.connect(self._on_tab_changed)
    
    def _on_open(self):
        """Handle open action."""
        try:
            # Show series selection dialog
            dialog = SeriesSelectionDialog(parent=self)
            if dialog.exec_() == QtWidgets.QDialog.Accepted:
                # Get assignments
                assignments = dialog.get_assignments()
                
                # Check if any series is assigned
                if not assignments or (not assignments.get("CT") and not assignments.get("PET")):
                    QtWidgets.QMessageBox.warning(
                        self,
                        "No Series Assigned",
                        "Please assign at least one series before loading."
                    )
                    return
                
                # Show progress
                self.progress_indicator.start("Loading series...")
                
                # Load series
                ct_series = assignments.get("CT")
                pet_series = assignments.get("PET")
                
                # Create new tab
                tab_name = "New Patient"
                if pet_series and pet_series.get('series_description'):
                    tab_name = pet_series.get('series_description')
                elif ct_series and ct_series.get('series_description'):
                    tab_name = ct_series.get('series_description')
                
                # Add tab
                self.tabbed_interface.add_tab(tab_name)
                
                # Update status
                self.statusBar().showMessage(f"Loaded series: {tab_name}")
                
                # Hide progress
                self.progress_indicator.stop()
        except Exception as e:
            logger.error(f"Error opening series: {str(e)}")
            self.statusBar().showMessage(f"Error opening series: {str(e)}")
            self.progress_indicator.stop()
    
    def _on_save(self):
        """Handle save action."""
        self.statusBar().showMessage("Save not implemented yet")
    
    def _on_save_as(self):
        """Handle save as action."""
        self.statusBar().showMessage("Save As not implemented yet")
    
    def _on_layout_change(self, layout):
        """
        Handle layout change.
        
        Args:
            layout (str): Layout name
        """
        self.statusBar().showMessage(f"Changed layout to {layout}")
    
    def _on_orientation_change(self, orientation):
        """
        Handle orientation change.
        
        Args:
            orientation (str): Orientation name
        """
        self.statusBar().showMessage(f"Changed orientation to {orientation}")
    
    def _on_window_preset(self, preset):
        """
        Handle window preset selection.
        
        Args:
            preset (str): Preset name
        """
        self.statusBar().showMessage(f"Applied window preset: {preset}")
    
    def _on_tool_select(self, tool):
        """
        Handle tool selection.
        
        Args:
            tool (str): Tool name
        """
        self.statusBar().showMessage(f"Selected tool: {tool}")
    
    def _on_annotation(self):
        """Handle annotation action."""
        self.statusBar().showMessage("Annotation tool activated")
    
    def _on_report(self):
        """Handle report action."""
        self.statusBar().showMessage("Generating report...")
        
        try:
            # Generate report
            report_path = self.report_generator.generate_report()
            
            # Show success message
            QtWidgets.QMessageBox.information(
                self,
                "Report Generated",
                f"Report generated successfully: {report_path}"
            )
            
            self.statusBar().showMessage(f"Report generated: {report_path}")
        except Exception as e:
            logger.error(f"Error generating report: {str(e)}")
            self.statusBar().showMessage(f"Error generating report: {str(e)}")
    
    def _on_patient_info(self):
        """Handle patient info action."""
        self.statusBar().showMessage("Showing patient information")
    
    def _on_server_list(self):
        """Handle server list action."""
        try:
            # Show server list dialog
            dialog = PACSServerListDialog(parent=self)
            dialog.exec_()
        except Exception as e:
            logger.error(f"Error showing server list: {str(e)}")
            self.statusBar().showMessage(f"Error showing server list: {str(e)}")
    
    def _on_query(self):
        """Handle query action."""
        try:
            # Show query dialog
            dialog = PACSQueryDialog(parent=self)
            if dialog.exec_() == QtWidgets.QDialog.Accepted:
                # Get retrieved series
                retrieved_series = dialog.get_retrieved_series()
                
                # Process retrieved series
                if retrieved_series:
                    self.statusBar().showMessage(f"Retrieved {len(retrieved_series)} series")
        except Exception as e:
            logger.error(f"Error querying PACS: {str(e)}")
            self.statusBar().showMessage(f"Error querying PACS: {str(e)}")
    
    def _on_about(self):
        """Handle about action."""
        QtWidgets.QMessageBox.about(
            self,
            "About PET/CT DICOM Viewer",
            "PET/CT DICOM Viewer\n\n"
            "A comprehensive viewer for PET/CT DICOM images with advanced visualization and analysis tools."
        )
    
    def _on_toolbar_tool_selected(self, group_id, tool_id):
        """
        Handle toolbar tool selection.
        
        Args:
            group_id (str): Tool group identifier
            tool_id (str): Tool identifier
        """
        self.statusBar().showMessage(f"Selected tool: {group_id}/{tool_id}")
    
    def _on_tab_changed(self, index):
        """
        Handle tab change.
        
        Args:
            index (int): Tab index
        """
        tab_name = self.tabbed_interface.tabText(index)
        self.statusBar().showMessage(f"Switched to tab: {tab_name}")


class ValidationTests:
    """
    Class for validating enhancements and optimizing performance.
    """
    
    def __init__(self):
        """Initialize the ValidationTests."""
        self.results = {}
    
    def run_all_tests(self):
        """
        Run all validation tests.
        
        Returns:
            dict: Test results
        """
        # Run tests
        self.test_opengl_texture_handling()
        self.test_progress_indicator()
        self.test_series_selection()
        self.test_fusion_display()
        self.test_orientation_handling()
        self.test_scrolling_behavior()
        self.test_color_map_handling()
        self.test_tabbed_interface()
        self.test_ui_adjustment()
        self.test_high_value_lut()
        self.test_search_bar()
        self.test_quantification_tools()
        self.test_pacs_connectivity()
        self.test_performance_optimization()
        
        return self.results
    
    def test_opengl_texture_handling(self):
        """Test OpenGL texture handling."""
        try:
            # Create texture optimizer
            optimizer = TextureOptimizer()
            
            # Test texture size limitation fix
            max_texture_size = optimizer.get_max_texture_size()
            result = optimizer.optimize_texture_size(4096, 4096)
            
            self.results['opengl_texture_handling'] = {
                'status': 'PASS' if result[0] <= max_texture_size and result[1] <= max_texture_size else 'FAIL',
                'max_texture_size': max_texture_size,
                'optimized_size': result
            }
        except Exception as e:
            self.results['opengl_texture_handling'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_progress_indicator(self):
        """Test progress indicator."""
        try:
            # Create progress indicator
            indicator = ProgressIndicator()
            
            # Test progress updates
            indicator.start("Testing progress...")
            for i in range(0, 101, 10):
                indicator.update(i, 100)
                time.sleep(0.01)
            indicator.stop()
            
            self.results['progress_indicator'] = {
                'status': 'PASS'
            }
        except Exception as e:
            self.results['progress_indicator'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_series_selection(self):
        """Test series selection."""
        try:
            # Create test series
            test_series = [
                {
                    'series_number': '1',
                    'series_description': 'CT Chest',
                    'modality': 'CT',
                    'series_date': '20250518',
                    'series_time': '102030',
                    'num_images': 120
                },
                {
                    'series_number': '2',
                    'series_description': 'PET Whole Body',
                    'modality': 'PT',
                    'series_date': '20250518',
                    'series_time': '102030',
                    'num_images': 80
                }
            ]
            
            # Test series filtering
            filtered_ct = [s for s in test_series if s['modality'] == 'CT']
            filtered_pet = [s for s in test_series if s['modality'] == 'PT']
            
            self.results['series_selection'] = {
                'status': 'PASS' if len(filtered_ct) == 1 and len(filtered_pet) == 1 else 'FAIL',
                'ct_series': len(filtered_ct),
                'pet_series': len(filtered_pet)
            }
        except Exception as e:
            self.results['series_selection'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_fusion_display(self):
        """Test fusion display."""
        try:
            # Create fusion handler
            fusion = FusionHandler()
            
            # Test dimension alignment
            ct_dims = (512, 512, 120)
            pet_dims = (128, 128, 80)
            aligned_dims = fusion.align_dimensions(ct_dims, pet_dims)
            
            self.results['fusion_display'] = {
                'status': 'PASS' if aligned_dims is not None else 'FAIL',
                'ct_dims': ct_dims,
                'pet_dims': pet_dims,
                'aligned_dims': aligned_dims
            }
        except Exception as e:
            self.results['fusion_display'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_orientation_handling(self):
        """Test orientation handling."""
        try:
            # Create orientation handler
            orientation = OrientationHandler()
            
            # Test orientation standardization
            original_orientation = 'AXIAL'
            standardized = orientation.standardize_orientation(original_orientation)
            
            self.results['orientation_handling'] = {
                'status': 'PASS' if standardized is not None else 'FAIL',
                'original_orientation': original_orientation,
                'standardized_orientation': standardized
            }
        except Exception as e:
            self.results['orientation_handling'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_scrolling_behavior(self):
        """Test scrolling behavior."""
        try:
            # Create interaction handler
            interaction = InteractionHandler()
            
            # Test scroll handling
            scroll_result = interaction.handle_scroll(1)
            
            self.results['scrolling_behavior'] = {
                'status': 'PASS' if scroll_result is not None else 'FAIL',
                'scroll_direction': 1,
                'scroll_result': scroll_result
            }
        except Exception as e:
            self.results['scrolling_behavior'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_color_map_handling(self):
        """Test color map handling."""
        try:
            # Create color map handler
            color_map = ColorMapHandler()
            
            # Test color map creation
            test_map = color_map.create_color_map('hot', 256)
            
            self.results['color_map_handling'] = {
                'status': 'PASS' if test_map is not None and len(test_map) == 256 else 'FAIL',
                'color_map_name': 'hot',
                'color_map_size': len(test_map) if test_map is not None else 0
            }
        except Exception as e:
            self.results['color_map_handling'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_tabbed_interface(self):
        """Test tabbed interface."""
        try:
            # Create tabbed interface
            tabbed = TabbedInterface()
            
            # Test tab creation
            tab_index = tabbed.add_tab("Test Tab")
            
            self.results['tabbed_interface'] = {
                'status': 'PASS' if tab_index >= 0 else 'FAIL',
                'tab_index': tab_index
            }
        except Exception as e:
            self.results['tabbed_interface'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_ui_adjustment(self):
        """Test UI adjustment."""
        try:
            # Create layout manager
            layout = LayoutManager()
            
            # Test layout creation
            layout_3x3 = layout.create_layout("3x3")
            layout_2x2 = layout.create_layout("2x2")
            layout_1x3 = layout.create_layout("1x3")
            
            self.results['ui_adjustment'] = {
                'status': 'PASS' if layout_3x3 and layout_2x2 and layout_1x3 else 'FAIL',
                'layouts': {
                    '3x3': layout_3x3 is not None,
                    '2x2': layout_2x2 is not None,
                    '1x3': layout_1x3 is not None
                }
            }
        except Exception as e:
            self.results['ui_adjustment'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_high_value_lut(self):
        """Test high value LUT."""
        try:
            # Create high value LUT
            lut = HighValueLUT()
            
            # Test LUT creation
            test_lut = lut.create_lut(0, 1000, 256)
            
            self.results['high_value_lut'] = {
                'status': 'PASS' if test_lut is not None and len(test_lut) == 256 else 'FAIL',
                'lut_range': (0, 1000),
                'lut_size': len(test_lut) if test_lut is not None else 0
            }
        except Exception as e:
            self.results['high_value_lut'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_search_bar(self):
        """Test search bar."""
        try:
            # Create top menu bar
            menu_bar = TopMenuBar()
            
            # Test search bar
            search_bar = menu_bar.search_bar
            
            self.results['search_bar'] = {
                'status': 'PASS' if search_bar is not None else 'FAIL'
            }
        except Exception as e:
            self.results['search_bar'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_quantification_tools(self):
        """Test quantification tools."""
        try:
            # Create quantification tools
            quant_tools = QuantificationToolsWidget()
            
            # Test tool selection
            quant_tools.select_tool("distance")
            current_tool = quant_tools.current_tool
            
            self.results['quantification_tools'] = {
                'status': 'PASS' if current_tool == "distance" else 'FAIL',
                'selected_tool': current_tool
            }
        except Exception as e:
            self.results['quantification_tools'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_pacs_connectivity(self):
        """Test PACS connectivity."""
        try:
            # Create PACS connector
            connector = PACSConnector()
            
            # Test server creation
            from pacs_connector_enhanced import PACSServer
            server = PACSServer(
                name="Test Server",
                host="127.0.0.1",
                port=104,
                aet="PYNETDICOM",
                aec="ANY-SCP",
                username="test",
                password="test"
            )
            
            self.results['pacs_connectivity'] = {
                'status': 'PASS' if server is not None else 'FAIL',
                'server_name': server.name if server is not None else None
            }
        except Exception as e:
            self.results['pacs_connectivity'] = {
                'status': 'ERROR',
                'message': str(e)
            }
    
    def test_performance_optimization(self):
        """Test performance optimization."""
        try:
            # Test loading performance
            start_time = time.time()
            
            # Simulate loading
            time.sleep(0.1)
            
            end_time = time.time()
            load_time = end_time - start_time
            
            self.results['performance_optimization'] = {
                'status': 'PASS' if load_time < 1.0 else 'FAIL',
                'load_time': load_time
            }
        except Exception as e:
            self.results['performance_optimization'] = {
                'status': 'ERROR',
                'message': str(e)
            }


def run_validation():
    """
    Run validation tests.
    
    Returns:
        dict: Test results
    """
    # Create validation tests
    validation = ValidationTests()
    
    # Run tests
    results = validation.run_all_tests()
    
    # Print results
    print("Validation Test Results:")
    print("=======================")
    
    for test_name, test_result in results.items():
        status = test_result.get('status', 'UNKNOWN')
        print(f"{test_name}: {status}")
        
        if status == 'ERROR':
            print(f"  Error: {test_result.get('message', 'Unknown error')}")
        elif status == 'FAIL':
            print("  Details:")
            for key, value in test_result.items():
                if key != 'status':
                    print(f"    {key}: {value}")
    
    # Count results
    pass_count = sum(1 for result in results.values() if result.get('status') == 'PASS')
    fail_count = sum(1 for result in results.values() if result.get('status') == 'FAIL')
    error_count = sum(1 for result in results.values() if result.get('status') == 'ERROR')
    
    print("\nSummary:")
    print(f"  Total tests: {len(results)}")
    print(f"  Passed: {pass_count}")
    print(f"  Failed: {fail_count}")
    print(f"  Errors: {error_count}")
    
    return results


def main():
    """Main function."""
    # Create application
    app = QtWidgets.QApplication(sys.argv)
    
    # Set application style
    app.setStyle("Fusion")
    
    # Create main window
    window = MainWindow()
    window.show()
    
    # Run application
    sys.exit(app.exec_())


if __name__ == "__main__":
    # Run validation tests
    if "--validate" in sys.argv:
        run_validation()
    else:
        # Run application
        main()
