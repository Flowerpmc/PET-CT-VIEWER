#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Search Module for PET/CT Viewer
------------------------------
This module provides search functionality for DICOM studies and series.
"""

import os
import sys
import logging
import datetime
import sqlite3
import pydicom
from pydicom.errors import InvalidDicomError

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('DicomSearch')

class DicomSearch:
    """
    Class for searching and indexing DICOM studies and series.
    """
    
    def __init__(self, db_path=None):
        """
        Initialize the DicomSearch with a database path.
        
        Args:
            db_path (str, optional): Path to SQLite database file
        """
        if db_path is None:
            # Use default path in user's home directory
            home_dir = os.path.expanduser("~")
            db_path = os.path.join(home_dir, ".pet_ct_viewer", "dicom_index.db")
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """Initialize the SQLite database with required tables."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create patients table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS patients (
                    patient_id TEXT PRIMARY KEY,
                    patient_name TEXT,
                    patient_birth_date TEXT,
                    patient_sex TEXT
                )
            ''')
            
            # Create studies table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS studies (
                    study_instance_uid TEXT PRIMARY KEY,
                    patient_id TEXT,
                    study_date TEXT,
                    study_time TEXT,
                    study_description TEXT,
                    accession_number TEXT,
                    referring_physician TEXT,
                    FOREIGN KEY (patient_id) REFERENCES patients (patient_id)
                )
            ''')
            
            # Create series table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS series (
                    series_instance_uid TEXT PRIMARY KEY,
                    study_instance_uid TEXT,
                    series_number INTEGER,
                    series_description TEXT,
                    modality TEXT,
                    body_part_examined TEXT,
                    series_date TEXT,
                    series_time TEXT,
                    number_of_slices INTEGER,
                    directory_path TEXT,
                    FOREIGN KEY (study_instance_uid) REFERENCES studies (study_instance_uid)
                )
            ''')
            
            conn.commit()
            conn.close()
            logger.info(f"Database initialized at {self.db_path}")
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {str(e)}")
    
    def index_directory(self, directory_path):
        """
        Index DICOM files in a directory and add them to the database.
        
        Args:
            directory_path (str): Path to directory containing DICOM files
            
        Returns:
            dict: Dictionary with indexing results
        """
        if not os.path.exists(directory_path):
            logger.error(f"Directory does not exist: {directory_path}")
            return {'status': 'error', 'message': f"Directory does not exist: {directory_path}"}
        
        try:
            # Find all potential DICOM files
            dicom_files = []
            for root, _, files in os.walk(directory_path):
                for file in files:
                    if file.lower().endswith(('.dcm', '.ima')) or '.' not in file:
                        dicom_files.append(os.path.join(root, file))
            
            if not dicom_files:
                logger.warning(f"No DICOM files found in: {directory_path}")
                return {'status': 'error', 'message': f"No DICOM files found in: {directory_path}"}
            
            # Process DICOM files
            patients_added = set()
            studies_added = set()
            series_added = set()
            
            # Group files by series
            series_dict = {}
            
            for file_path in dicom_files:
                try:
                    ds = pydicom.dcmread(file_path, force=True, stop_before_pixels=True)
                    
                    # Check if it's a valid DICOM file with required attributes
                    if not hasattr(ds, 'SOPClassUID') or not hasattr(ds, 'SeriesInstanceUID'):
                        continue
                    
                    # Group by SeriesInstanceUID
                    series_uid = ds.SeriesInstanceUID
                    if series_uid not in series_dict:
                        series_dict[series_uid] = []
                    
                    series_dict[series_uid].append((file_path, ds))
                    
                except (InvalidDicomError, AttributeError, IOError) as e:
                    logger.warning(f"Error reading file {file_path}: {str(e)}")
            
            # Process each series
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for series_uid, files in series_dict.items():
                if not files:
                    continue
                
                # Use first file as reference
                _, ds = files[0]
                
                # Extract patient information
                if hasattr(ds, 'PatientID') and ds.PatientID:
                    patient_id = ds.PatientID
                    
                    # Check if patient exists
                    cursor.execute("SELECT patient_id FROM patients WHERE patient_id = ?", (patient_id,))
                    if not cursor.fetchone():
                        # Add patient
                        patient_name = str(ds.PatientName) if hasattr(ds, 'PatientName') else "Unknown"
                        patient_birth_date = ds.PatientBirthDate if hasattr(ds, 'PatientBirthDate') else ""
                        patient_sex = ds.PatientSex if hasattr(ds, 'PatientSex') else ""
                        
                        cursor.execute('''
                            INSERT INTO patients (patient_id, patient_name, patient_birth_date, patient_sex)
                            VALUES (?, ?, ?, ?)
                        ''', (patient_id, patient_name, patient_birth_date, patient_sex))
                        
                        patients_added.add(patient_id)
                    
                    # Extract study information
                    if hasattr(ds, 'StudyInstanceUID') and ds.StudyInstanceUID:
                        study_uid = ds.StudyInstanceUID
                        
                        # Check if study exists
                        cursor.execute("SELECT study_instance_uid FROM studies WHERE study_instance_uid = ?", (study_uid,))
                        if not cursor.fetchone():
                            # Add study
                            study_date = ds.StudyDate if hasattr(ds, 'StudyDate') else ""
                            study_time = ds.StudyTime if hasattr(ds, 'StudyTime') else ""
                            study_description = ds.StudyDescription if hasattr(ds, 'StudyDescription') else ""
                            accession_number = ds.AccessionNumber if hasattr(ds, 'AccessionNumber') else ""
                            referring_physician = str(ds.ReferringPhysicianName) if hasattr(ds, 'ReferringPhysicianName') else ""
                            
                            cursor.execute('''
                                INSERT INTO studies (study_instance_uid, patient_id, study_date, study_time, 
                                                    study_description, accession_number, referring_physician)
                                VALUES (?, ?, ?, ?, ?, ?, ?)
                            ''', (study_uid, patient_id, study_date, study_time, study_description, 
                                 accession_number, referring_physician))
                            
                            studies_added.add(study_uid)
                        
                        # Check if series exists
                        cursor.execute("SELECT series_instance_uid FROM series WHERE series_instance_uid = ?", (series_uid,))
                        if not cursor.fetchone():
                            # Add series
                            series_number = int(ds.SeriesNumber) if hasattr(ds, 'SeriesNumber') else 0
                            series_description = ds.SeriesDescription if hasattr(ds, 'SeriesDescription') else ""
                            modality = ds.Modality if hasattr(ds, 'Modality') else ""
                            body_part = ds.BodyPartExamined if hasattr(ds, 'BodyPartExamined') else ""
                            series_date = ds.SeriesDate if hasattr(ds, 'SeriesDate') else ""
                            series_time = ds.SeriesTime if hasattr(ds, 'SeriesTime') else ""
                            number_of_slices = len(files)
                            
                            # Use parent directory of first file as series directory
                            series_directory = os.path.dirname(files[0][0])
                            
                            cursor.execute('''
                                INSERT INTO series (series_instance_uid, study_instance_uid, series_number, 
                                                  series_description, modality, body_part_examined, 
                                                  series_date, series_time, number_of_slices, directory_path)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ''', (series_uid, study_uid, series_number, series_description, modality, 
                                 body_part, series_date, series_time, number_of_slices, series_directory))
                            
                            series_added.add(series_uid)
            
            conn.commit()
            conn.close()
            
            return {
                'status': 'success',
                'patients_added': len(patients_added),
                'studies_added': len(studies_added),
                'series_added': len(series_added),
                'message': f"Indexed {len(series_added)} series from {len(studies_added)} studies"
            }
            
        except Exception as e:
            logger.error(f"Error indexing directory: {str(e)}")
            return {'status': 'error', 'message': f"Error indexing directory: {str(e)}"}
    
    def search_by_patient(self, patient_name=None, patient_id=None):
        """
        Search for patients by name or ID.
        
        Args:
            patient_name (str, optional): Patient name (partial match)
            patient_id (str, optional): Patient ID (exact match)
            
        Returns:
            list: List of matching patient records
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = "SELECT * FROM patients WHERE 1=1"
            params = []
            
            if patient_name:
                query += " AND patient_name LIKE ?"
                params.append(f"%{patient_name}%")
            
            if patient_id:
                query += " AND patient_id = ?"
                params.append(patient_id)
            
            cursor.execute(query, params)
            results = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            return results
        except sqlite3.Error as e:
            logger.error(f"Database search error: {str(e)}")
            return []
    
    def search_by_date(self, start_date=None, end_date=None):
        """
        Search for studies by date range.
        
        Args:
            start_date (str, optional): Start date in YYYYMMDD format
            end_date (str, optional): End date in YYYYMMDD format
            
        Returns:
            list: List of matching study records
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = """
                SELECT s.*, p.patient_name 
                FROM studies s
                JOIN patients p ON s.patient_id = p.patient_id
                WHERE 1=1
            """
            params = []
            
            if start_date:
                query += " AND s.study_date >= ?"
                params.append(start_date)
            
            if end_date:
                query += " AND s.study_date <= ?"
                params.append(end_date)
            
            query += " ORDER BY s.study_date DESC, s.study_time DESC"
            
            cursor.execute(query, params)
            results = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            return results
        except sqlite3.Error as e:
            logger.error(f"Database search error: {str(e)}")
            return []
    
    def search_by_modality(self, modality):
        """
        Search for series by modality.
        
        Args:
            modality (str): Modality type (e.g., 'PT', 'CT')
            
        Returns:
            list: List of matching series records
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = """
                SELECT ser.*, s.study_date, s.study_description, p.patient_name 
                FROM series ser
                JOIN studies s ON ser.study_instance_uid = s.study_instance_uid
                JOIN patients p ON s.patient_id = p.patient_id
                WHERE ser.modality = ?
                ORDER BY s.study_date DESC, s.study_time DESC
            """
            
            cursor.execute(query, (modality,))
            results = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            return results
        except sqlite3.Error as e:
            logger.error(f"Database search error: {str(e)}")
            return []
    
    def search_by_description(self, description):
        """
        Search for studies or series by description.
        
        Args:
            description (str): Description text (partial match)
            
        Returns:
            dict: Dictionary with study and series results
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Search studies
            study_query = """
                SELECT s.*, p.patient_name 
                FROM studies s
                JOIN patients p ON s.patient_id = p.patient_id
                WHERE s.study_description LIKE ?
                ORDER BY s.study_date DESC, s.study_time DESC
            """
            
            cursor.execute(study_query, (f"%{description}%",))
            study_results = [dict(row) for row in cursor.fetchall()]
            
            # Search series
            series_query = """
                SELECT ser.*, s.study_date, s.study_description, p.patient_name 
                FROM series ser
                JOIN studies s ON ser.study_instance_uid = s.study_instance_uid
                JOIN patients p ON s.patient_id = p.patient_id
                WHERE ser.series_description LIKE ?
                ORDER BY s.study_date DESC, s.study_time DESC
            """
            
            cursor.execute(series_query, (f"%{description}%",))
            series_results = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            
            return {
                'studies': study_results,
                'series': series_results
            }
        except sqlite3.Error as e:
            logger.error(f"Database search error: {str(e)}")
            return {'studies': [], 'series': []}
    
    def get_today_studies(self):
        """
        Get studies from today.
        
        Returns:
            list: List of today's study records
        """
        today = datetime.datetime.now().strftime("%Y%m%d")
        return self.search_by_date(today, today)
    
    def get_series_for_study(self, study_instance_uid):
        """
        Get all series for a specific study.
        
        Args:
            study_instance_uid (str): Study Instance UID
            
        Returns:
            list: List of series records
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = """
                SELECT * FROM series
                WHERE study_instance_uid = ?
                ORDER BY series_number
            """
            
            cursor.execute(query, (study_instance_uid,))
            results = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            return results
        except sqlite3.Error as e:
            logger.error(f"Database search error: {str(e)}")
            return []
    
    def get_study_details(self, study_instance_uid):
        """
        Get detailed information about a specific study.
        
        Args:
            study_instance_uid (str): Study Instance UID
            
        Returns:
            dict: Study details or None if not found
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = """
                SELECT s.*, p.* 
                FROM studies s
                JOIN patients p ON s.patient_id = p.patient_id
                WHERE s.study_instance_uid = ?
            """
            
            cursor.execute(query, (study_instance_uid,))
            row = cursor.fetchone()
            
            if row:
                result = dict(row)
                
                # Get series count
                cursor.execute("""
                    SELECT COUNT(*) as series_count FROM series
                    WHERE study_instance_uid = ?
                """, (study_instance_uid,))
                
                count_row = cursor.fetchone()
                result['series_count'] = count_row['series_count'] if count_row else 0
                
                conn.close()
                return result
            else:
                conn.close()
                return None
        except sqlite3.Error as e:
            logger.error(f"Database search error: {str(e)}")
            return None
    
    def get_series_details(self, series_instance_uid):
        """
        Get detailed information about a specific series.
        
        Args:
            series_instance_uid (str): Series Instance UID
            
        Returns:
            dict: Series details or None if not found
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = """
                SELECT ser.*, s.*, p.* 
                FROM series ser
                JOIN studies s ON ser.study_instance_uid = s.study_instance_uid
                JOIN patients p ON s.patient_id = p.patient_id
                WHERE ser.series_instance_uid = ?
            """
            
            cursor.execute(query, (series_instance_uid,))
            row = cursor.fetchone()
            
            conn.close()
            
            if row:
                return dict(row)
            else:
                return None
        except sqlite3.Error as e:
            logger.error(f"Database search error: {str(e)}")
            return None


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    search = DicomSearch()
    
    # Check if a directory path was provided
    if len(sys.argv) > 1:
        directory_path = sys.argv[1]
        result = search.index_directory(directory_path)
        print(f"Indexing result: {result}")
        
        # Perform some test searches
        print("\nPatient search:")
        patients = search.search_by_patient()
        for p in patients[:5]:  # Show first 5
            print(f"  {p['patient_name']} (ID: {p['patient_id']})")
        
        print("\nToday's studies:")
        today_studies = search.get_today_studies()
        for s in today_studies[:5]:  # Show first 5
            print(f"  {s['study_description']} - {s['patient_name']}")
        
        print("\nPET series:")
        pet_series = search.search_by_modality('PT')
        for s in pet_series[:5]:  # Show first 5
            print(f"  {s['series_description']} - {s['patient_name']}")
    else:
        print("Usage: python dicom_search.py <dicom_directory>")
