#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Interaction Handler Module for PET/CT Viewer
------------------------------------------
This module provides enhanced scrolling and interaction behavior for DICOM viewers.
"""

import os
import sys
import logging
from PyQt5 import QtCore, QtGui, QtWidgets
import vtk
from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('InteractionHandler')

class MouseWheelInteractorStyle(vtk.vtkInteractorStyleImage):
    """
    Custom interactor style for mouse wheel scrolling through slices.
    """
    
    def __init__(self):
        """Initialize the MouseWheelInteractorStyle."""
        self.AddObserver("MouseWheelForwardEvent", self.mouse_wheel_forward)
        self.AddObserver("MouseWheelBackwardEvent", self.mouse_wheel_backward)
        self.AddObserver("LeftButtonPressEvent", self.left_button_press)
        self.AddObserver("LeftButtonReleaseEvent", self.left_button_release)
        self.AddObserver("MouseMoveEvent", self.mouse_move)
        self.AddObserver("RightButtonPressEvent", self.right_button_press)
        self.AddObserver("RightButtonReleaseEvent", self.right_button_release)
        self.AddObserver("MiddleButtonPressEvent", self.middle_button_press)
        self.AddObserver("MiddleButtonReleaseEvent", self.middle_button_release)
        
        # Initialize variables
        self.slice_index = 0
        self.max_slice_index = 0
        self.slice_callback = None
        self.window_level_callback = None
        self.pan_callback = None
        self.zoom_callback = None
        self.measure_callback = None
        
        # Interaction state
        self.left_button_down = False
        self.right_button_down = False
        self.middle_button_down = False
        self.start_window = 0
        self.start_level = 0
        self.start_position = (0, 0)
        self.current_tool = "none"  # none, window_level, pan, zoom, measure
    
    def set_slice_callback(self, callback):
        """
        Set the callback function for slice changes.
        
        Args:
            callback (callable): Function to call with new slice index
        """
        self.slice_callback = callback
    
    def set_window_level_callback(self, callback):
        """
        Set the callback function for window/level changes.
        
        Args:
            callback (callable): Function to call with new window/level values
        """
        self.window_level_callback = callback
    
    def set_pan_callback(self, callback):
        """
        Set the callback function for pan changes.
        
        Args:
            callback (callable): Function to call with pan delta
        """
        self.pan_callback = callback
    
    def set_zoom_callback(self, callback):
        """
        Set the callback function for zoom changes.
        
        Args:
            callback (callable): Function to call with zoom factor
        """
        self.zoom_callback = callback
    
    def set_measure_callback(self, callback):
        """
        Set the callback function for measurements.
        
        Args:
            callback (callable): Function to call with measurement points
        """
        self.measure_callback = callback
    
    def set_slice_index(self, index):
        """
        Set the current slice index.
        
        Args:
            index (int): Slice index
        """
        self.slice_index = max(0, min(index, self.max_slice_index))
    
    def set_max_slice_index(self, max_index):
        """
        Set the maximum slice index.
        
        Args:
            max_index (int): Maximum slice index
        """
        self.max_slice_index = max_index
        self.slice_index = max(0, min(self.slice_index, self.max_slice_index))
    
    def set_current_tool(self, tool):
        """
        Set the current interaction tool.
        
        Args:
            tool (str): Tool name ('none', 'window_level', 'pan', 'zoom', 'measure')
        """
        self.current_tool = tool
    
    def mouse_wheel_forward(self, obj, event):
        """Handle mouse wheel forward event (scroll up)."""
        if self.max_slice_index > 0:
            self.slice_index = max(0, self.slice_index - 1)
            if self.slice_callback:
                self.slice_callback(self.slice_index)
        self.OnMouseWheelForward()
    
    def mouse_wheel_backward(self, obj, event):
        """Handle mouse wheel backward event (scroll down)."""
        if self.max_slice_index > 0:
            self.slice_index = min(self.max_slice_index, self.slice_index + 1)
            if self.slice_callback:
                self.slice_callback(self.slice_index)
        self.OnMouseWheelBackward()
    
    def left_button_press(self, obj, event):
        """Handle left button press event."""
        self.left_button_down = True
        self.start_position = self.GetInteractor().GetEventPosition()
        
        if self.current_tool == "window_level":
            # Get initial window/level
            if self.window_level_callback:
                self.start_window, self.start_level = self.window_level_callback(None, None, "get")
        elif self.current_tool == "measure":
            # Start measurement
            if self.measure_callback:
                self.measure_callback(self.start_position, None, "start")
        
        self.OnLeftButtonDown()
    
    def left_button_release(self, obj, event):
        """Handle left button release event."""
        self.left_button_down = False
        
        if self.current_tool == "measure":
            # End measurement
            if self.measure_callback:
                end_position = self.GetInteractor().GetEventPosition()
                self.measure_callback(self.start_position, end_position, "end")
        
        self.OnLeftButtonUp()
    
    def right_button_press(self, obj, event):
        """Handle right button press event."""
        self.right_button_down = True
        self.start_position = self.GetInteractor().GetEventPosition()
        self.OnRightButtonDown()
    
    def right_button_release(self, obj, event):
        """Handle right button release event."""
        self.right_button_down = False
        self.OnRightButtonUp()
    
    def middle_button_press(self, obj, event):
        """Handle middle button press event."""
        self.middle_button_down = True
        self.start_position = self.GetInteractor().GetEventPosition()
        self.OnMiddleButtonDown()
    
    def middle_button_release(self, obj, event):
        """Handle middle button release event."""
        self.middle_button_down = False
        self.OnMiddleButtonUp()
    
    def mouse_move(self, obj, event):
        """Handle mouse move event."""
        if not (self.left_button_down or self.right_button_down or self.middle_button_down):
            self.OnMouseMove()
            return
        
        current_position = self.GetInteractor().GetEventPosition()
        
        if self.left_button_down:
            if self.current_tool == "window_level":
                # Adjust window/level
                if self.window_level_callback:
                    # Calculate deltas
                    dx = current_position[0] - self.start_position[0]
                    dy = current_position[1] - self.start_position[1]
                    
                    # Adjust window and level
                    window = self.start_window + dx
                    level = self.start_level + dy
                    
                    # Ensure window is positive
                    window = max(1, window)
                    
                    self.window_level_callback(window, level, "set")
            elif self.current_tool == "pan":
                # Pan the image
                if self.pan_callback:
                    dx = current_position[0] - self.start_position[0]
                    dy = current_position[1] - self.start_position[1]
                    self.pan_callback(dx, dy)
                    self.start_position = current_position
            elif self.current_tool == "measure":
                # Update measurement
                if self.measure_callback:
                    self.measure_callback(self.start_position, current_position, "update")
        elif self.right_button_down:
            # Default to zoom
            if self.zoom_callback:
                dy = current_position[1] - self.start_position[1]
                zoom_factor = 1.0 + dy / 100.0
                self.zoom_callback(zoom_factor)
                self.start_position = current_position
        elif self.middle_button_down:
            # Default to pan
            if self.pan_callback:
                dx = current_position[0] - self.start_position[0]
                dy = current_position[1] - self.start_position[1]
                self.pan_callback(dx, dy)
                self.start_position = current_position
        
        self.OnMouseMove()


class DicomViewerWidget(QVTKRenderWindowInteractor):
    """
    Widget for displaying and interacting with DICOM images.
    """
    
    # Signal emitted when slice changes
    sliceChanged = QtCore.pyqtSignal(int)
    
    # Signal emitted when window/level changes
    windowLevelChanged = QtCore.pyqtSignal(float, float)
    
    # Signal emitted when measurement is made
    measurementMade = QtCore.pyqtSignal(list, float)
    
    def __init__(self, parent=None):
        """
        Initialize the DicomViewerWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(DicomViewerWidget, self).__init__(parent)
        
        # Create renderer
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.1, 0.1, 0.1)  # Dark gray background
        
        # Add renderer to render window
        self.GetRenderWindow().AddRenderer(self.renderer)
        
        # Create custom interactor style
        self.interactor_style = MouseWheelInteractorStyle()
        self.interactor_style.set_slice_callback(self._on_slice_changed)
        self.interactor_style.set_window_level_callback(self._on_window_level_changed)
        self.interactor_style.set_pan_callback(self._on_pan)
        self.interactor_style.set_zoom_callback(self._on_zoom)
        self.interactor_style.set_measure_callback(self._on_measure)
        
        # Set interactor style
        self.SetInteractorStyle(self.interactor_style)
        
        # Initialize variables
        self.slice_actor = None
        self.slice_index = 0
        self.max_slice_index = 0
        self.window = 400
        self.level = 40
        self.orientation_actors = []
        self.measurement_actors = []
        self.current_tool = "none"
        
        # Initialize camera
        self.reset_camera()
    
    def reset_camera(self):
        """Reset the camera to default position."""
        self.renderer.ResetCamera()
        camera = self.renderer.GetActiveCamera()
        camera.ParallelProjectionOn()
        self.renderer.ResetCameraClippingRange()
        self.GetRenderWindow().Render()
    
    def set_slice_actor(self, actor):
        """
        Set the slice actor.
        
        Args:
            actor (vtkActor): Slice actor
        """
        # Remove old actor if exists
        if self.slice_actor:
            self.renderer.RemoveActor(self.slice_actor)
        
        # Add new actor
        self.slice_actor = actor
        if self.slice_actor:
            self.renderer.AddActor(self.slice_actor)
            self.reset_camera()
    
    def set_slice_index(self, index):
        """
        Set the current slice index.
        
        Args:
            index (int): Slice index
        """
        self.slice_index = max(0, min(index, self.max_slice_index))
        self.interactor_style.set_slice_index(self.slice_index)
        self.sliceChanged.emit(self.slice_index)
    
    def set_max_slice_index(self, max_index):
        """
        Set the maximum slice index.
        
        Args:
            max_index (int): Maximum slice index
        """
        self.max_slice_index = max_index
        self.interactor_style.set_max_slice_index(self.max_slice_index)
        self.slice_index = max(0, min(self.slice_index, self.max_slice_index))
    
    def set_window_level(self, window, level):
        """
        Set the window/level values.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        self.window = window
        self.level = level
        self.windowLevelChanged.emit(self.window, self.level)
    
    def set_orientation_actors(self, actors):
        """
        Set the orientation marker actors.
        
        Args:
            actors (list): List of orientation actors
        """
        # Remove old actors
        for actor in self.orientation_actors:
            self.renderer.RemoveActor(actor)
        
        # Add new actors
        self.orientation_actors = actors
        for actor in self.orientation_actors:
            self.renderer.AddActor(actor)
        
        self.GetRenderWindow().Render()
    
    def set_current_tool(self, tool):
        """
        Set the current interaction tool.
        
        Args:
            tool (str): Tool name ('none', 'window_level', 'pan', 'zoom', 'measure')
        """
        self.current_tool = tool
        self.interactor_style.set_current_tool(tool)
        
        # Clear measurements if switching from measure tool
        if tool != "measure":
            self._clear_measurements()
    
    def _on_slice_changed(self, index):
        """
        Handle slice change event.
        
        Args:
            index (int): New slice index
        """
        self.slice_index = index
        self.sliceChanged.emit(index)
    
    def _on_window_level_changed(self, window, level, action):
        """
        Handle window/level change event.
        
        Args:
            window (float): Window value
            level (float): Level value
            action (str): Action ('get' or 'set')
        """
        if action == "get":
            return self.window, self.level
        elif action == "set":
            self.window = window
            self.level = level
            self.windowLevelChanged.emit(window, level)
    
    def _on_pan(self, dx, dy):
        """
        Handle pan event.
        
        Args:
            dx (float): X delta
            dy (float): Y delta
        """
        camera = self.renderer.GetActiveCamera()
        fp = camera.GetFocalPoint()
        p = camera.GetPosition()
        
        # Get camera parameters
        camera_scale = camera.GetParallelScale()
        viewport_size = self.renderer.GetSize()
        
        # Calculate movement in world coordinates
        world_dx = -dx * camera_scale * 2.0 / viewport_size[1]
        world_dy = -dy * camera_scale * 2.0 / viewport_size[1]
        
        # Move camera
        camera.SetFocalPoint(fp[0] + world_dx, fp[1] + world_dy, fp[2])
        camera.SetPosition(p[0] + world_dx, p[1] + world_dy, p[2])
        
        self.renderer.ResetCameraClippingRange()
        self.GetRenderWindow().Render()
    
    def _on_zoom(self, factor):
        """
        Handle zoom event.
        
        Args:
            factor (float): Zoom factor
        """
        camera = self.renderer.GetActiveCamera()
        
        # Adjust parallel scale (smaller = more zoom)
        camera.SetParallelScale(camera.GetParallelScale() / factor)
        
        self.renderer.ResetCameraClippingRange()
        self.GetRenderWindow().Render()
    
    def _on_measure(self, start_pos, end_pos, action):
        """
        Handle measurement event.
        
        Args:
            start_pos (tuple): Start position (x, y)
            end_pos (tuple): End position (x, y)
            action (str): Action ('start', 'update', or 'end')
        """
        if action == "start":
            # Clear previous measurements
            self._clear_measurements()
            
            # Create point
            self._add_measurement_point(start_pos)
        elif action == "update":
            # Clear previous line
            for actor in self.measurement_actors:
                if isinstance(actor, vtk.vtkLineSource) or isinstance(actor, vtk.vtkActor):
                    self.renderer.RemoveActor(actor)
            
            # Create line
            self._add_measurement_line(start_pos, end_pos)
            
            # Calculate distance
            distance = self._calculate_distance(start_pos, end_pos)
            
            # Update display
            self.GetRenderWindow().Render()
        elif action == "end":
            # Calculate final distance
            distance = self._calculate_distance(start_pos, end_pos)
            
            # Create distance text
            self._add_measurement_text(end_pos, f"{distance:.2f} mm")
            
            # Emit signal
            self.measurementMade.emit([start_pos, end_pos], distance)
            
            # Update display
            self.GetRenderWindow().Render()
    
    def _clear_measurements(self):
        """Clear all measurement actors."""
        for actor in self.measurement_actors:
            self.renderer.RemoveActor(actor)
        
        self.measurement_actors = []
        self.GetRenderWindow().Render()
    
    def _add_measurement_point(self, position):
        """
        Add a measurement point.
        
        Args:
            position (tuple): Point position (x, y)
        """
        # Convert display to world coordinates
        world_pos = self._display_to_world(position)
        
        # Create sphere
        sphere = vtk.vtkSphereSource()
        sphere.SetCenter(world_pos)
        sphere.SetRadius(1.0)
        sphere.SetPhiResolution(10)
        sphere.SetThetaResolution(10)
        
        # Create mapper
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(sphere.GetOutputPort())
        
        # Create actor
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)  # Red
        
        # Add to renderer
        self.renderer.AddActor(actor)
        self.measurement_actors.append(actor)
        
        self.GetRenderWindow().Render()
    
    def _add_measurement_line(self, start_pos, end_pos):
        """
        Add a measurement line.
        
        Args:
            start_pos (tuple): Start position (x, y)
            end_pos (tuple): End position (x, y)
        """
        # Convert display to world coordinates
        start_world = self._display_to_world(start_pos)
        end_world = self._display_to_world(end_pos)
        
        # Create line
        line = vtk.vtkLineSource()
        line.SetPoint1(start_world)
        line.SetPoint2(end_world)
        
        # Create mapper
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(line.GetOutputPort())
        
        # Create actor
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)  # Red
        actor.GetProperty().SetLineWidth(2)
        
        # Add to renderer
        self.renderer.AddActor(actor)
        self.measurement_actors.append(actor)
        self.measurement_actors.append(line)
    
    def _add_measurement_text(self, position, text):
        """
        Add measurement text.
        
        Args:
            position (tuple): Text position (x, y)
            text (str): Text to display
        """
        # Create text actor
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(text)
        text_actor.SetPosition(position[0], position[1])
        
        # Set text properties
        text_property = text_actor.GetTextProperty()
        text_property.SetColor(1, 1, 0)  # Yellow
        text_property.SetFontSize(14)
        text_property.SetBold(True)
        
        # Add to renderer
        self.renderer.AddActor(text_actor)
        self.measurement_actors.append(text_actor)
    
    def _calculate_distance(self, start_pos, end_pos):
        """
        Calculate distance between two points.
        
        Args:
            start_pos (tuple): Start position (x, y)
            end_pos (tuple): End position (x, y)
            
        Returns:
            float: Distance in mm
        """
        # Convert display to world coordinates
        start_world = self._display_to_world(start_pos)
        end_world = self._display_to_world(end_pos)
        
        # Calculate distance
        dx = end_world[0] - start_world[0]
        dy = end_world[1] - start_world[1]
        dz = end_world[2] - start_world[2]
        
        return (dx*dx + dy*dy + dz*dz) ** 0.5
    
    def _display_to_world(self, display_pos):
        """
        Convert display coordinates to world coordinates.
        
        Args:
            display_pos (tuple): Display position (x, y)
            
        Returns:
            tuple: World position (x, y, z)
        """
        # Get renderer and camera
        renderer = self.renderer
        camera = renderer.GetActiveCamera()
        
        # Get view and display info
        view_focus = camera.GetFocalPoint()
        view_plane_normal = camera.GetViewPlaneNormal()
        
        # Create picker
        picker = vtk.vtkWorldPointPicker()
        picker.Pick(display_pos[0], display_pos[1], 0, renderer)
        
        # Get picked position
        world_pos = picker.GetPickPosition()
        
        return world_pos


class ScrollableImageWidget(QtWidgets.QWidget):
    """
    Widget for displaying scrollable images with mouse wheel support.
    """
    
    # Signal emitted when slice changes
    sliceChanged = QtCore.pyqtSignal(int)
    
    def __init__(self, parent=None):
        """
        Initialize the ScrollableImageWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(ScrollableImageWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create image label
        self.image_label = QtWidgets.QLabel()
        self.image_label.setAlignment(QtCore.Qt.AlignCenter)
        self.image_label.setMinimumSize(100, 100)
        
        # Create scroll bar
        self.scroll_bar = QtWidgets.QScrollBar(QtCore.Qt.Horizontal)
        self.scroll_bar.setMinimum(0)
        self.scroll_bar.setMaximum(0)
        self.scroll_bar.valueChanged.connect(self._on_scroll_changed)
        
        # Add widgets to layout
        layout.addWidget(self.image_label, 1)
        layout.addWidget(self.scroll_bar)
        
        # Initialize variables
        self.images = []
        self.current_index = 0
        
        # Enable mouse wheel events
        self.setMouseTracking(True)
    
    def set_images(self, images):
        """
        Set the list of images to display.
        
        Args:
            images (list): List of QImage objects
        """
        self.images = images
        self.scroll_bar.setMaximum(max(0, len(images) - 1))
        self.set_current_index(0)
    
    def set_current_index(self, index):
        """
        Set the current image index.
        
        Args:
            index (int): Image index
        """
        if not self.images:
            return
        
        self.current_index = max(0, min(index, len(self.images) - 1))
        self.scroll_bar.setValue(self.current_index)
        
        # Display current image
        self._update_display()
        
        # Emit signal
        self.sliceChanged.emit(self.current_index)
    
    def _update_display(self):
        """Update the displayed image."""
        if not self.images or self.current_index >= len(self.images):
            self.image_label.clear()
            return
        
        # Get current image
        image = self.images[self.current_index]
        
        # Convert to pixmap
        pixmap = QtGui.QPixmap.fromImage(image)
        
        # Scale pixmap to fit label while maintaining aspect ratio
        scaled_pixmap = pixmap.scaled(
            self.image_label.size(),
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation
        )
        
        # Set pixmap
        self.image_label.setPixmap(scaled_pixmap)
    
    def _on_scroll_changed(self, value):
        """
        Handle scroll bar value change.
        
        Args:
            value (int): New scroll bar value
        """
        if self.current_index != value:
            self.set_current_index(value)
    
    def wheelEvent(self, event):
        """
        Handle wheel events for scrolling through images.
        
        Args:
            event (QWheelEvent): Wheel event
        """
        delta = event.angleDelta().y()
        
        if delta > 0:
            # Scroll up (previous image)
            self.set_current_index(self.current_index - 1)
        elif delta < 0:
            # Scroll down (next image)
            self.set_current_index(self.current_index + 1)
        
        event.accept()
    
    def resizeEvent(self, event):
        """
        Handle resize events.
        
        Args:
            event (QResizeEvent): Resize event
        """
        super(ScrollableImageWidget, self).resizeEvent(event)
        self._update_display()


class ToolbarWidget(QtWidgets.QWidget):
    """
    Widget for displaying a toolbar with tool buttons.
    """
    
    # Signal emitted when tool is selected
    toolSelected = QtCore.pyqtSignal(str)
    
    def __init__(self, parent=None):
        """
        Initialize the ToolbarWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(ToolbarWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create tool buttons
        self.tool_buttons = {}
        
        # Add tools
        self._add_tool("none", "Pointer", "Select")
        self._add_tool("window_level", "Window/Level", "Adjust brightness/contrast")
        self._add_tool("pan", "Pan", "Move image")
        self._add_tool("zoom", "Zoom", "Zoom image")
        self._add_tool("measure", "Measure", "Measure distance")
        
        # Add stretch to push buttons to the left
        layout.addStretch()
        
        # Set default tool
        self.set_current_tool("none")
    
    def _add_tool(self, tool_id, label, tooltip):
        """
        Add a tool button.
        
        Args:
            tool_id (str): Tool identifier
            label (str): Button label
            tooltip (str): Button tooltip
        """
        button = QtWidgets.QPushButton(label)
        button.setCheckable(True)
        button.setToolTip(tooltip)
        button.clicked.connect(lambda checked, tid=tool_id: self._on_tool_clicked(tid))
        
        self.layout().addWidget(button)
        self.tool_buttons[tool_id] = button
    
    def set_current_tool(self, tool_id):
        """
        Set the current tool.
        
        Args:
            tool_id (str): Tool identifier
        """
        # Uncheck all buttons
        for button in self.tool_buttons.values():
            button.setChecked(False)
        
        # Check selected button
        if tool_id in self.tool_buttons:
            self.tool_buttons[tool_id].setChecked(True)
            self.toolSelected.emit(tool_id)
    
    def _on_tool_clicked(self, tool_id):
        """
        Handle tool button click.
        
        Args:
            tool_id (str): Tool identifier
        """
        self.set_current_tool(tool_id)


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("Interaction Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QVBoxLayout(central_widget)
    
    # Create toolbar
    toolbar = ToolbarWidget()
    layout.addWidget(toolbar)
    
    # Create viewer widget
    viewer = DicomViewerWidget()
    layout.addWidget(viewer)
    
    # Connect signals
    toolbar.toolSelected.connect(viewer.set_current_tool)
    viewer.sliceChanged.connect(lambda index: print(f"Slice changed: {index}"))
    viewer.windowLevelChanged.connect(lambda w, l: print(f"Window/Level changed: {w}/{l}"))
    viewer.measurementMade.connect(lambda points, dist: print(f"Measurement: {dist:.2f} mm"))
    
    # Initialize interactor
    viewer.Initialize()
    viewer.Start()
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
