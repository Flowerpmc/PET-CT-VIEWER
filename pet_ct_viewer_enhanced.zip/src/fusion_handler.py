#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Fusion Image Handler Module for PET/CT Viewer
-------------------------------------------
This module provides enhanced fusion image creation and dimension alignment.
"""

import os
import sys
import logging
import numpy as np
import vtk
from scipy import ndimage
from texture_optimizer import TextureOptimizer

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('FusionHandler')

class FusionHandler:
    """
    Class for handling fusion of PET and CT images with dimension alignment.
    """
    
    def __init__(self):
        """Initialize the FusionHandler."""
        self.texture_optimizer = TextureOptimizer()
        self.pet_array = None
        self.ct_array = None
        self.fusion_array = None
        self.pet_spacing = None
        self.ct_spacing = None
        self.fusion_spacing = None
        self.pet_origin = None
        self.ct_origin = None
        self.fusion_origin = None
        self.pet_metadata = {}
        self.ct_metadata = {}
    
    def set_pet_data(self, array, spacing=None, origin=None, metadata=None):
        """
        Set PET volume data.
        
        Args:
            array (numpy.ndarray): 3D array of PET data
            spacing (tuple, optional): Voxel spacing (x, y, z)
            origin (tuple, optional): Volume origin (x, y, z)
            metadata (dict, optional): Additional metadata
        """
        if array is None:
            logger.warning("PET array is None")
            return
        
        self.pet_array = array
        self.pet_spacing = spacing if spacing is not None else (1.0, 1.0, 1.0)
        self.pet_origin = origin if origin is not None else (0.0, 0.0, 0.0)
        self.pet_metadata = metadata if metadata is not None else {}
        
        logger.info(f"PET data set with shape {array.shape}")
    
    def set_ct_data(self, array, spacing=None, origin=None, metadata=None):
        """
        Set CT volume data.
        
        Args:
            array (numpy.ndarray): 3D array of CT data
            spacing (tuple, optional): Voxel spacing (x, y, z)
            origin (tuple, optional): Volume origin (x, y, z)
            metadata (dict, optional): Additional metadata
        """
        if array is None:
            logger.warning("CT array is None")
            return
        
        self.ct_array = array
        self.ct_spacing = spacing if spacing is not None else (1.0, 1.0, 1.0)
        self.ct_origin = origin if origin is not None else (0.0, 0.0, 0.0)
        self.ct_metadata = metadata if metadata is not None else {}
        
        logger.info(f"CT data set with shape {array.shape}")
    
    def create_fusion(self, alpha_pet=0.6, alpha_ct=0.4, resample_to='pet'):
        """
        Create fusion volume from PET and CT data.
        
        Args:
            alpha_pet (float): Alpha value for PET (0.0-1.0)
            alpha_ct (float): Alpha value for CT (0.0-1.0)
            resample_to (str): Which volume to resample to ('pet', 'ct', or 'best')
            
        Returns:
            numpy.ndarray: Fusion array, or None if fusion failed
        """
        if self.pet_array is None or self.ct_array is None:
            logger.warning("Cannot create fusion: PET or CT data missing")
            return None
        
        try:
            # Check if dimensions match
            pet_shape = self.pet_array.shape
            ct_shape = self.ct_array.shape
            
            # Determine target dimensions and spacing
            if resample_to == 'pet':
                target_shape = pet_shape
                target_spacing = self.pet_spacing
                target_origin = self.pet_origin
                logger.info(f"Resampling to PET dimensions: {target_shape}")
            elif resample_to == 'ct':
                target_shape = ct_shape
                target_spacing = self.ct_spacing
                target_origin = self.ct_origin
                logger.info(f"Resampling to CT dimensions: {target_shape}")
            else:  # 'best'
                # Choose the higher resolution
                pet_volume = np.prod(pet_shape)
                ct_volume = np.prod(ct_shape)
                
                if pet_volume >= ct_volume:
                    target_shape = pet_shape
                    target_spacing = self.pet_spacing
                    target_origin = self.pet_origin
                    logger.info(f"Resampling to PET dimensions (best): {target_shape}")
                else:
                    target_shape = ct_shape
                    target_spacing = self.ct_spacing
                    target_origin = self.ct_origin
                    logger.info(f"Resampling to CT dimensions (best): {target_shape}")
            
            # Resample arrays if needed
            pet_resampled = self.pet_array
            ct_resampled = self.ct_array
            
            if pet_shape != target_shape:
                logger.info(f"Resampling PET from {pet_shape} to {target_shape}")
                pet_resampled = self._resample_array(
                    self.pet_array, pet_shape, self.pet_spacing, 
                    target_shape, target_spacing)
            
            if ct_shape != target_shape:
                logger.info(f"Resampling CT from {ct_shape} to {target_shape}")
                ct_resampled = self._resample_array(
                    self.ct_array, ct_shape, self.ct_spacing, 
                    target_shape, target_spacing)
            
            # Create fusion array
            logger.info("Creating fusion array")
            
            # Normalize CT to 0-1 range
            ct_min = -1000  # Typical min HU value
            ct_max = 1000   # Typical max HU value
            ct_normalized = (np.clip(ct_resampled, ct_min, ct_max) - ct_min) / (ct_max - ct_min)
            
            # Normalize PET to 0-1 range
            pet_max = np.max(pet_resampled)
            if pet_max > 0:
                pet_normalized = pet_resampled / pet_max
            else:
                pet_normalized = pet_resampled
            
            # Create RGB fusion
            fusion = np.zeros(target_shape + (3,), dtype=np.float32)
            
            # Apply alpha blending
            fusion[..., 0] = alpha_pet * pet_normalized  # Red channel (PET)
            fusion[..., 1] = 0.5 * alpha_pet * pet_normalized + 0.5 * alpha_ct * ct_normalized  # Green channel (mixed)
            fusion[..., 2] = alpha_ct * ct_normalized  # Blue channel (CT)
            
            # Scale to 0-255 for display
            fusion = np.clip(fusion * 255.0, 0, 255).astype(np.uint8)
            
            # Store fusion data
            self.fusion_array = fusion
            self.fusion_spacing = target_spacing
            self.fusion_origin = target_origin
            
            logger.info(f"Fusion created with shape {fusion.shape}")
            return fusion
        except Exception as e:
            logger.error(f"Error creating fusion: {str(e)}")
            return None
    
    def _resample_array(self, array, src_shape, src_spacing, dst_shape, dst_spacing):
        """
        Resample a 3D array to new dimensions and spacing.
        
        Args:
            array (numpy.ndarray): Source array
            src_shape (tuple): Source shape
            src_spacing (tuple): Source spacing
            dst_shape (tuple): Destination shape
            dst_spacing (tuple): Destination spacing
            
        Returns:
            numpy.ndarray: Resampled array
        """
        # Calculate physical size
        src_physical_size = np.array(src_shape) * np.array(src_spacing)
        dst_physical_size = np.array(dst_shape) * np.array(dst_spacing)
        
        # Calculate zoom factors
        zoom_factors = src_physical_size / dst_physical_size
        
        # Adjust zoom factors for shape differences
        zoom_factors = zoom_factors * np.array(dst_shape) / np.array(src_shape)
        
        # Resample using scipy's ndimage
        resampled = ndimage.zoom(array, zoom_factors, order=1)
        
        # Handle any small differences in shape due to rounding
        if resampled.shape != dst_shape:
            # Create output array of exact target shape
            output = np.zeros(dst_shape, dtype=array.dtype)
            
            # Copy data, handling shape differences
            slices = tuple(slice(0, min(resampled.shape[i], dst_shape[i])) for i in range(len(dst_shape)))
            output[slices] = resampled[slices]
            
            return output
        
        return resampled
    
    def create_vtk_volume(self, array, spacing=None):
        """
        Create a VTK volume from a numpy array.
        
        Args:
            array (numpy.ndarray): 3D array of volume data
            spacing (tuple, optional): Voxel spacing (x, y, z)
            
        Returns:
            vtkImageData: VTK image data
        """
        if array is None:
            logger.warning("Array is None")
            return None
        
        if spacing is None:
            spacing = (1.0, 1.0, 1.0)
        
        try:
            # Create VTK image data
            vtk_image = vtk.vtkImageData()
            
            # Set dimensions
            if len(array.shape) == 3:
                # 3D volume
                vtk_image.SetDimensions(array.shape[2], array.shape[1], array.shape[0])
            elif len(array.shape) == 4 and array.shape[3] <= 4:
                # 3D volume with color components
                vtk_image.SetDimensions(array.shape[2], array.shape[1], array.shape[0])
            else:
                logger.error(f"Unsupported array shape: {array.shape}")
                return None
            
            # Set spacing
            vtk_image.SetSpacing(spacing)
            
            # Set origin to center of volume
            origin_x = -spacing[0] * array.shape[2] / 2
            origin_y = -spacing[1] * array.shape[1] / 2
            origin_z = -spacing[2] * array.shape[0] / 2
            vtk_image.SetOrigin(origin_x, origin_y, origin_z)
            
            # Determine VTK data type and number of components
            if len(array.shape) == 3:
                num_components = 1
            else:
                num_components = array.shape[3]
            
            vtk_type = vtk.VTK_UNSIGNED_CHAR
            if array.dtype == np.uint8:
                vtk_type = vtk.VTK_UNSIGNED_CHAR
            elif array.dtype == np.int16:
                vtk_type = vtk.VTK_SHORT
            elif array.dtype == np.uint16:
                vtk_type = vtk.VTK_UNSIGNED_SHORT
            elif array.dtype == np.int32:
                vtk_type = vtk.VTK_INT
            elif array.dtype == np.float32:
                vtk_type = vtk.VTK_FLOAT
            elif array.dtype == np.float64:
                vtk_type = vtk.VTK_DOUBLE
            
            # Allocate scalars
            vtk_image.AllocateScalars(vtk_type, num_components)
            
            # Get pointer to data and copy
            if num_components == 1:
                # Single component data
                vtk_array = vtk.util.numpy_support.numpy_to_vtk(
                    array.ravel(), deep=True, array_type=vtk_type)
            else:
                # Multi-component data (e.g., RGB)
                # Reshape to 2D array with shape (num_points, num_components)
                flat_array = array.reshape(-1, num_components)
                vtk_array = vtk.util.numpy_support.numpy_to_vtk(
                    flat_array, deep=True, array_type=vtk_type)
                vtk_array.SetNumberOfComponents(num_components)
            
            vtk_image.GetPointData().SetScalars(vtk_array)
            
            return vtk_image
        except Exception as e:
            logger.error(f"Error creating VTK volume: {str(e)}")
            return None
    
    def create_fusion_slice(self, orientation, slice_index, alpha_pet=0.6, alpha_ct=0.4):
        """
        Create a 2D fusion slice from PET and CT data.
        
        Args:
            orientation (int): Slice orientation (0=axial, 1=coronal, 2=sagittal)
            slice_index (int): Slice index
            alpha_pet (float): Alpha value for PET (0.0-1.0)
            alpha_ct (float): Alpha value for CT (0.0-1.0)
            
        Returns:
            numpy.ndarray: 2D RGB fusion slice, or None if fusion failed
        """
        if self.pet_array is None or self.ct_array is None:
            logger.warning("Cannot create fusion slice: PET or CT data missing")
            return None
        
        try:
            # Extract 2D slices
            pet_slice = self._extract_slice(self.pet_array, orientation, slice_index)
            ct_slice = self._extract_slice(self.ct_array, orientation, slice_index)
            
            # Check if dimensions match
            if pet_slice.shape != ct_slice.shape:
                logger.warning(f"PET slice shape {pet_slice.shape} does not match CT slice shape {ct_slice.shape}")
                
                # Resample CT slice to match PET slice
                ct_slice = self._resample_slice(ct_slice, pet_slice.shape)
            
            # Normalize CT to 0-1 range
            ct_min = -1000  # Typical min HU value
            ct_max = 1000   # Typical max HU value
            ct_normalized = (np.clip(ct_slice, ct_min, ct_max) - ct_min) / (ct_max - ct_min)
            
            # Normalize PET to 0-1 range
            pet_max = np.max(pet_slice)
            if pet_max > 0:
                pet_normalized = pet_slice / pet_max
            else:
                pet_normalized = pet_slice
            
            # Create RGB fusion
            fusion = np.zeros(pet_slice.shape + (3,), dtype=np.float32)
            
            # Apply alpha blending
            fusion[..., 0] = alpha_pet * pet_normalized  # Red channel (PET)
            fusion[..., 1] = 0.5 * alpha_pet * pet_normalized + 0.5 * alpha_ct * ct_normalized  # Green channel (mixed)
            fusion[..., 2] = alpha_ct * ct_normalized  # Blue channel (CT)
            
            # Scale to 0-255 for display
            fusion = np.clip(fusion * 255.0, 0, 255).astype(np.uint8)
            
            return fusion
        except Exception as e:
            logger.error(f"Error creating fusion slice: {str(e)}")
            return None
    
    def _extract_slice(self, volume, orientation, index):
        """
        Extract a 2D slice from a 3D volume.
        
        Args:
            volume (numpy.ndarray): 3D volume
            orientation (int): Slice orientation (0=axial, 1=coronal, 2=sagittal)
            index (int): Slice index
            
        Returns:
            numpy.ndarray: 2D slice
        """
        if orientation == 0:  # Axial
            if 0 <= index < volume.shape[0]:
                return volume[index, :, :]
            else:
                return np.zeros((volume.shape[1], volume.shape[2]), dtype=volume.dtype)
        elif orientation == 1:  # Coronal
            if 0 <= index < volume.shape[1]:
                return volume[:, index, :]
            else:
                return np.zeros((volume.shape[0], volume.shape[2]), dtype=volume.dtype)
        else:  # Sagittal
            if 0 <= index < volume.shape[2]:
                return volume[:, :, index]
            else:
                return np.zeros((volume.shape[0], volume.shape[1]), dtype=volume.dtype)
    
    def _resample_slice(self, slice_array, target_shape):
        """
        Resample a 2D slice to new dimensions.
        
        Args:
            slice_array (numpy.ndarray): Source slice
            target_shape (tuple): Target shape
            
        Returns:
            numpy.ndarray: Resampled slice
        """
        # Calculate zoom factors
        zoom_factors = np.array(target_shape) / np.array(slice_array.shape)
        
        # Resample using scipy's ndimage
        return ndimage.zoom(slice_array, zoom_factors, order=1)
    
    def create_optimized_fusion_volume(self):
        """
        Create an optimized VTK volume for fusion data.
        
        Returns:
            vtkImageData: VTK image data, or None if fusion failed
        """
        if self.fusion_array is None:
            logger.warning("No fusion data available")
            return None
        
        # Check if dimensions exceed texture size limits
        max_dim = max(self.fusion_array.shape[:3])
        if max_dim > self.texture_optimizer.max_texture_size:
            logger.warning(f"Fusion dimensions {max_dim} exceed max texture size {self.texture_optimizer.max_texture_size}")
            logger.info("Using optimized texture handling")
            
            # Optimize texture size
            optimized_array = self.texture_optimizer.optimize_texture_size(self.fusion_array)
            
            # Create VTK volume
            return self.create_vtk_volume(optimized_array, self.fusion_spacing)
        else:
            # Create VTK volume directly
            return self.create_vtk_volume(self.fusion_array, self.fusion_spacing)
    
    def get_fusion_array(self):
        """
        Get the fusion array.
        
        Returns:
            numpy.ndarray: Fusion array, or None if not available
        """
        return self.fusion_array
    
    def get_fusion_spacing(self):
        """
        Get the fusion spacing.
        
        Returns:
            tuple: Fusion spacing, or None if not available
        """
        return self.fusion_spacing
    
    def get_fusion_origin(self):
        """
        Get the fusion origin.
        
        Returns:
            tuple: Fusion origin, or None if not available
        """
        return self.fusion_origin


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    fusion_handler = FusionHandler()
    
    # Create test data
    try:
        # Create PET-like volume
        pet_size = 64
        pet_volume = np.zeros((pet_size, pet_size, pet_size), dtype=np.float32)
        for z in range(pet_size):
            for y in range(pet_size):
                for x in range(pet_size):
                    # Create a sphere
                    dx = x - pet_size/2
                    dy = y - pet_size/2
                    dz = z - pet_size/2
                    distance = np.sqrt(dx*dx + dy*dy + dz*dz)
                    if distance < pet_size/4:
                        pet_volume[z, y, x] = 5.0 * (1.0 - distance/(pet_size/4))
        
        # Create CT-like volume with different dimensions
        ct_size = 80
        ct_volume = np.zeros((ct_size, ct_size, ct_size), dtype=np.int16)
        for z in range(ct_size):
            for y in range(ct_size):
                for x in range(ct_size):
                    # Create a cylinder
                    dx = x - ct_size/2
                    dy = y - ct_size/2
                    distance = np.sqrt(dx*dx + dy*dy)
                    if distance < ct_size/3:
                        ct_volume[z, y, x] = 100
                    else:
                        ct_volume[z, y, x] = -1000
        
        # Set data in fusion handler
        fusion_handler.set_pet_data(pet_volume, spacing=(1.0, 1.0, 1.0))
        fusion_handler.set_ct_data(ct_volume, spacing=(0.8, 0.8, 0.8))
        
        # Create fusion
        fusion = fusion_handler.create_fusion(alpha_pet=0.7, alpha_ct=0.3, resample_to='best')
        
        if fusion is not None:
            print(f"Created fusion with shape {fusion.shape}")
            
            # Create a fusion slice
            fusion_slice = fusion_handler.create_fusion_slice(0, 32)
            if fusion_slice is not None:
                print(f"Created fusion slice with shape {fusion_slice.shape}")
                
                # Save slice as image for testing
                try:
                    from PIL import Image
                    Image.fromarray(fusion_slice).save("fusion_slice_test.png")
                    print("Saved fusion slice as fusion_slice_test.png")
                except ImportError:
                    print("PIL not available, cannot save image")
    except Exception as e:
        print(f"Error in test: {str(e)}")
