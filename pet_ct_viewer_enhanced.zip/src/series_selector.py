#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Series Selection Module for PET/CT Viewer
---------------------------------------
This module provides enhanced series selection with drag-and-drop functionality.
"""

import os
import sys
import logging
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('SeriesSelector')

class SeriesItem(QtWidgets.QListWidgetItem):
    """
    Custom list widget item for displaying series information.
    """
    
    def __init__(self, series_info, parent=None):
        """
        Initialize the SeriesItem.
        
        Args:
            series_info (dict): Series information
            parent (QListWidget, optional): Parent list widget
        """
        super(SeriesItem, self).__init__(parent)
        
        self.series_info = series_info
        
        # Set text based on series information
        modality = series_info.get('Modality', 'Unknown')
        description = series_info.get('SeriesDescription', 'Unknown')
        slice_count = series_info.get('SliceCount', 0)
        
        self.setText(f"{modality}: {description} ({slice_count} slices)")
        
        # Set tooltip with more information
        tooltip = f"Series: {description}\n"
        tooltip += f"Modality: {modality}\n"
        tooltip += f"Series Number: {series_info.get('SeriesNumber', 'Unknown')}\n"
        tooltip += f"Slices: {slice_count}\n"
        tooltip += f"Patient: {series_info.get('PatientName', 'Unknown')}"
        self.setToolTip(tooltip)
        
        # Set icon based on modality
        if modality == 'PT':
            self.setIcon(QtGui.QIcon.fromTheme("image-x-generic", QtGui.QIcon()))
            # Set background color hint for PET (light red)
            self.setBackground(QtGui.QBrush(QtGui.QColor(255, 230, 230)))
        elif modality == 'CT':
            self.setIcon(QtGui.QIcon.fromTheme("image-x-generic", QtGui.QIcon()))
            # Set background color hint for CT (light blue)
            self.setBackground(QtGui.QBrush(QtGui.QColor(230, 230, 255)))
        else:
            self.setIcon(QtGui.QIcon.fromTheme("image", QtGui.QIcon()))
        
        # Set data for drag and drop
        self.setData(QtCore.Qt.UserRole, series_info)


class SeriesListWidget(QtWidgets.QListWidget):
    """
    Custom list widget for displaying and selecting series.
    """
    
    seriesDropped = QtCore.pyqtSignal(dict, str)  # Signal emitted when a series is dropped (series_info, drop_target)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesListWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesListWidget, self).__init__(parent)
        
        # Enable drag and drop
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QtWidgets.QAbstractItemView.DragDrop)
        self.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        
        # Set size policy
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        
        # Set minimum size
        self.setMinimumWidth(200)
        
        # Set alternate row colors
        self.setAlternatingRowColors(True)
    
    def dragEnterEvent(self, event):
        """Handle drag enter events."""
        if event.mimeData().hasFormat("application/x-qabstractitemmodeldatalist"):
            event.acceptProposedAction()
        else:
            super(SeriesListWidget, self).dragEnterEvent(event)
    
    def dragMoveEvent(self, event):
        """Handle drag move events."""
        if event.mimeData().hasFormat("application/x-qabstractitemmodeldatalist"):
            event.acceptProposedAction()
        else:
            super(SeriesListWidget, self).dragMoveEvent(event)
    
    def dropEvent(self, event):
        """Handle drop events."""
        if event.mimeData().hasFormat("application/x-qabstractitemmodeldatalist"):
            # Get the source widget
            source = event.source()
            
            # Get the dropped item
            data = event.mimeData()
            item_data = data.data("application/x-qabstractitemmodeldatalist")
            stream = QtCore.QDataStream(item_data, QtCore.QIODevice.ReadOnly)
            
            # Read the data
            while not stream.atEnd():
                row = stream.readInt32()
                column = stream.readInt32()
                
                # Read the number of items
                map_items = stream.readInt32()
                
                # Read each item
                for i in range(map_items):
                    key = stream.readInt32()
                    value = QtCore.QVariant()
                    stream >> value
                    
                    # If this is the user role data, emit signal
                    if key == QtCore.Qt.UserRole:
                        series_info = value
                        self.seriesDropped.emit(series_info, self.objectName())
                        break
            
            event.acceptProposedAction()
        else:
            super(SeriesListWidget, self).dropEvent(event)


class SeriesSelector(QtWidgets.QWidget):
    """
    Widget for selecting and managing series.
    """
    
    seriesSelected = QtCore.pyqtSignal(dict)  # Signal emitted when a series is selected
    seriesAssigned = QtCore.pyqtSignal(dict, str)  # Signal emitted when a series is assigned to a view (series_info, view_type)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesSelector.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesSelector, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create filter controls
        filter_layout = QtWidgets.QHBoxLayout()
        
        self.filter_edit = QtWidgets.QLineEdit()
        self.filter_edit.setPlaceholderText("Filter series...")
        self.filter_edit.textChanged.connect(self._filter_series)
        
        self.modality_combo = QtWidgets.QComboBox()
        self.modality_combo.addItem("All Modalities")
        self.modality_combo.addItem("PET")
        self.modality_combo.addItem("CT")
        self.modality_combo.currentTextChanged.connect(self._filter_series)
        
        filter_layout.addWidget(self.filter_edit)
        filter_layout.addWidget(self.modality_combo)
        
        # Create series list
        self.series_list = SeriesListWidget()
        self.series_list.setObjectName("series_list")
        self.series_list.itemClicked.connect(self._on_series_clicked)
        self.series_list.seriesDropped.connect(self._on_series_dropped)
        
        # Create buttons
        button_layout = QtWidgets.QHBoxLayout()
        
        self.open_button = QtWidgets.QPushButton("Open")
        self.open_button.clicked.connect(self._on_open_clicked)
        
        self.refresh_button = QtWidgets.QPushButton("Refresh")
        self.refresh_button.clicked.connect(self._on_refresh_clicked)
        
        button_layout.addWidget(self.open_button)
        button_layout.addWidget(self.refresh_button)
        
        # Create target drop areas
        targets_layout = QtWidgets.QHBoxLayout()
        
        # PET target
        pet_layout = QtWidgets.QVBoxLayout()
        pet_label = QtWidgets.QLabel("PET")
        pet_label.setAlignment(QtCore.Qt.AlignCenter)
        self.pet_target = SeriesListWidget()
        self.pet_target.setObjectName("pet_target")
        self.pet_target.setMaximumHeight(60)
        self.pet_target.seriesDropped.connect(self._on_series_dropped)
        pet_layout.addWidget(pet_label)
        pet_layout.addWidget(self.pet_target)
        
        # CT target
        ct_layout = QtWidgets.QVBoxLayout()
        ct_label = QtWidgets.QLabel("CT")
        ct_label.setAlignment(QtCore.Qt.AlignCenter)
        self.ct_target = SeriesListWidget()
        self.ct_target.setObjectName("ct_target")
        self.ct_target.setMaximumHeight(60)
        self.ct_target.seriesDropped.connect(self._on_series_dropped)
        ct_layout.addWidget(ct_label)
        ct_layout.addWidget(self.ct_target)
        
        targets_layout.addLayout(pet_layout)
        targets_layout.addLayout(ct_layout)
        
        # Add widgets to layout
        layout.addLayout(filter_layout)
        layout.addWidget(self.series_list)
        layout.addLayout(targets_layout)
        layout.addLayout(button_layout)
        
        # Initialize variables
        self.series_list_data = []
        self.current_pet_series = None
        self.current_ct_series = None
    
    def set_series_list(self, series_list):
        """
        Set the list of available series.
        
        Args:
            series_list (list): List of series information dictionaries
        """
        self.series_list_data = series_list
        self._update_series_list()
    
    def _update_series_list(self):
        """Update the series list widget with filtered items."""
        # Clear the list
        self.series_list.clear()
        
        # Get filter text
        filter_text = self.filter_edit.text().lower()
        
        # Get modality filter
        modality_filter = self.modality_combo.currentText()
        if modality_filter == "All Modalities":
            modality_filter = None
        
        # Add items that match the filter
        for series_info in self.series_list_data:
            # Check modality filter
            if modality_filter and series_info.get('Modality') != modality_filter:
                continue
            
            # Check text filter
            if filter_text:
                description = series_info.get('SeriesDescription', '').lower()
                patient_name = str(series_info.get('PatientName', '')).lower()
                
                if filter_text not in description and filter_text not in patient_name:
                    continue
            
            # Add item
            item = SeriesItem(series_info)
            self.series_list.addItem(item)
    
    def _filter_series(self):
        """Filter the series list based on current filter settings."""
        self._update_series_list()
    
    def _on_series_clicked(self, item):
        """
        Handle series item click.
        
        Args:
            item (SeriesItem): Clicked item
        """
        # Get series info
        series_info = item.data(QtCore.Qt.UserRole)
        
        # Emit signal
        self.seriesSelected.emit(series_info)
    
    def _on_series_dropped(self, series_info, target_name):
        """
        Handle series drop event.
        
        Args:
            series_info (dict): Series information
            target_name (str): Name of the drop target
        """
        # Check target
        if target_name == "pet_target":
            # Clear previous item
            self.pet_target.clear()
            
            # Add new item
            item = SeriesItem(series_info)
            self.pet_target.addItem(item)
            
            # Store current PET series
            self.current_pet_series = series_info
            
            # Emit signal
            self.seriesAssigned.emit(series_info, "PET")
        elif target_name == "ct_target":
            # Clear previous item
            self.ct_target.clear()
            
            # Add new item
            item = SeriesItem(series_info)
            self.ct_target.addItem(item)
            
            # Store current CT series
            self.current_ct_series = series_info
            
            # Emit signal
            self.seriesAssigned.emit(series_info, "CT")
    
    def _on_open_clicked(self):
        """Handle open button click."""
        # Get selected item
        item = self.series_list.currentItem()
        if not item:
            return
        
        # Get series info
        series_info = item.data(QtCore.Qt.UserRole)
        
        # Check modality and assign to appropriate target
        modality = series_info.get('Modality')
        if modality == 'PT':
            self._on_series_dropped(series_info, "pet_target")
        elif modality == 'CT':
            self._on_series_dropped(series_info, "ct_target")
    
    def _on_refresh_clicked(self):
        """Handle refresh button click."""
        # Just update the list with current data
        self._update_series_list()
    
    def get_current_pet_series(self):
        """
        Get the currently selected PET series.
        
        Returns:
            dict: PET series information or None
        """
        return self.current_pet_series
    
    def get_current_ct_series(self):
        """
        Get the currently selected CT series.
        
        Returns:
            dict: CT series information or None
        """
        return self.current_ct_series


class FileDropWidget(QtWidgets.QWidget):
    """
    Widget that accepts file drops.
    """
    
    filesDropped = QtCore.pyqtSignal(list)  # Signal emitted when files are dropped
    
    def __init__(self, parent=None):
        """
        Initialize the FileDropWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(FileDropWidget, self).__init__(parent)
        
        # Enable drag and drop
        self.setAcceptDrops(True)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create label
        self.label = QtWidgets.QLabel("Drop DICOM files here")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setStyleSheet("border: 2px dashed #aaa; padding: 20px;")
        
        # Add label to layout
        layout.addWidget(self.label)
    
    def dragEnterEvent(self, event):
        """Handle drag enter events."""
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def dragMoveEvent(self, event):
        """Handle drag move events."""
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def dropEvent(self, event):
        """Handle drop events."""
        if event.mimeData().hasUrls():
            # Get the dropped URLs
            urls = event.mimeData().urls()
            
            # Convert to local file paths
            file_paths = [url.toLocalFile() for url in urls]
            
            # Emit signal
            self.filesDropped.emit(file_paths)
            
            event.acceptProposedAction()


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("Series Selector Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QVBoxLayout(central_widget)
    
    # Create file drop widget
    file_drop = FileDropWidget()
    
    # Create series selector
    series_selector = SeriesSelector()
    
    # Connect signals
    file_drop.filesDropped.connect(lambda files: print(f"Files dropped: {files}"))
    series_selector.seriesSelected.connect(lambda series: print(f"Series selected: {series}"))
    series_selector.seriesAssigned.connect(lambda series, view_type: print(f"Series assigned to {view_type}: {series}"))
    
    # Add widgets to layout
    layout.addWidget(file_drop)
    layout.addWidget(series_selector)
    
    # Add some sample data
    sample_series = [
        {
            'SeriesInstanceUID': '1.2.3.4.5.1',
            'SeriesNumber': 1,
            'SeriesDescription': 'Whole Body PET',
            'Modality': 'PT',
            'PatientName': 'John Doe',
            'SliceCount': 234
        },
        {
            'SeriesInstanceUID': '1.2.3.4.5.2',
            'SeriesNumber': 2,
            'SeriesDescription': 'Whole Body CT',
            'Modality': 'CT',
            'PatientName': 'John Doe',
            'SliceCount': 234
        },
        {
            'SeriesInstanceUID': '1.2.3.4.5.3',
            'SeriesNumber': 3,
            'SeriesDescription': 'Brain PET',
            'Modality': 'PT',
            'PatientName': 'Jane Smith',
            'SliceCount': 120
        },
        {
            'SeriesInstanceUID': '1.2.3.4.5.4',
            'SeriesNumber': 4,
            'SeriesDescription': 'Brain CT',
            'Modality': 'CT',
            'PatientName': 'Jane Smith',
            'SliceCount': 120
        }
    ]
    
    series_selector.set_series_list(sample_series)
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
