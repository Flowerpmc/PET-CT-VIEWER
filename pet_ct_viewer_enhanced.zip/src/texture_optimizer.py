#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
OpenGL Texture Optimization Module for PET/CT Viewer
--------------------------------------------------
This module provides optimized texture handling for large DICOM images.
"""

import os
import sys
import logging
import numpy as np
import vtk

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('TextureOptimizer')

class TextureOptimizer:
    """
    Class for optimizing texture handling in VTK/OpenGL rendering.
    """
    
    def __init__(self):
        """Initialize the TextureOptimizer."""
        # Get OpenGL capabilities
        self.gl_vendor = None
        self.gl_renderer = None
        self.gl_version = None
        self.max_texture_size = 4096  # Default conservative value
        self.texture_tiling_enabled = False
        self.texture_compression_enabled = False
        
        # Try to detect OpenGL capabilities
        self._detect_opengl_capabilities()
    
    def _detect_opengl_capabilities(self):
        """Detect OpenGL capabilities using VTK."""
        try:
            # Create a dummy render window to query OpenGL info
            render_window = vtk.vtkRenderWindow()
            render_window.SetOffScreenRendering(1)
            render_window.Render()
            
            # Get OpenGL info
            opengl_info = render_window.GetOpenGLInformation()
            if opengl_info:
                self.gl_vendor = opengl_info.GetVendor()
                self.gl_renderer = opengl_info.GetRenderer()
                self.gl_version = opengl_info.GetVersion()
                
                # Get max texture size
                if opengl_info.GetMaximumTextureSize() > 0:
                    self.max_texture_size = opengl_info.GetMaximumTextureSize()
                
                logger.info(f"OpenGL Vendor: {self.gl_vendor}")
                logger.info(f"OpenGL Renderer: {self.gl_renderer}")
                logger.info(f"OpenGL Version: {self.gl_version}")
                logger.info(f"Max Texture Size: {self.max_texture_size}")
            
            # Clean up
            render_window = None
        except Exception as e:
            logger.warning(f"Failed to detect OpenGL capabilities: {str(e)}")
    
    def optimize_texture_size(self, image_data):
        """
        Optimize texture size for an image.
        
        Args:
            image_data (numpy.ndarray): Image data
            
        Returns:
            numpy.ndarray: Optimized image data
        """
        # Check if image exceeds max texture size
        if image_data is None:
            return None
        
        shape = image_data.shape
        max_dim = max(shape)
        
        if max_dim > self.max_texture_size:
            logger.warning(f"Image dimension {max_dim} exceeds max texture size {self.max_texture_size}")
            
            # Option 1: Downsample the image
            if len(shape) == 2:
                # 2D image
                scale_factor = self.max_texture_size / max_dim
                new_shape = (int(shape[0] * scale_factor), int(shape[1] * scale_factor))
                return self._resize_image(image_data, new_shape)
            elif len(shape) == 3:
                # 3D image (assuming last dimension is components)
                scale_factor = self.max_texture_size / max(shape[0], shape[1])
                new_shape = (int(shape[0] * scale_factor), int(shape[1] * scale_factor), shape[2])
                return self._resize_image(image_data, new_shape)
        
        return image_data
    
    def _resize_image(self, image_data, new_shape):
        """
        Resize an image to new dimensions.
        
        Args:
            image_data (numpy.ndarray): Image data
            new_shape (tuple): New shape
            
        Returns:
            numpy.ndarray: Resized image data
        """
        try:
            from scipy.ndimage import zoom
            
            # Calculate zoom factors
            zoom_factors = [new_dim / old_dim for new_dim, old_dim in zip(new_shape, image_data.shape)]
            
            # Resize image
            return zoom(image_data, zoom_factors, order=1)
        except ImportError:
            logger.warning("scipy not available, using simple resize")
            return self._simple_resize(image_data, new_shape)
    
    def _simple_resize(self, image_data, new_shape):
        """
        Simple resize function when scipy is not available.
        
        Args:
            image_data (numpy.ndarray): Image data
            new_shape (tuple): New shape
            
        Returns:
            numpy.ndarray: Resized image data
        """
        # Create output array
        output = np.zeros(new_shape, dtype=image_data.dtype)
        
        # Calculate scaling factors
        scale_x = image_data.shape[0] / new_shape[0]
        scale_y = image_data.shape[1] / new_shape[1]
        
        # Simple nearest neighbor sampling
        for i in range(new_shape[0]):
            for j in range(new_shape[1]):
                src_i = min(int(i * scale_x), image_data.shape[0] - 1)
                src_j = min(int(j * scale_y), image_data.shape[1] - 1)
                
                if len(new_shape) == 3:
                    output[i, j, :] = image_data[src_i, src_j, :]
                else:
                    output[i, j] = image_data[src_i, src_j]
        
        return output
    
    def create_tiled_textures(self, image_data):
        """
        Create tiled textures for large images.
        
        Args:
            image_data (numpy.ndarray): Image data
            
        Returns:
            list: List of VTK texture objects
        """
        if image_data is None:
            return []
        
        shape = image_data.shape
        max_dim = max(shape[:2])  # Consider only first two dimensions for tiling
        
        if max_dim <= self.max_texture_size:
            # No tiling needed
            return [self._create_single_texture(image_data)]
        
        # Enable tiling
        self.texture_tiling_enabled = True
        
        # Calculate number of tiles needed
        tiles_x = (shape[1] + self.max_texture_size - 1) // self.max_texture_size
        tiles_y = (shape[0] + self.max_texture_size - 1) // self.max_texture_size
        
        logger.info(f"Creating {tiles_x}x{tiles_y} texture tiles")
        
        # Create tiles
        textures = []
        for ty in range(tiles_y):
            for tx in range(tiles_x):
                # Calculate tile bounds
                x0 = tx * self.max_texture_size
                y0 = ty * self.max_texture_size
                x1 = min(x0 + self.max_texture_size, shape[1])
                y1 = min(y0 + self.max_texture_size, shape[0])
                
                # Extract tile data
                if len(shape) == 2:
                    tile_data = image_data[y0:y1, x0:x1]
                else:
                    tile_data = image_data[y0:y1, x0:x1, :]
                
                # Create texture for this tile
                texture = self._create_single_texture(tile_data)
                textures.append((texture, (x0, y0, x1, y1)))
        
        return textures
    
    def _create_single_texture(self, image_data):
        """
        Create a single VTK texture from image data.
        
        Args:
            image_data (numpy.ndarray): Image data
            
        Returns:
            vtkTexture: VTK texture object
        """
        # Create VTK image data
        vtk_image = vtk.vtkImageData()
        
        # Set dimensions
        shape = image_data.shape
        if len(shape) == 2:
            vtk_image.SetDimensions(shape[1], shape[0], 1)
            num_components = 1
        else:
            vtk_image.SetDimensions(shape[1], shape[0], 1)
            num_components = shape[2]
        
        # Set number of components
        vtk_image.AllocateScalars(vtk.VTK_UNSIGNED_CHAR, num_components)
        
        # Copy data to VTK image
        data_flat = image_data.flatten()
        vtk_array = vtk.vtkUnsignedCharArray()
        vtk_array.SetNumberOfComponents(num_components)
        vtk_array.SetNumberOfTuples(len(data_flat) // num_components)
        for i in range(len(data_flat)):
            vtk_array.SetValue(i, data_flat[i])
        
        vtk_image.GetPointData().SetScalars(vtk_array)
        
        # Create texture
        texture = vtk.vtkTexture()
        texture.SetInputData(vtk_image)
        texture.InterpolateOn()
        
        # Enable mipmapping for better quality
        texture.MipmapOn()
        
        # Enable edge clamping
        texture.EdgeClampOn()
        
        # Enable compression if supported
        if self.texture_compression_enabled:
            texture.SetCompression(True)
        
        return texture
    
    def optimize_vtk_mapper(self, mapper):
        """
        Optimize a VTK mapper for better performance.
        
        Args:
            mapper: VTK mapper object
            
        Returns:
            bool: True if optimization was applied, False otherwise
        """
        if mapper is None:
            return False
        
        try:
            # Enable immediate mode rendering for better performance with large datasets
            mapper.ImmediateModeRenderingOff()
            
            # Set scalar mode to optimize for texture mapping
            mapper.SetScalarModeToUsePointData()
            
            # Enable color interpolation for smoother rendering
            mapper.InterpolateScalarsBeforeMappingOn()
            
            # Set scalar visibility
            mapper.SetScalarVisibility(True)
            
            return True
        except Exception as e:
            logger.warning(f"Error optimizing mapper: {str(e)}")
            return False
    
    def optimize_vtk_volume(self, volume):
        """
        Optimize a VTK volume for better performance.
        
        Args:
            volume: VTK volume object
            
        Returns:
            bool: True if optimization was applied, False otherwise
        """
        if volume is None:
            return False
        
        try:
            # Get volume property
            volume_property = volume.GetProperty()
            
            # Set interpolation type
            volume_property.SetInterpolationTypeToLinear()
            
            # Set sample distance for ray casting
            volume.SetSampleDistance(0.5)
            
            # Enable auto adjustment of sample distance
            volume.AutoAdjustSampleDistancesOn()
            
            return True
        except Exception as e:
            logger.warning(f"Error optimizing volume: {str(e)}")
            return False
    
    def create_optimized_image_actor(self, image_data):
        """
        Create an optimized VTK image actor for displaying large images.
        
        Args:
            image_data (numpy.ndarray): Image data
            
        Returns:
            vtkImageActor: VTK image actor
        """
        if image_data is None:
            return None
        
        try:
            # Check if image needs optimization
            shape = image_data.shape
            max_dim = max(shape[:2])  # Consider only first two dimensions
            
            if max_dim > self.max_texture_size:
                # Use tiled approach for very large images
                if max_dim > 2 * self.max_texture_size:
                    logger.info(f"Image too large ({max_dim}), using tiled approach")
                    return self._create_tiled_image_actor(image_data)
                
                # Otherwise just resize
                logger.info(f"Resizing image from {shape} to fit texture size {self.max_texture_size}")
                image_data = self.optimize_texture_size(image_data)
            
            # Convert image data to VTK image data
            vtk_image = self._numpy_to_vtk_image(image_data)
            
            # Create image actor
            actor = vtk.vtkImageActor()
            actor.SetInputData(vtk_image)
            actor.InterpolateOn()
            
            return actor
        except Exception as e:
            logger.error(f"Error creating optimized image actor: {str(e)}")
            return None
    
    def _create_tiled_image_actor(self, image_data):
        """
        Create a tiled image actor for very large images.
        
        Args:
            image_data (numpy.ndarray): Image data
            
        Returns:
            vtkAssembly: Assembly of image actors
        """
        shape = image_data.shape
        
        # Calculate number of tiles needed
        tiles_x = (shape[1] + self.max_texture_size - 1) // self.max_texture_size
        tiles_y = (shape[0] + self.max_texture_size - 1) // self.max_texture_size
        
        # Create assembly to hold all tile actors
        assembly = vtk.vtkAssembly()
        
        # Create tiles
        for ty in range(tiles_y):
            for tx in range(tiles_x):
                # Calculate tile bounds
                x0 = tx * self.max_texture_size
                y0 = ty * self.max_texture_size
                x1 = min(x0 + self.max_texture_size, shape[1])
                y1 = min(y0 + self.max_texture_size, shape[0])
                
                # Extract tile data
                if len(shape) == 2:
                    tile_data = image_data[y0:y1, x0:x1]
                else:
                    tile_data = image_data[y0:y1, x0:x1, :]
                
                # Convert to VTK image
                vtk_image = self._numpy_to_vtk_image(tile_data)
                
                # Create actor for this tile
                actor = vtk.vtkImageActor()
                actor.SetInputData(vtk_image)
                actor.InterpolateOn()
                
                # Position the tile correctly
                actor.SetPosition(x0, y0, 0)
                
                # Add to assembly
                assembly.AddPart(actor)
        
        return assembly
    
    def _numpy_to_vtk_image(self, numpy_array):
        """
        Convert a numpy array to a VTK image data object.
        
        Args:
            numpy_array (numpy.ndarray): Numpy array
            
        Returns:
            vtkImageData: VTK image data
        """
        # Get array shape and data type
        shape = numpy_array.shape
        dtype = numpy_array.dtype
        
        # Create VTK image data
        vtk_image = vtk.vtkImageData()
        
        # Set dimensions
        if len(shape) == 2:
            # 2D grayscale image
            vtk_image.SetDimensions(shape[1], shape[0], 1)
            num_components = 1
        elif len(shape) == 3 and shape[2] <= 4:
            # 2D color image (RGB or RGBA)
            vtk_image.SetDimensions(shape[1], shape[0], 1)
            num_components = shape[2]
        else:
            # 3D volume
            vtk_image.SetDimensions(shape[2], shape[1], shape[0])
            num_components = 1
        
        # Set data type
        vtk_type = vtk.VTK_UNSIGNED_CHAR
        if dtype == np.uint8:
            vtk_type = vtk.VTK_UNSIGNED_CHAR
        elif dtype == np.int16:
            vtk_type = vtk.VTK_SHORT
        elif dtype == np.uint16:
            vtk_type = vtk.VTK_UNSIGNED_SHORT
        elif dtype == np.int32:
            vtk_type = vtk.VTK_INT
        elif dtype == np.float32:
            vtk_type = vtk.VTK_FLOAT
        elif dtype == np.float64:
            vtk_type = vtk.VTK_DOUBLE
        
        # Allocate scalars
        vtk_image.AllocateScalars(vtk_type, num_components)
        
        # Get pointer to data and copy
        memory_size = numpy_array.size * numpy_array.itemsize
        raw_ptr = vtk_image.GetScalarPointer()
        
        # Use numpy's buffer interface for efficient copy
        vtk_array = numpy_array
        if num_components > 1 and len(shape) == 3:
            # For color images, ensure correct memory layout
            vtk_array = numpy_array.reshape((-1, num_components))
        elif len(shape) == 3 and num_components == 1:
            # For volumes, ensure correct memory layout
            vtk_array = numpy_array.reshape(-1)
        
        # Create a VTK array and copy data
        vtk_data_array = vtk.vtkDataArray.CreateDataArray(vtk_type)
        vtk_data_array.SetNumberOfComponents(num_components)
        vtk_data_array.SetNumberOfTuples(vtk_array.shape[0])
        
        # Use numpy interface for efficient copy
        vtk_data_array.SetVoidArray(vtk_array, vtk_array.size, 1)
        
        # Set the scalars
        vtk_image.GetPointData().SetScalars(vtk_data_array)
        
        return vtk_image


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    optimizer = TextureOptimizer()
    
    # Print OpenGL info
    print(f"OpenGL Vendor: {optimizer.gl_vendor}")
    print(f"OpenGL Renderer: {optimizer.gl_renderer}")
    print(f"OpenGL Version: {optimizer.gl_version}")
    print(f"Max Texture Size: {optimizer.max_texture_size}")
    
    # Test with a sample image
    try:
        import matplotlib.pyplot as plt
        
        # Create a test image larger than typical texture limits
        test_size = 8192
        print(f"Creating test image of size {test_size}x{test_size}")
        test_image = np.zeros((test_size, test_size), dtype=np.uint8)
        
        # Add some pattern
        x, y = np.meshgrid(np.linspace(0, 255, test_size), np.linspace(0, 255, test_size))
        test_image = (np.sin(x/100) * np.cos(y/100) * 128 + 128).astype(np.uint8)
        
        # Optimize texture
        print("Optimizing texture...")
        optimized_image = optimizer.optimize_texture_size(test_image)
        
        print(f"Original shape: {test_image.shape}")
        print(f"Optimized shape: {optimized_image.shape}")
        
        # Save a small section for visualization
        plt.figure(figsize=(10, 5))
        plt.subplot(1, 2, 1)
        plt.imshow(test_image[:1000, :1000], cmap='gray')
        plt.title("Original (section)")
        plt.subplot(1, 2, 2)
        plt.imshow(optimized_image[:1000, :1000], cmap='gray')
        plt.title("Optimized (section)")
        plt.savefig("texture_optimization_test.png")
        print("Test image saved as texture_optimization_test.png")
    except ImportError:
        print("matplotlib not available, skipping visualization test")
