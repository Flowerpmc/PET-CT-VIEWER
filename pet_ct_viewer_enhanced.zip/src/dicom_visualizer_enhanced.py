#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Enhanced DICOM Visualization Module for PET/CT Viewer
--------------------------------------------------
This module provides visualization capabilities for PET/CT DICOM images with
optimized texture handling and improved rendering performance.
"""

import os
import sys
import logging
import numpy as np
import vtk
from texture_optimizer import TextureOptimizer

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('DicomVisualizer')

class DicomVisualizer:
    """
    Class for visualizing DICOM images with optimized rendering.
    """
    
    # Constants for modality types
    PET = 0
    CT = 1
    FUSION = 2
    
    # Constants for orientation
    AXIAL = 0
    CORONAL = 1
    SAGITTAL = 2
    
    def __init__(self):
        """Initialize the DicomVisualizer."""
        self.pet_volume = None
        self.ct_volume = None
        self.fusion_volume = None
        
        self.pet_dimensions = None
        self.ct_dimensions = None
        self.fusion_dimensions = None
        
        self.pet_spacing = None
        self.ct_spacing = None
        self.fusion_spacing = None
        
        # Initialize texture optimizer
        self.texture_optimizer = TextureOptimizer()
        
        # Initialize color maps
        self.pet_color_map = self._create_pet_color_map()
        self.ct_color_map = self._create_ct_color_map()
        self.fusion_color_map = self._create_fusion_color_map()
        
        # Initialize lookup tables
        self.pet_lut = self._create_pet_lut()
        self.ct_lut = self._create_ct_lut()
        self.fusion_lut = self._create_fusion_lut()
        
        # Initialize window/level values
        self.pet_window = 6.0
        self.pet_level = 3.0
        self.ct_window = 400.0
        self.ct_level = 40.0
        
        # Initialize orientation matrices
        self.orientation_matrices = self._create_orientation_matrices()
    
    def set_pet_data(self, array, spacing=(1.0, 1.0, 1.0)):
        """
        Set PET volume data.
        
        Args:
            array (numpy.ndarray): 3D array of PET data
            spacing (tuple): Voxel spacing (x, y, z)
        """
        if array is None:
            logger.warning("PET array is None")
            return
        
        try:
            # Store dimensions and spacing
            self.pet_dimensions = array.shape
            self.pet_spacing = spacing
            
            # Create VTK image data
            self.pet_volume = self._create_vtk_volume(array, spacing)
            
            logger.info(f"PET data set with dimensions {self.pet_dimensions}")
        except Exception as e:
            logger.error(f"Error setting PET data: {str(e)}")
    
    def set_ct_data(self, array, spacing=(1.0, 1.0, 1.0)):
        """
        Set CT volume data.
        
        Args:
            array (numpy.ndarray): 3D array of CT data
            spacing (tuple): Voxel spacing (x, y, z)
        """
        if array is None:
            logger.warning("CT array is None")
            return
        
        try:
            # Store dimensions and spacing
            self.ct_dimensions = array.shape
            self.ct_spacing = spacing
            
            # Create VTK image data
            self.ct_volume = self._create_vtk_volume(array, spacing)
            
            logger.info(f"CT data set with dimensions {self.ct_dimensions}")
        except Exception as e:
            logger.error(f"Error setting CT data: {str(e)}")
    
    def set_fusion_data(self, array, spacing=(1.0, 1.0, 1.0)):
        """
        Set fusion volume data.
        
        Args:
            array (numpy.ndarray): 3D array of fusion data
            spacing (tuple): Voxel spacing (x, y, z)
        """
        if array is None:
            logger.warning("Fusion array is None")
            return
        
        try:
            # Store dimensions and spacing
            self.fusion_dimensions = array.shape
            self.fusion_spacing = spacing
            
            # Create VTK image data
            self.fusion_volume = self._create_vtk_volume(array, spacing)
            
            logger.info(f"Fusion data set with dimensions {self.fusion_dimensions}")
        except Exception as e:
            logger.error(f"Error setting fusion data: {str(e)}")
    
    def create_fusion_from_pet_ct(self):
        """
        Create fusion volume from PET and CT data.
        
        Returns:
            bool: True if fusion was created successfully, False otherwise
        """
        if self.pet_volume is None or self.ct_volume is None:
            logger.warning("Cannot create fusion: PET or CT data missing")
            return False
        
        try:
            # Check if dimensions match
            if self.pet_dimensions != self.ct_dimensions:
                logger.warning(f"PET dimensions {self.pet_dimensions} do not match CT dimensions {self.ct_dimensions}")
                logger.info("Resampling CT to match PET dimensions")
                
                # Resample CT to match PET
                resampled_ct = self._resample_volume(self.ct_volume, self.pet_dimensions, self.pet_spacing)
                
                # Create fusion using resampled CT
                fusion = self._create_fusion_volume(self.pet_volume, resampled_ct)
            else:
                # Create fusion directly
                fusion = self._create_fusion_volume(self.pet_volume, self.ct_volume)
            
            # Set fusion data
            self.fusion_volume = fusion
            self.fusion_dimensions = self.pet_dimensions
            self.fusion_spacing = self.pet_spacing
            
            logger.info(f"Fusion data created with dimensions {self.fusion_dimensions}")
            return True
        except Exception as e:
            logger.error(f"Error creating fusion: {str(e)}")
            return False
    
    def _create_vtk_volume(self, array, spacing):
        """
        Create a VTK volume from a numpy array.
        
        Args:
            array (numpy.ndarray): 3D array of volume data
            spacing (tuple): Voxel spacing (x, y, z)
            
        Returns:
            vtkImageData: VTK image data
        """
        # Check if array exceeds texture size limits
        max_dim = max(array.shape)
        if max_dim > self.texture_optimizer.max_texture_size:
            logger.warning(f"Volume dimension {max_dim} exceeds max texture size {self.texture_optimizer.max_texture_size}")
            logger.info("Using optimized texture handling")
        
        # Create VTK image data
        vtk_image = vtk.vtkImageData()
        
        # Set dimensions
        vtk_image.SetDimensions(array.shape[2], array.shape[1], array.shape[0])
        
        # Set spacing
        vtk_image.SetSpacing(spacing)
        
        # Set origin to center of volume
        origin_x = -spacing[0] * array.shape[2] / 2
        origin_y = -spacing[1] * array.shape[1] / 2
        origin_z = -spacing[2] * array.shape[0] / 2
        vtk_image.SetOrigin(origin_x, origin_y, origin_z)
        
        # Determine VTK data type
        vtk_type = vtk.VTK_FLOAT
        if array.dtype == np.uint8:
            vtk_type = vtk.VTK_UNSIGNED_CHAR
        elif array.dtype == np.int16:
            vtk_type = vtk.VTK_SHORT
        elif array.dtype == np.uint16:
            vtk_type = vtk.VTK_UNSIGNED_SHORT
        elif array.dtype == np.int32:
            vtk_type = vtk.VTK_INT
        elif array.dtype == np.float32:
            vtk_type = vtk.VTK_FLOAT
        elif array.dtype == np.float64:
            vtk_type = vtk.VTK_DOUBLE
        
        # Allocate scalars
        vtk_image.AllocateScalars(vtk_type, 1)
        
        # Get pointer to data and copy
        vtk_array = vtk.util.numpy_support.numpy_to_vtk(
            array.ravel(), deep=True, array_type=vtk_type)
        vtk_image.GetPointData().SetScalars(vtk_array)
        
        return vtk_image
    
    def _resample_volume(self, volume, target_dimensions, target_spacing):
        """
        Resample a volume to match target dimensions and spacing.
        
        Args:
            volume (vtkImageData): Volume to resample
            target_dimensions (tuple): Target dimensions
            target_spacing (tuple): Target spacing
            
        Returns:
            vtkImageData: Resampled volume
        """
        # Create resampling filter
        resample = vtk.vtkImageResample()
        resample.SetInputData(volume)
        
        # Set output dimensions
        resample.SetOutputDimensions(
            target_dimensions[2], target_dimensions[1], target_dimensions[0])
        
        # Set output spacing
        resample.SetOutputSpacing(target_spacing)
        
        # Use linear interpolation
        resample.SetInterpolationModeToLinear()
        
        # Update filter
        resample.Update()
        
        return resample.GetOutput()
    
    def _create_fusion_volume(self, pet_volume, ct_volume):
        """
        Create a fusion volume from PET and CT volumes.
        
        Args:
            pet_volume (vtkImageData): PET volume
            ct_volume (vtkImageData): CT volume
            
        Returns:
            vtkImageData: Fusion volume
        """
        # Create blend filter
        blend = vtk.vtkImageBlend()
        blend.AddInputData(ct_volume)
        blend.AddInputData(pet_volume)
        
        # Set blend mode
        blend.SetBlendModeToCompound()
        
        # Set opacity for each input
        blend.SetOpacity(0, 0.6)  # CT
        blend.SetOpacity(1, 0.4)  # PET
        
        # Update filter
        blend.Update()
        
        return blend.GetOutput()
    
    def create_slice_actor(self, modality, orientation, slice_index):
        """
        Create a VTK actor for displaying a slice.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            orientation (int): Orientation (AXIAL, CORONAL, or SAGITTAL)
            slice_index (int): Slice index
            
        Returns:
            vtkActor: VTK actor for the slice
        """
        # Get volume based on modality
        volume = None
        lut = None
        if modality == self.PET:
            volume = self.pet_volume
            lut = self.pet_lut
        elif modality == self.CT:
            volume = self.ct_volume
            lut = self.ct_lut
        elif modality == self.FUSION:
            volume = self.fusion_volume
            lut = self.fusion_lut
        
        if volume is None:
            logger.warning(f"No volume data for modality {modality}")
            return None
        
        try:
            # Create slice with correct orientation
            reslice = vtk.vtkImageReslice()
            reslice.SetInputData(volume)
            reslice.SetOutputDimensionality(2)
            
            # Set slice orientation
            reslice.SetResliceAxes(self.orientation_matrices[orientation])
            
            # Set slice position
            dimensions = volume.GetDimensions()
            spacing = volume.GetSpacing()
            origin = volume.GetOrigin()
            
            if orientation == self.AXIAL:
                max_slice = dimensions[2] - 1
                if slice_index < 0 or slice_index > max_slice:
                    slice_index = max_slice // 2
                position = origin[2] + slice_index * spacing[2]
                reslice.SetResliceAxesOrigin(0, 0, position)
            elif orientation == self.CORONAL:
                max_slice = dimensions[1] - 1
                if slice_index < 0 or slice_index > max_slice:
                    slice_index = max_slice // 2
                position = origin[1] + slice_index * spacing[1]
                reslice.SetResliceAxesOrigin(0, position, 0)
            else:  # SAGITTAL
                max_slice = dimensions[0] - 1
                if slice_index < 0 or slice_index > max_slice:
                    slice_index = max_slice // 2
                position = origin[0] + slice_index * spacing[0]
                reslice.SetResliceAxesOrigin(position, 0, 0)
            
            # Use linear interpolation
            reslice.SetInterpolationModeToLinear()
            
            # Update filter
            reslice.Update()
            
            # Get slice image
            slice_image = reslice.GetOutput()
            
            # Create mapper
            mapper = vtk.vtkImageMapToColors()
            mapper.SetInputData(slice_image)
            mapper.SetLookupTable(lut)
            
            # Optimize mapper
            self.texture_optimizer.optimize_vtk_mapper(mapper)
            
            # Create actor
            actor = vtk.vtkImageActor()
            actor.GetMapper().SetInputConnection(mapper.GetOutputPort())
            
            return actor
        except Exception as e:
            logger.error(f"Error creating slice actor: {str(e)}")
            return None
    
    def create_mip_actor(self, modality):
        """
        Create a VTK actor for displaying a Maximum Intensity Projection (MIP).
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            
        Returns:
            vtkActor: VTK actor for the MIP
        """
        # Get volume based on modality
        volume = None
        lut = None
        if modality == self.PET:
            volume = self.pet_volume
            lut = self.pet_lut
        elif modality == self.CT:
            volume = self.ct_volume
            lut = self.ct_lut
        elif modality == self.FUSION:
            volume = self.fusion_volume
            lut = self.fusion_lut
        
        if volume is None:
            logger.warning(f"No volume data for modality {modality}")
            return None
        
        try:
            # Create volume mapper
            mapper = vtk.vtkSmartVolumeMapper()
            mapper.SetInputData(volume)
            
            # Set blend mode to MIP
            mapper.SetBlendModeToMaximumIntensity()
            
            # Optimize mapper
            self.texture_optimizer.optimize_vtk_mapper(mapper)
            
            # Create volume property
            property = vtk.vtkVolumeProperty()
            property.SetInterpolationTypeToLinear()
            property.ShadeOff()
            
            # Set color transfer function
            color_function = vtk.vtkColorTransferFunction()
            if modality == self.PET:
                # PET color function (hot metal)
                color_function.AddRGBPoint(0, 0, 0, 0)
                color_function.AddRGBPoint(1, 0.5, 0, 0)
                color_function.AddRGBPoint(2, 0.9, 0.2, 0)
                color_function.AddRGBPoint(3, 1, 0.5, 0)
                color_function.AddRGBPoint(4, 1, 0.8, 0.2)
                color_function.AddRGBPoint(5, 1, 1, 0.5)
                color_function.AddRGBPoint(6, 1, 1, 1)
            elif modality == self.CT:
                # CT color function (grayscale)
                color_function.AddRGBPoint(-1000, 0, 0, 0)
                color_function.AddRGBPoint(0, 0.5, 0.5, 0.5)
                color_function.AddRGBPoint(1000, 1, 1, 1)
            else:
                # Fusion color function
                color_function.AddRGBPoint(0, 0, 0, 0)
                color_function.AddRGBPoint(500, 0.5, 0.5, 0.5)
                color_function.AddRGBPoint(1000, 0.9, 0.9, 0.9)
                color_function.AddRGBPoint(1500, 1, 0.8, 0.2)
                color_function.AddRGBPoint(2000, 1, 0.5, 0)
                color_function.AddRGBPoint(2500, 1, 0, 0)
            
            property.SetColor(color_function)
            
            # Set opacity transfer function
            opacity_function = vtk.vtkPiecewiseFunction()
            opacity_function.AddPoint(0, 0)
            opacity_function.AddPoint(500, 0.2)
            opacity_function.AddPoint(1000, 0.4)
            opacity_function.AddPoint(1500, 0.6)
            opacity_function.AddPoint(2000, 0.8)
            opacity_function.AddPoint(2500, 1.0)
            
            property.SetScalarOpacity(opacity_function)
            
            # Create volume
            volume_actor = vtk.vtkVolume()
            volume_actor.SetMapper(mapper)
            volume_actor.SetProperty(property)
            
            # Optimize volume
            self.texture_optimizer.optimize_vtk_volume(volume_actor)
            
            return volume_actor
        except Exception as e:
            logger.error(f"Error creating MIP actor: {str(e)}")
            return None
    
    def get_slice_count(self, modality, orientation):
        """
        Get the number of slices for a specific modality and orientation.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            orientation (int): Orientation (AXIAL, CORONAL, or SAGITTAL)
            
        Returns:
            int: Number of slices
        """
        # Get dimensions based on modality
        dimensions = None
        if modality == self.PET and self.pet_volume is not None:
            dimensions = self.pet_volume.GetDimensions()
        elif modality == self.CT and self.ct_volume is not None:
            dimensions = self.ct_volume.GetDimensions()
        elif modality == self.FUSION and self.fusion_volume is not None:
            dimensions = self.fusion_volume.GetDimensions()
        
        if dimensions is None:
            return 0
        
        # Return slice count based on orientation
        if orientation == self.AXIAL:
            return dimensions[2]
        elif orientation == self.CORONAL:
            return dimensions[1]
        else:  # SAGITTAL
            return dimensions[0]
    
    def set_window_level(self, modality, window, level):
        """
        Set window/level values for a specific modality.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            window (float): Window value
            level (float): Level value
        """
        if modality == self.PET:
            self.pet_window = window
            self.pet_level = level
            self._update_pet_lut()
        elif modality == self.CT:
            self.ct_window = window
            self.ct_level = level
            self._update_ct_lut()
        elif modality == self.FUSION:
            # For fusion, we update both PET and CT
            self.pet_window = window
            self.pet_level = level
            self.ct_window = window
            self.ct_level = level
            self._update_pet_lut()
            self._update_ct_lut()
            self._update_fusion_lut()
    
    def set_pet_colormap(self, colormap_name):
        """
        Set the colormap for PET images.
        
        Args:
            colormap_name (str): Name of the colormap
        """
        self.pet_color_map = self._create_colormap(colormap_name)
        self._update_pet_lut()
    
    def set_ct_colormap(self, colormap_name):
        """
        Set the colormap for CT images.
        
        Args:
            colormap_name (str): Name of the colormap
        """
        self.ct_color_map = self._create_colormap(colormap_name)
        self._update_ct_lut()
    
    def set_fusion_colormap(self, colormap_name):
        """
        Set the colormap for fusion images.
        
        Args:
            colormap_name (str): Name of the colormap
        """
        self.fusion_color_map = self._create_colormap(colormap_name)
        self._update_fusion_lut()
    
    def _create_pet_color_map(self):
        """
        Create the default color map for PET images.
        
        Returns:
            list: List of (value, r, g, b) tuples
        """
        # Hot metal color map
        return [
            (0.0, 0, 0, 0),      # Black
            (0.2, 0.5, 0, 0),    # Dark red
            (0.4, 0.9, 0.2, 0),  # Red-orange
            (0.6, 1, 0.5, 0),    # Orange
            (0.8, 1, 0.8, 0.2),  # Yellow-orange
            (1.0, 1, 1, 1)       # White
        ]
    
    def _create_ct_color_map(self):
        """
        Create the default color map for CT images.
        
        Returns:
            list: List of (value, r, g, b) tuples
        """
        # Grayscale color map
        return [
            (0.0, 0, 0, 0),      # Black
            (1.0, 1, 1, 1)       # White
        ]
    
    def _create_fusion_color_map(self):
        """
        Create the default color map for fusion images.
        
        Returns:
            list: List of (value, r, g, b) tuples
        """
        # Custom fusion color map
        return [
            (0.0, 0, 0, 0),      # Black
            (0.2, 0.5, 0.5, 0.5), # Gray
            (0.4, 0.9, 0.9, 0.9), # Light gray
            (0.6, 1, 0.8, 0.2),  # Yellow-orange
            (0.8, 1, 0.5, 0),    # Orange
            (1.0, 1, 0, 0)       # Red
        ]
    
    def _create_colormap(self, name):
        """
        Create a color map by name.
        
        Args:
            name (str): Name of the color map
            
        Returns:
            list: List of (value, r, g, b) tuples
        """
        if name.lower() == "grayscale":
            return [
                (0.0, 0, 0, 0),
                (1.0, 1, 1, 1)
            ]
        elif name.lower() == "hot metal":
            return [
                (0.0, 0, 0, 0),
                (0.2, 0.5, 0, 0),
                (0.4, 0.9, 0.2, 0),
                (0.6, 1, 0.5, 0),
                (0.8, 1, 0.8, 0.2),
                (1.0, 1, 1, 1)
            ]
        elif name.lower() == "rainbow":
            return [
                (0.0, 0, 0, 1),    # Blue
                (0.25, 0, 1, 1),   # Cyan
                (0.5, 0, 1, 0),    # Green
                (0.75, 1, 1, 0),   # Yellow
                (1.0, 1, 0, 0)     # Red
            ]
        elif name.lower() == "jet":
            return [
                (0.0, 0, 0, 0.5),
                (0.1, 0, 0, 1),
                (0.3, 0, 1, 1),
                (0.5, 0, 1, 0),
                (0.7, 1, 1, 0),
                (0.9, 1, 0, 0),
                (1.0, 0.5, 0, 0)
            ]
        elif name.lower() == "bone":
            return [
                (0.0, 0, 0, 0),
                (0.4, 0.3, 0.3, 0.3),
                (0.7, 0.7, 0.7, 0.7),
                (1.0, 1, 1, 1)
            ]
        elif name.lower() == "hot":
            return [
                (0.0, 0, 0, 0),
                (0.3, 1, 0, 0),
                (0.6, 1, 1, 0),
                (1.0, 1, 1, 1)
            ]
        else:
            # Default to grayscale
            return [
                (0.0, 0, 0, 0),
                (1.0, 1, 1, 1)
            ]
    
    def _create_pet_lut(self):
        """
        Create a lookup table for PET images.
        
        Returns:
            vtkLookupTable: VTK lookup table
        """
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(256)
        lut.SetRange(self.pet_level - self.pet_window/2, self.pet_level + self.pet_window/2)
        lut.SetRampToLinear()
        
        # Set colors from color map
        for i, (value, r, g, b) in enumerate(self.pet_color_map):
            index = int(value * 255)
            lut.SetTableValue(index, r, g, b, 1.0)
        
        # Interpolate intermediate colors
        lut.Build()
        
        return lut
    
    def _create_ct_lut(self):
        """
        Create a lookup table for CT images.
        
        Returns:
            vtkLookupTable: VTK lookup table
        """
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(256)
        lut.SetRange(self.ct_level - self.ct_window/2, self.ct_level + self.ct_window/2)
        lut.SetRampToLinear()
        
        # Set colors from color map
        for i, (value, r, g, b) in enumerate(self.ct_color_map):
            index = int(value * 255)
            lut.SetTableValue(index, r, g, b, 1.0)
        
        # Interpolate intermediate colors
        lut.Build()
        
        return lut
    
    def _create_fusion_lut(self):
        """
        Create a lookup table for fusion images.
        
        Returns:
            vtkLookupTable: VTK lookup table
        """
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(256)
        
        # For fusion, we use a wider range
        fusion_level = (self.pet_level + self.ct_level) / 2
        fusion_window = (self.pet_window + self.ct_window) / 2
        lut.SetRange(fusion_level - fusion_window/2, fusion_level + fusion_window/2)
        lut.SetRampToLinear()
        
        # Set colors from color map
        for i, (value, r, g, b) in enumerate(self.fusion_color_map):
            index = int(value * 255)
            lut.SetTableValue(index, r, g, b, 1.0)
        
        # Interpolate intermediate colors
        lut.Build()
        
        return lut
    
    def _update_pet_lut(self):
        """Update the PET lookup table with current window/level values."""
        if self.pet_lut is not None:
            self.pet_lut.SetRange(self.pet_level - self.pet_window/2, self.pet_level + self.pet_window/2)
            self.pet_lut.Build()
    
    def _update_ct_lut(self):
        """Update the CT lookup table with current window/level values."""
        if self.ct_lut is not None:
            self.ct_lut.SetRange(self.ct_level - self.ct_window/2, self.ct_level + self.ct_window/2)
            self.ct_lut.Build()
    
    def _update_fusion_lut(self):
        """Update the fusion lookup table with current window/level values."""
        if self.fusion_lut is not None:
            fusion_level = (self.pet_level + self.ct_level) / 2
            fusion_window = (self.pet_window + self.ct_window) / 2
            self.fusion_lut.SetRange(fusion_level - fusion_window/2, fusion_level + fusion_window/2)
            self.fusion_lut.Build()
    
    def _create_orientation_matrices(self):
        """
        Create orientation matrices for different view orientations.
        
        Returns:
            list: List of vtkMatrix4x4 objects for each orientation
        """
        # Create matrices
        axial = vtk.vtkMatrix4x4()
        coronal = vtk.vtkMatrix4x4()
        sagittal = vtk.vtkMatrix4x4()
        
        # Set axial orientation (XY plane, Z points up)
        axial.Identity()
        
        # Set coronal orientation (XZ plane, Y points up)
        coronal.Identity()
        coronal.SetElement(1, 1, 0)
        coronal.SetElement(1, 2, 1)
        coronal.SetElement(2, 1, 1)
        coronal.SetElement(2, 2, 0)
        
        # Set sagittal orientation (YZ plane, X points up)
        sagittal.Identity()
        sagittal.SetElement(0, 0, 0)
        sagittal.SetElement(0, 2, 1)
        sagittal.SetElement(2, 0, 1)
        sagittal.SetElement(2, 2, 0)
        
        return [axial, coronal, sagittal]
    
    def create_color_bar_actor(self, modality, width=20, height=200):
        """
        Create a color bar actor for displaying the color scale.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            width (int): Width of the color bar
            height (int): Height of the color bar
            
        Returns:
            vtkActor: VTK actor for the color bar
        """
        # Get lookup table based on modality
        lut = None
        if modality == self.PET:
            lut = self.pet_lut
        elif modality == self.CT:
            lut = self.ct_lut
        elif modality == self.FUSION:
            lut = self.fusion_lut
        
        if lut is None:
            logger.warning(f"No lookup table for modality {modality}")
            return None
        
        try:
            # Create color bar
            color_bar = vtk.vtkScalarBarActor()
            color_bar.SetLookupTable(lut)
            color_bar.SetWidth(0.1)
            color_bar.SetHeight(0.8)
            color_bar.SetPosition(0.9, 0.1)
            color_bar.SetLabelFormat("%.1f")
            color_bar.SetNumberOfLabels(5)
            color_bar.SetOrientationToVertical()
            
            # Set title based on modality
            if modality == self.PET:
                color_bar.SetTitle("SUV")
            elif modality == self.CT:
                color_bar.SetTitle("HU")
            else:
                color_bar.SetTitle("Value")
            
            # Customize text properties
            title_prop = color_bar.GetTitleTextProperty()
            title_prop.SetColor(1, 1, 1)
            title_prop.SetFontSize(12)
            title_prop.SetBold(True)
            
            label_prop = color_bar.GetLabelTextProperty()
            label_prop.SetColor(1, 1, 1)
            label_prop.SetFontSize(10)
            
            return color_bar
        except Exception as e:
            logger.error(f"Error creating color bar actor: {str(e)}")
            return None
    
    def adjust_orientation(self, orientation_matrix):
        """
        Adjust the orientation of all volumes.
        
        Args:
            orientation_matrix (vtkMatrix4x4): Orientation matrix
            
        Returns:
            bool: True if orientation was adjusted successfully, False otherwise
        """
        if orientation_matrix is None:
            logger.warning("Orientation matrix is None")
            return False
        
        try:
            # Create transform
            transform = vtk.vtkTransform()
            transform.SetMatrix(orientation_matrix)
            
            # Apply transform to volumes
            if self.pet_volume is not None:
                transformer = vtk.vtkImageReslice()
                transformer.SetInputData(self.pet_volume)
                transformer.SetResliceTransform(transform)
                transformer.SetInterpolationModeToLinear()
                transformer.Update()
                self.pet_volume = transformer.GetOutput()
            
            if self.ct_volume is not None:
                transformer = vtk.vtkImageReslice()
                transformer.SetInputData(self.ct_volume)
                transformer.SetResliceTransform(transform)
                transformer.SetInterpolationModeToLinear()
                transformer.Update()
                self.ct_volume = transformer.GetOutput()
            
            if self.fusion_volume is not None:
                transformer = vtk.vtkImageReslice()
                transformer.SetInputData(self.fusion_volume)
                transformer.SetResliceTransform(transform)
                transformer.SetInterpolationModeToLinear()
                transformer.Update()
                self.fusion_volume = transformer.GetOutput()
            
            # Update orientation matrices
            self.orientation_matrices = self._create_orientation_matrices()
            
            return True
        except Exception as e:
            logger.error(f"Error adjusting orientation: {str(e)}")
            return False
    
    def create_standard_orientation(self):
        """
        Adjust volumes to standard radiological orientation.
        
        Returns:
            bool: True if orientation was standardized successfully, False otherwise
        """
        try:
            # Create standard orientation matrix (radiological convention)
            matrix = vtk.vtkMatrix4x4()
            matrix.Identity()
            
            # Set to RAI orientation (Right-Anterior-Inferior)
            # X increases from patient right to left
            # Y increases from patient posterior to anterior
            # Z increases from patient inferior to superior
            matrix.SetElement(0, 0, -1)  # Flip X
            
            return self.adjust_orientation(matrix)
        except Exception as e:
            logger.error(f"Error creating standard orientation: {str(e)}")
            return False


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    visualizer = DicomVisualizer()
    
    # Print OpenGL info from texture optimizer
    print(f"OpenGL Vendor: {visualizer.texture_optimizer.gl_vendor}")
    print(f"OpenGL Renderer: {visualizer.texture_optimizer.gl_renderer}")
    print(f"OpenGL Version: {visualizer.texture_optimizer.gl_version}")
    print(f"Max Texture Size: {visualizer.texture_optimizer.max_texture_size}")
    
    # Test with a sample volume
    try:
        import matplotlib.pyplot as plt
        
        # Create a test volume
        test_size = 64
        print(f"Creating test volume of size {test_size}x{test_size}x{test_size}")
        
        # Create PET-like volume
        pet_volume = np.zeros((test_size, test_size, test_size), dtype=np.float32)
        for z in range(test_size):
            for y in range(test_size):
                for x in range(test_size):
                    # Create a sphere
                    dx = x - test_size/2
                    dy = y - test_size/2
                    dz = z - test_size/2
                    distance = np.sqrt(dx*dx + dy*dy + dz*dz)
                    if distance < test_size/4:
                        pet_volume[z, y, x] = 5.0 * (1.0 - distance/(test_size/4))
        
        # Create CT-like volume
        ct_volume = np.zeros((test_size, test_size, test_size), dtype=np.int16)
        for z in range(test_size):
            for y in range(test_size):
                for x in range(test_size):
                    # Create a cylinder
                    dx = x - test_size/2
                    dy = y - test_size/2
                    distance = np.sqrt(dx*dx + dy*dy)
                    if distance < test_size/3:
                        ct_volume[z, y, x] = 100
                    else:
                        ct_volume[z, y, x] = -1000
        
        # Set volumes in visualizer
        visualizer.set_pet_data(pet_volume)
        visualizer.set_ct_data(ct_volume)
        
        # Create fusion
        visualizer.create_fusion_from_pet_ct()
        
        print("Volumes created and fusion generated")
    except ImportError:
        print("matplotlib not available, skipping visualization test")
