#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Quantification Module for PET/CT Viewer
--------------------------------------
This module provides tools for quantitative analysis of PET/CT images,
including measurement, SUV calculation, and volume analysis.
"""

import os
import sys
import logging
import numpy as np
import vtk
from vtk.util import numpy_support
import math

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('DicomQuantification')

class MeasurementTool:
    """
    Class for performing measurements on DICOM images.
    Includes distance, area, angle, and SUV measurements.
    """
    
    # Measurement types
    DISTANCE = 0
    AREA_CIRCLE = 1
    AREA_ELLIPSE = 2
    AREA_FREEHAND = 3
    ANGLE = 4
    POINT_VALUE = 5
    
    def __init__(self, renderer=None):
        """
        Initialize the MeasurementTool.
        
        Args:
            renderer (vtkRenderer, optional): VTK renderer for visualization
        """
        self.renderer = renderer
        self.current_measurement = None
        self.measurement_type = None
        self.points = []
        self.actors = []
        self.measurements = []  # List to store all measurements
        
        # Create VTK objects for rendering
        self.point_placer = vtk.vtkPointPlacer()
        self.distance_widget = None
        self.angle_widget = None
        self.contour_widget = None
        
    def set_renderer(self, renderer):
        """Set the VTK renderer for visualization."""
        self.renderer = renderer
        
    def start_measurement(self, measurement_type):
        """
        Start a new measurement.
        
        Args:
            measurement_type (int): Type of measurement to perform
            
        Returns:
            bool: True if measurement started successfully, False otherwise
        """
        if self.renderer is None:
            logger.warning("Cannot start measurement: renderer not set")
            return False
        
        # Clear previous measurement
        self.clear_current_measurement()
        
        self.measurement_type = measurement_type
        self.points = []
        
        try:
            if measurement_type == self.DISTANCE:
                self._setup_distance_measurement()
            elif measurement_type in [self.AREA_CIRCLE, self.AREA_ELLIPSE]:
                self._setup_area_measurement()
            elif measurement_type == self.AREA_FREEHAND:
                self._setup_freehand_measurement()
            elif measurement_type == self.ANGLE:
                self._setup_angle_measurement()
            elif measurement_type == self.POINT_VALUE:
                self._setup_point_measurement()
            else:
                logger.error(f"Invalid measurement type: {measurement_type}")
                return False
            
            return True
        except Exception as e:
            logger.error(f"Error starting measurement: {str(e)}")
            return False
    
    def _setup_distance_measurement(self):
        """Setup for distance measurement."""
        self.distance_widget = vtk.vtkDistanceWidget()
        self.distance_widget.SetInteractor(self.renderer.GetRenderWindow().GetInteractor())
        
        distance_representation = vtk.vtkDistanceRepresentation2D()
        self.distance_widget.SetRepresentation(distance_representation)
        
        self.distance_widget.On()
    
    def _setup_area_measurement(self):
        """Setup for circular or elliptical area measurement."""
        self.contour_widget = vtk.vtkContourWidget()
        self.contour_widget.SetInteractor(self.renderer.GetRenderWindow().GetInteractor())
        
        if self.measurement_type == self.AREA_CIRCLE:
            representation = vtk.vtkOrientedGlyphContourRepresentation()
            representation.GetProperty().SetColor(1, 0, 0)  # Red
        else:  # AREA_ELLIPSE
            representation = vtk.vtkOrientedGlyphContourRepresentation()
            representation.GetProperty().SetColor(0, 1, 0)  # Green
        
        self.contour_widget.SetRepresentation(representation)
        self.contour_widget.On()
    
    def _setup_freehand_measurement(self):
        """Setup for freehand area measurement."""
        self.contour_widget = vtk.vtkContourWidget()
        self.contour_widget.SetInteractor(self.renderer.GetRenderWindow().GetInteractor())
        
        representation = vtk.vtkOrientedGlyphContourRepresentation()
        representation.GetProperty().SetColor(0, 0, 1)  # Blue
        
        self.contour_widget.SetRepresentation(representation)
        self.contour_widget.On()
    
    def _setup_angle_measurement(self):
        """Setup for angle measurement."""
        self.angle_widget = vtk.vtkAngleWidget()
        self.angle_widget.SetInteractor(self.renderer.GetRenderWindow().GetInteractor())
        
        angle_representation = vtk.vtkAngleRepresentation2D()
        self.angle_widget.SetRepresentation(angle_representation)
        
        self.angle_widget.On()
    
    def _setup_point_measurement(self):
        """Setup for point value measurement."""
        # For point measurement, we just need to track clicks
        # This will be handled by the interactor style in the main application
        pass
    
    def add_point(self, x, y, z):
        """
        Add a point to the current measurement.
        
        Args:
            x, y, z (float): Coordinates of the point
            
        Returns:
            bool: True if point added successfully, False otherwise
        """
        if self.measurement_type is None:
            logger.warning("Cannot add point: no measurement in progress")
            return False
        
        self.points.append((x, y, z))
        
        # Create a sphere to visualize the point
        sphere = vtk.vtkSphereSource()
        sphere.SetCenter(x, y, z)
        sphere.SetRadius(1.0)  # Adjust radius as needed
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(sphere.GetOutputPort())
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)  # Red
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        # Update measurement based on points
        self._update_measurement()
        
        return True
    
    def _update_measurement(self):
        """Update the current measurement based on added points."""
        if len(self.points) < 1:
            return
        
        if self.measurement_type == self.DISTANCE and len(self.points) >= 2:
            self._calculate_distance()
        elif self.measurement_type == self.AREA_CIRCLE and len(self.points) >= 2:
            self._calculate_circle_area()
        elif self.measurement_type == self.AREA_ELLIPSE and len(self.points) >= 3:
            self._calculate_ellipse_area()
        elif self.measurement_type == self.AREA_FREEHAND and len(self.points) >= 3:
            self._calculate_freehand_area()
        elif self.measurement_type == self.ANGLE and len(self.points) >= 3:
            self._calculate_angle()
        elif self.measurement_type == self.POINT_VALUE and len(self.points) >= 1:
            self._calculate_point_value()
    
    def _calculate_distance(self):
        """Calculate distance between two points."""
        p1 = self.points[0]
        p2 = self.points[-1]
        
        distance = math.sqrt((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2 + (p2[2] - p1[2])**2)
        
        self.current_measurement = {
            'type': 'distance',
            'value': distance,
            'unit': 'mm',
            'points': [p1, p2]
        }
        
        # Create a line to visualize the distance
        line_source = vtk.vtkLineSource()
        line_source.SetPoint1(p1)
        line_source.SetPoint2(p2)
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(line_source.GetOutputPort())
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 1, 0)  # Yellow
        actor.GetProperty().SetLineWidth(2)
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        # Add text label with distance
        text_actor = self._create_text_actor(f"{distance:.2f} mm", 
                                           (p1[0] + p2[0])/2, 
                                           (p1[1] + p2[1])/2, 
                                           (p1[2] + p2[2])/2)
        self.renderer.AddActor(text_actor)
        self.actors.append(text_actor)
    
    def _calculate_circle_area(self):
        """Calculate area of a circle."""
        center = self.points[0]
        edge = self.points[-1]
        
        radius = math.sqrt((edge[0] - center[0])**2 + 
                          (edge[1] - center[1])**2 + 
                          (edge[2] - center[2])**2)
        
        area = math.pi * radius**2
        
        self.current_measurement = {
            'type': 'circle_area',
            'value': area,
            'unit': 'mm²',
            'center': center,
            'radius': radius
        }
        
        # Create a circle to visualize the area
        circle = vtk.vtkRegularPolygonSource()
        circle.SetCenter(center)
        circle.SetRadius(radius)
        circle.SetNumberOfSides(50)  # Make it look like a circle
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(circle.GetOutputPort())
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)  # Red
        actor.GetProperty().SetOpacity(0.3)
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        # Add text label with area
        text_actor = self._create_text_actor(f"{area:.2f} mm²", 
                                           center[0], center[1], center[2])
        self.renderer.AddActor(text_actor)
        self.actors.append(text_actor)
    
    def _calculate_ellipse_area(self):
        """Calculate area of an ellipse."""
        center = self.points[0]
        axis1 = self.points[1]
        axis2 = self.points[2]
        
        a = math.sqrt((axis1[0] - center[0])**2 + 
                     (axis1[1] - center[1])**2 + 
                     (axis1[2] - center[2])**2)
        
        b = math.sqrt((axis2[0] - center[0])**2 + 
                     (axis2[1] - center[1])**2 + 
                     (axis2[2] - center[2])**2)
        
        area = math.pi * a * b
        
        self.current_measurement = {
            'type': 'ellipse_area',
            'value': area,
            'unit': 'mm²',
            'center': center,
            'semi_major': max(a, b),
            'semi_minor': min(a, b)
        }
        
        # In a real application, we would create an ellipse actor
        # For simplicity, we'll just add a text label
        text_actor = self._create_text_actor(f"{area:.2f} mm²", 
                                           center[0], center[1], center[2])
        self.renderer.AddActor(text_actor)
        self.actors.append(text_actor)
    
    def _calculate_freehand_area(self):
        """Calculate area of a freehand region."""
        # For simplicity, we'll just calculate the area of the polygon
        # formed by the points using the Shoelace formula
        
        # Extract x, y coordinates (assuming z is constant for 2D slice)
        x = [p[0] for p in self.points]
        y = [p[1] for p in self.points]
        
        # Close the polygon
        x.append(x[0])
        y.append(y[0])
        
        # Calculate area using Shoelace formula
        area = 0.5 * abs(sum(x[i] * y[i+1] - x[i+1] * y[i] 
                            for i in range(len(x)-1)))
        
        self.current_measurement = {
            'type': 'freehand_area',
            'value': area,
            'unit': 'mm²',
            'points': self.points
        }
        
        # Create a polygon to visualize the area
        points = vtk.vtkPoints()
        for p in self.points:
            points.InsertNextPoint(p)
        
        polygon = vtk.vtkPolygon()
        polygon.GetPointIds().SetNumberOfIds(len(self.points))
        for i in range(len(self.points)):
            polygon.GetPointIds().SetId(i, i)
        
        cells = vtk.vtkCellArray()
        cells.InsertNextCell(polygon)
        
        poly_data = vtk.vtkPolyData()
        poly_data.SetPoints(points)
        poly_data.SetPolys(cells)
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(poly_data)
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(0, 0, 1)  # Blue
        actor.GetProperty().SetOpacity(0.3)
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        # Add text label with area
        centroid_x = sum(p[0] for p in self.points) / len(self.points)
        centroid_y = sum(p[1] for p in self.points) / len(self.points)
        centroid_z = sum(p[2] for p in self.points) / len(self.points)
        
        text_actor = self._create_text_actor(f"{area:.2f} mm²", 
                                           centroid_x, centroid_y, centroid_z)
        self.renderer.AddActor(text_actor)
        self.actors.append(text_actor)
    
    def _calculate_angle(self):
        """Calculate angle between three points."""
        if len(self.points) < 3:
            return
        
        p1 = self.points[0]
        p2 = self.points[1]
        p3 = self.points[2]
        
        # Calculate vectors
        v1 = [p1[0] - p2[0], p1[1] - p2[1], p1[2] - p2[2]]
        v2 = [p3[0] - p2[0], p3[1] - p2[1], p3[2] - p2[2]]
        
        # Calculate dot product
        dot_product = v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]
        
        # Calculate magnitudes
        mag_v1 = math.sqrt(v1[0]**2 + v1[1]**2 + v1[2]**2)
        mag_v2 = math.sqrt(v2[0]**2 + v2[1]**2 + v2[2]**2)
        
        # Calculate angle in radians
        cos_angle = dot_product / (mag_v1 * mag_v2)
        # Clamp to [-1, 1] to avoid numerical errors
        cos_angle = max(-1, min(1, cos_angle))
        angle_rad = math.acos(cos_angle)
        
        # Convert to degrees
        angle_deg = math.degrees(angle_rad)
        
        self.current_measurement = {
            'type': 'angle',
            'value': angle_deg,
            'unit': 'degrees',
            'points': [p1, p2, p3]
        }
        
        # Create lines to visualize the angle
        line1 = vtk.vtkLineSource()
        line1.SetPoint1(p2)
        line1.SetPoint2(p1)
        
        line2 = vtk.vtkLineSource()
        line2.SetPoint1(p2)
        line2.SetPoint2(p3)
        
        mapper1 = vtk.vtkPolyDataMapper()
        mapper1.SetInputConnection(line1.GetOutputPort())
        
        mapper2 = vtk.vtkPolyDataMapper()
        mapper2.SetInputConnection(line2.GetOutputPort())
        
        actor1 = vtk.vtkActor()
        actor1.SetMapper(mapper1)
        actor1.GetProperty().SetColor(1, 1, 0)  # Yellow
        actor1.GetProperty().SetLineWidth(2)
        
        actor2 = vtk.vtkActor()
        actor2.SetMapper(mapper2)
        actor2.GetProperty().SetColor(1, 1, 0)  # Yellow
        actor2.GetProperty().SetLineWidth(2)
        
        self.renderer.AddActor(actor1)
        self.renderer.AddActor(actor2)
        self.actors.append(actor1)
        self.actors.append(actor2)
        
        # Add text label with angle
        text_actor = self._create_text_actor(f"{angle_deg:.1f}°", 
                                           p2[0], p2[1], p2[2])
        self.renderer.AddActor(text_actor)
        self.actors.append(text_actor)
    
    def _calculate_point_value(self):
        """Calculate value at a specific point."""
        # In a real application, this would extract the value from the image data
        # For now, we'll just use a placeholder
        point = self.points[0]
        value = 0  # Placeholder
        
        self.current_measurement = {
            'type': 'point_value',
            'value': value,
            'unit': 'HU',  # or SUV for PET
            'point': point
        }
        
        # Add text label with value
        text_actor = self._create_text_actor(f"{value:.2f}", 
                                           point[0], point[1], point[2])
        self.renderer.AddActor(text_actor)
        self.actors.append(text_actor)
    
    def _create_text_actor(self, text, x, y, z):
        """Create a VTK text actor at the specified position."""
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(text)
        text_actor.GetTextProperty().SetFontSize(14)
        text_actor.GetTextProperty().SetColor(1, 1, 1)  # White
        text_actor.GetTextProperty().SetBold(True)
        text_actor.GetTextProperty().SetShadow(True)
        
        # Convert 3D world coordinates to 2D display coordinates
        coordinate = vtk.vtkCoordinate()
        coordinate.SetCoordinateSystemToWorld()
        coordinate.SetValue(x, y, z)
        
        display_coords = coordinate.GetComputedDisplayValue(self.renderer)
        text_actor.SetPosition(display_coords[0], display_coords[1])
        
        return text_actor
    
    def finish_measurement(self):
        """
        Finish the current measurement and add it to the list of measurements.
        
        Returns:
            dict: Measurement data, or None if no measurement in progress
        """
        if self.current_measurement is None:
            return None
        
        # Add measurement to list
        self.measurements.append(self.current_measurement)
        
        # Turn off widgets
        if self.distance_widget is not None:
            self.distance_widget.Off()
            self.distance_widget = None
        
        if self.angle_widget is not None:
            self.angle_widget.Off()
            self.angle_widget = None
        
        if self.contour_widget is not None:
            self.contour_widget.Off()
            self.contour_widget = None
        
        # Return the measurement
        result = self.current_measurement
        self.current_measurement = None
        self.measurement_type = None
        
        return result
    
    def clear_current_measurement(self):
        """Clear the current measurement without saving it."""
        # Turn off widgets
        if self.distance_widget is not None:
            self.distance_widget.Off()
            self.distance_widget = None
        
        if self.angle_widget is not None:
            self.angle_widget.Off()
            self.angle_widget = None
        
        if self.contour_widget is not None:
            self.contour_widget.Off()
            self.contour_widget = None
        
        # Remove actors
        for actor in self.actors:
            self.renderer.RemoveActor(actor)
        
        self.actors = []
        self.points = []
        self.current_measurement = None
        self.measurement_type = None
    
    def clear_all_measurements(self):
        """Clear all measurements."""
        self.clear_current_measurement()
        self.measurements = []
    
    def get_measurements(self):
        """Get all measurements."""
        return self.measurements


class SUVCalculator:
    """
    Class for calculating Standardized Uptake Values (SUV) in PET images.
    """
    
    def __init__(self):
        """Initialize the SUVCalculator."""
        self.pet_array = None
        self.patient_weight = None  # in kg
        self.injected_dose = None   # in Bq
        self.injection_time = None  # in seconds since epoch
        self.acquisition_time = None  # in seconds since epoch
        self.isotope_halflife = None  # in seconds
        self.suv_array = None
    
    def set_pet_data(self, pet_array):
        """Set PET data for SUV calculation."""
        self.pet_array = pet_array
    
    def set_patient_info(self, weight, injected_dose, injection_time, acquisition_time, isotope_halflife):
        """
        Set patient information for SUV calculation.
        
        Args:
            weight (float): Patient weight in kg
            injected_dose (float): Injected dose in Bq
            injection_time (float): Injection time in seconds since epoch
            acquisition_time (float): Acquisition time in seconds since epoch
            isotope_halflife (float): Isotope half-life in seconds
        """
        self.patient_weight = weight
        self.injected_dose = injected_dose
        self.injection_time = injection_time
        self.acquisition_time = acquisition_time
        self.isotope_halflife = isotope_halflife
    
    def calculate_suv(self):
        """
        Calculate SUV values.
        
        Returns:
            numpy.ndarray: SUV array, or None if calculation fails
        """
        if self.pet_array is None:
            logger.warning("Cannot calculate SUV: PET data not set")
            return None
        
        if (self.patient_weight is None or self.injected_dose is None or
            self.injection_time is None or self.acquisition_time is None or
            self.isotope_halflife is None):
            logger.warning("Cannot calculate SUV: patient information incomplete")
            return None
        
        try:
            # Calculate decay factor
            decay_time = self.acquisition_time - self.injection_time
            decay_factor = 2 ** (-decay_time / self.isotope_halflife)
            
            # Calculate decay-corrected injected dose
            corrected_dose = self.injected_dose * decay_factor
            
            # Calculate SUV
            suv_factor = self.patient_weight * 1000 / corrected_dose  # 1000 to convert kg to g
            self.suv_array = self.pet_array * suv_factor
            
            return self.suv_array
        except Exception as e:
            logger.error(f"Error calculating SUV: {str(e)}")
            return None
    
    def get_suv_at_point(self, x, y, z):
        """
        Get SUV value at a specific point.
        
        Args:
            x, y, z (int): Coordinates of the point
            
        Returns:
            float: SUV value, or None if calculation fails
        """
        if self.suv_array is None:
            logger.warning("Cannot get SUV: SUV array not calculated")
            return None
        
        try:
            # Check if coordinates are within array bounds
            shape = self.suv_array.shape
            if (0 <= x < shape[0] and 0 <= y < shape[1] and 0 <= z < shape[2]):
                return self.suv_array[x, y, z]
            else:
                logger.warning(f"Point ({x}, {y}, {z}) is outside array bounds {shape}")
                return None
        except Exception as e:
            logger.error(f"Error getting SUV at point: {str(e)}")
            return None
    
    def get_suv_stats_in_roi(self, roi_mask):
        """
        Calculate SUV statistics within a region of interest.
        
        Args:
            roi_mask (numpy.ndarray): Binary mask defining the ROI
            
        Returns:
            dict: SUV statistics, or None if calculation fails
        """
        if self.suv_array is None:
            logger.warning("Cannot calculate SUV stats: SUV array not calculated")
            return None
        
        if roi_mask.shape != self.suv_array.shape:
            logger.warning("ROI mask shape does not match SUV array shape")
            return None
        
        try:
            # Extract SUV values within ROI
            suv_values = self.suv_array[roi_mask > 0]
            
            if len(suv_values) == 0:
                logger.warning("ROI is empty")
                return None
            
            # Calculate statistics
            stats = {
                'min': np.min(suv_values),
                'max': np.max(suv_values),
                'mean': np.mean(suv_values),
                'median': np.median(suv_values),
                'std': np.std(suv_values),
                'volume_voxels': len(suv_values),
                # SUVpeak is typically defined as the average SUV within a 1 cm³ sphere
                # centered on the maximum SUV voxel. This is a simplified version.
                'peak': np.percentile(suv_values, 95)
            }
            
            return stats
        except Exception as e:
            logger.error(f"Error calculating SUV stats: {str(e)}")
            return None


class VolumeCalculator:
    """
    Class for calculating volumes of regions of interest in DICOM images.
    """
    
    def __init__(self):
        """Initialize the VolumeCalculator."""
        self.image_data = None
        self.spacing = (1.0, 1.0, 1.0)  # Default spacing in mm
    
    def set_image_data(self, image_data, spacing=None):
        """
        Set image data for volume calculation.
        
        Args:
            image_data (numpy.ndarray): 3D array of image data
            spacing (tuple, optional): Voxel spacing in mm (x, y, z)
        """
        self.image_data = image_data
        if spacing is not None:
            self.spacing = spacing
    
    def calculate_volume_from_mask(self, mask):
        """
        Calculate volume of a region defined by a binary mask.
        
        Args:
            mask (numpy.ndarray): Binary mask defining the region
            
        Returns:
            dict: Volume information, or None if calculation fails
        """
        if self.image_data is None:
            logger.warning("Cannot calculate volume: image data not set")
            return None
        
        if mask.shape != self.image_data.shape:
            logger.warning("Mask shape does not match image data shape")
            return None
        
        try:
            # Count voxels in the mask
            voxel_count = np.sum(mask > 0)
            
            # Calculate voxel volume in mm³
            voxel_volume = self.spacing[0] * self.spacing[1] * self.spacing[2]
            
            # Calculate total volume in mm³
            volume_mm3 = voxel_count * voxel_volume
            
            # Convert to cm³
            volume_cm3 = volume_mm3 / 1000.0
            
            return {
                'voxel_count': voxel_count,
                'voxel_volume_mm3': voxel_volume,
                'volume_mm3': volume_mm3,
                'volume_cm3': volume_cm3
            }
        except Exception as e:
            logger.error(f"Error calculating volume: {str(e)}")
            return None
    
    def calculate_volume_from_threshold(self, threshold, above=True):
        """
        Calculate volume of a region defined by a threshold.
        
        Args:
            threshold (float): Threshold value
            above (bool): If True, include voxels above threshold; if False, include voxels below threshold
            
        Returns:
            dict: Volume information, or None if calculation fails
        """
        if self.image_data is None:
            logger.warning("Cannot calculate volume: image data not set")
            return None
        
        try:
            # Create mask based on threshold
            if above:
                mask = self.image_data > threshold
            else:
                mask = self.image_data < threshold
            
            # Calculate volume using the mask
            return self.calculate_volume_from_mask(mask)
        except Exception as e:
            logger.error(f"Error calculating volume from threshold: {str(e)}")
            return None
    
    def calculate_volume_from_range(self, lower_threshold, upper_threshold):
        """
        Calculate volume of a region defined by a range of values.
        
        Args:
            lower_threshold (float): Lower threshold value
            upper_threshold (float): Upper threshold value
            
        Returns:
            dict: Volume information, or None if calculation fails
        """
        if self.image_data is None:
            logger.warning("Cannot calculate volume: image data not set")
            return None
        
        try:
            # Create mask based on range
            mask = (self.image_data >= lower_threshold) & (self.image_data <= upper_threshold)
            
            # Calculate volume using the mask
            return self.calculate_volume_from_mask(mask)
        except Exception as e:
            logger.error(f"Error calculating volume from range: {str(e)}")
            return None


class AnnotationTool:
    """
    Class for creating and managing annotations on DICOM images.
    """
    
    # Annotation types
    TEXT = 0
    ARROW = 1
    RECTANGLE = 2
    ELLIPSE = 3
    FREEHAND = 4
    
    def __init__(self, renderer=None):
        """
        Initialize the AnnotationTool.
        
        Args:
            renderer (vtkRenderer, optional): VTK renderer for visualization
        """
        self.renderer = renderer
        self.current_annotation = None
        self.annotation_type = None
        self.points = []
        self.actors = []
        self.annotations = []  # List to store all annotations
        self.text_content = ""
    
    def set_renderer(self, renderer):
        """Set the VTK renderer for visualization."""
        self.renderer = renderer
    
    def start_annotation(self, annotation_type, text=""):
        """
        Start a new annotation.
        
        Args:
            annotation_type (int): Type of annotation to create
            text (str, optional): Text content for text annotations
            
        Returns:
            bool: True if annotation started successfully, False otherwise
        """
        if self.renderer is None:
            logger.warning("Cannot start annotation: renderer not set")
            return False
        
        # Clear previous annotation
        self.clear_current_annotation()
        
        self.annotation_type = annotation_type
        self.points = []
        self.text_content = text
        
        return True
    
    def add_point(self, x, y, z):
        """
        Add a point to the current annotation.
        
        Args:
            x, y, z (float): Coordinates of the point
            
        Returns:
            bool: True if point added successfully, False otherwise
        """
        if self.annotation_type is None:
            logger.warning("Cannot add point: no annotation in progress")
            return False
        
        self.points.append((x, y, z))
        
        # Update annotation based on points
        self._update_annotation()
        
        return True
    
    def _update_annotation(self):
        """Update the current annotation based on added points."""
        if len(self.points) < 1:
            return
        
        # Remove previous actors
        for actor in self.actors:
            self.renderer.RemoveActor(actor)
        self.actors = []
        
        if self.annotation_type == self.TEXT and len(self.points) >= 1:
            self._create_text_annotation()
        elif self.annotation_type == self.ARROW and len(self.points) >= 2:
            self._create_arrow_annotation()
        elif self.annotation_type == self.RECTANGLE and len(self.points) >= 2:
            self._create_rectangle_annotation()
        elif self.annotation_type == self.ELLIPSE and len(self.points) >= 2:
            self._create_ellipse_annotation()
        elif self.annotation_type == self.FREEHAND and len(self.points) >= 2:
            self._create_freehand_annotation()
    
    def _create_text_annotation(self):
        """Create a text annotation."""
        point = self.points[0]
        
        text_actor = vtk.vtkTextActor()
        text_actor.SetInput(self.text_content)
        text_actor.GetTextProperty().SetFontSize(14)
        text_actor.GetTextProperty().SetColor(1, 1, 0)  # Yellow
        text_actor.GetTextProperty().SetBold(True)
        
        # Convert 3D world coordinates to 2D display coordinates
        coordinate = vtk.vtkCoordinate()
        coordinate.SetCoordinateSystemToWorld()
        coordinate.SetValue(point)
        
        display_coords = coordinate.GetComputedDisplayValue(self.renderer)
        text_actor.SetPosition(display_coords[0], display_coords[1])
        
        self.renderer.AddActor(text_actor)
        self.actors.append(text_actor)
        
        self.current_annotation = {
            'type': 'text',
            'text': self.text_content,
            'position': point
        }
    
    def _create_arrow_annotation(self):
        """Create an arrow annotation."""
        start_point = self.points[0]
        end_point = self.points[-1]
        
        # Create arrow
        arrow_source = vtk.vtkArrowSource()
        arrow_source.SetTipResolution(20)
        arrow_source.SetShaftResolution(20)
        
        # Calculate direction and length
        direction = [end_point[0] - start_point[0],
                    end_point[1] - start_point[1],
                    end_point[2] - start_point[2]]
        length = math.sqrt(direction[0]**2 + direction[1]**2 + direction[2]**2)
        
        if length > 0:
            direction = [d / length for d in direction]
        else:
            direction = [0, 0, 1]  # Default direction
        
        # Create transform
        transform = vtk.vtkTransform()
        transform.Translate(start_point)
        transform.RotateZ(math.degrees(math.atan2(direction[1], direction[0])))
        transform.RotateY(math.degrees(math.acos(direction[2])))
        transform.Scale(length, length, length)
        
        # Apply transform
        transform_filter = vtk.vtkTransformPolyDataFilter()
        transform_filter.SetInputConnection(arrow_source.GetOutputPort())
        transform_filter.SetTransform(transform)
        transform_filter.Update()
        
        # Create mapper and actor
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(transform_filter.GetOutputPort())
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 1, 0)  # Yellow
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        self.current_annotation = {
            'type': 'arrow',
            'start_point': start_point,
            'end_point': end_point
        }
    
    def _create_rectangle_annotation(self):
        """Create a rectangle annotation."""
        p1 = self.points[0]
        p2 = self.points[-1]
        
        # Create rectangle points
        points = vtk.vtkPoints()
        points.InsertNextPoint(p1[0], p1[1], p1[2])
        points.InsertNextPoint(p2[0], p1[1], p1[2])
        points.InsertNextPoint(p2[0], p2[1], p2[2])
        points.InsertNextPoint(p1[0], p2[1], p2[2])
        
        # Create polygon
        polygon = vtk.vtkPolygon()
        polygon.GetPointIds().SetNumberOfIds(4)
        for i in range(4):
            polygon.GetPointIds().SetId(i, i)
        
        # Create cell array
        cells = vtk.vtkCellArray()
        cells.InsertNextCell(polygon)
        
        # Create polydata
        poly_data = vtk.vtkPolyData()
        poly_data.SetPoints(points)
        poly_data.SetPolys(cells)
        
        # Create mapper and actor
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(poly_data)
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 1, 0)  # Yellow
        actor.GetProperty().SetOpacity(0.3)
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        self.current_annotation = {
            'type': 'rectangle',
            'corner1': p1,
            'corner2': p2
        }
    
    def _create_ellipse_annotation(self):
        """Create an ellipse annotation."""
        center = self.points[0]
        edge = self.points[-1]
        
        # Calculate radius
        radius_x = abs(edge[0] - center[0])
        radius_y = abs(edge[1] - center[1])
        
        # Create ellipse
        ellipse = vtk.vtkRegularPolygonSource()
        ellipse.SetCenter(center[0], center[1], center[2])
        ellipse.SetRadius(max(radius_x, radius_y))
        ellipse.SetNumberOfSides(50)  # Make it look smooth
        
        # Scale to create ellipse
        transform = vtk.vtkTransform()
        transform.Translate(center[0], center[1], center[2])
        transform.Scale(radius_x / max(radius_x, radius_y),
                       radius_y / max(radius_x, radius_y),
                       1.0)
        transform.Translate(-center[0], -center[1], -center[2])
        
        # Apply transform
        transform_filter = vtk.vtkTransformPolyDataFilter()
        transform_filter.SetInputConnection(ellipse.GetOutputPort())
        transform_filter.SetTransform(transform)
        transform_filter.Update()
        
        # Create mapper and actor
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(transform_filter.GetOutputPort())
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 1, 0)  # Yellow
        actor.GetProperty().SetOpacity(0.3)
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        self.current_annotation = {
            'type': 'ellipse',
            'center': center,
            'radius_x': radius_x,
            'radius_y': radius_y
        }
    
    def _create_freehand_annotation(self):
        """Create a freehand annotation."""
        # Create points
        points = vtk.vtkPoints()
        for p in self.points:
            points.InsertNextPoint(p)
        
        # Create lines
        lines = vtk.vtkCellArray()
        for i in range(len(self.points) - 1):
            line = vtk.vtkLine()
            line.GetPointIds().SetId(0, i)
            line.GetPointIds().SetId(1, i + 1)
            lines.InsertNextCell(line)
        
        # Create polydata
        poly_data = vtk.vtkPolyData()
        poly_data.SetPoints(points)
        poly_data.SetLines(lines)
        
        # Create mapper and actor
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(poly_data)
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 1, 0)  # Yellow
        actor.GetProperty().SetLineWidth(2)
        
        self.renderer.AddActor(actor)
        self.actors.append(actor)
        
        self.current_annotation = {
            'type': 'freehand',
            'points': self.points
        }
    
    def finish_annotation(self):
        """
        Finish the current annotation and add it to the list of annotations.
        
        Returns:
            dict: Annotation data, or None if no annotation in progress
        """
        if self.current_annotation is None:
            return None
        
        # Add annotation to list
        self.annotations.append(self.current_annotation)
        
        # Return the annotation
        result = self.current_annotation
        self.current_annotation = None
        self.annotation_type = None
        self.text_content = ""
        
        return result
    
    def clear_current_annotation(self):
        """Clear the current annotation without saving it."""
        # Remove actors
        for actor in self.actors:
            self.renderer.RemoveActor(actor)
        
        self.actors = []
        self.points = []
        self.current_annotation = None
        self.annotation_type = None
        self.text_content = ""
    
    def clear_all_annotations(self):
        """Clear all annotations."""
        self.clear_current_annotation()
        self.annotations = []
    
    def get_annotations(self):
        """Get all annotations."""
        return self.annotations
    
    def export_annotations_to_dict(self):
        """
        Export all annotations to a dictionary.
        
        Returns:
            dict: Dictionary containing all annotations
        """
        return {
            'annotations': self.annotations,
            'count': len(self.annotations)
        }


class ReportGenerator:
    """
    Class for generating reports from annotations and measurements.
    """
    
    def __init__(self):
        """Initialize the ReportGenerator."""
        self.annotations = []
        self.measurements = []
        self.patient_info = {}
        self.study_info = {}
        self.screenshots = []
    
    def set_annotations(self, annotations):
        """Set annotations for the report."""
        self.annotations = annotations
    
    def set_measurements(self, measurements):
        """Set measurements for the report."""
        self.measurements = measurements
    
    def set_patient_info(self, patient_info):
        """Set patient information for the report."""
        self.patient_info = patient_info
    
    def set_study_info(self, study_info):
        """Set study information for the report."""
        self.study_info = study_info
    
    def add_screenshot(self, image_path, description=""):
        """
        Add a screenshot to the report.
        
        Args:
            image_path (str): Path to the screenshot image
            description (str, optional): Description of the screenshot
        """
        self.screenshots.append({
            'path': image_path,
            'description': description
        })
    
    def generate_report_html(self, output_path):
        """
        Generate an HTML report.
        
        Args:
            output_path (str): Path to save the HTML report
            
        Returns:
            bool: True if report generated successfully, False otherwise
        """
        try:
            # Create HTML content
            html_content = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>PET/CT Report</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    h1 { color: #333366; }
                    h2 { color: #336699; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    .screenshot { margin: 10px 0; max-width: 100%; }
                    .screenshot img { max-width: 100%; border: 1px solid #ddd; }
                </style>
            </head>
            <body>
                <h1>PET/CT Imaging Report</h1>
            """
            
            # Add patient information
            html_content += "<h2>Patient Information</h2>"
            html_content += "<table>"
            for key, value in self.patient_info.items():
                html_content += f"<tr><th>{key}</th><td>{value}</td></tr>"
            html_content += "</table>"
            
            # Add study information
            html_content += "<h2>Study Information</h2>"
            html_content += "<table>"
            for key, value in self.study_info.items():
                html_content += f"<tr><th>{key}</th><td>{value}</td></tr>"
            html_content += "</table>"
            
            # Add measurements
            if self.measurements:
                html_content += "<h2>Measurements</h2>"
                html_content += "<table>"
                html_content += "<tr><th>Type</th><th>Value</th><th>Unit</th></tr>"
                for m in self.measurements:
                    html_content += f"<tr><td>{m.get('type', 'Unknown')}</td><td>{m.get('value', 'N/A')}</td><td>{m.get('unit', '')}</td></tr>"
                html_content += "</table>"
            
            # Add annotations
            if self.annotations:
                html_content += "<h2>Annotations</h2>"
                html_content += "<table>"
                html_content += "<tr><th>Type</th><th>Description</th></tr>"
                for a in self.annotations:
                    description = a.get('text', '') if a.get('type') == 'text' else ''
                    html_content += f"<tr><td>{a.get('type', 'Unknown')}</td><td>{description}</td></tr>"
                html_content += "</table>"
            
            # Add screenshots
            if self.screenshots:
                html_content += "<h2>Screenshots</h2>"
                for i, screenshot in enumerate(self.screenshots):
                    html_content += f"""
                    <div class="screenshot">
                        <h3>Screenshot {i+1}</h3>
                        <p>{screenshot['description']}</p>
                        <img src="{screenshot['path']}" alt="Screenshot {i+1}">
                    </div>
                    """
            
            # Close HTML
            html_content += """
            </body>
            </html>
            """
            
            # Write to file
            with open(output_path, 'w') as f:
                f.write(html_content)
            
            return True
        except Exception as e:
            logger.error(f"Error generating HTML report: {str(e)}")
            return False
    
    def generate_report_docx(self, output_path):
        """
        Generate a Word (DOCX) report.
        
        Args:
            output_path (str): Path to save the DOCX report
            
        Returns:
            bool: True if report generated successfully, False otherwise
        """
        try:
            # This would use a library like python-docx to generate a Word document
            # For simplicity, we'll just create a placeholder function
            logger.warning("DOCX report generation not fully implemented")
            
            # In a real implementation, we would:
            # 1. Create a new document
            # 2. Add patient and study information
            # 3. Add tables for measurements and annotations
            # 4. Add screenshots
            # 5. Save the document
            
            return False
        except Exception as e:
            logger.error(f"Error generating DOCX report: {str(e)}")
            return False


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, these would be imported by the main application
    print("Quantification module loaded")
