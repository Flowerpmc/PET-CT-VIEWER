#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PACS Integration Module for PET/CT Viewer
---------------------------------------
This module provides PACS connectivity and DICOM networking features.
"""

import os
import sys
import logging
import datetime
import time
import threading
import queue
import tempfile
from pydicom.dataset import Dataset
from pynetdicom import AE, evt, AllStoragePresentationContexts, debug_logger
from pynetdicom.sop_class import (
    PatientRootQueryRetrieveInformationModelFind,
    PatientRootQueryRetrieveInformationModelGet,
    PatientRootQueryRetrieveInformationModelMove,
    StudyRootQueryRetrieveInformationModelFind,
    StudyRootQueryRetrieveInformationModelGet,
    StudyRootQueryRetrieveInformationModelMove,
    ModalityWorklistInformationFind
)

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('PacsConnector')

# Uncomment for debugging DICOM network operations
# debug_logger()

class PacsConnector:
    """
    Class for connecting to PACS servers and retrieving DICOM data.
    """
    
    def __init__(self):
        """Initialize the PacsConnector."""
        self.ae = AE()
        self.remote_ae = None
        self.remote_port = None
        self.remote_host = None
        self.local_port = 11112  # Default local port
        self.timeout = 30  # Default timeout in seconds
        self.is_connected = False
        self.download_dir = None
        self.download_queue = queue.Queue()
        self.download_thread = None
        self.download_in_progress = False
        self.download_callback = None
        self.status_callback = None
    
    def set_callbacks(self, status_callback=None, download_callback=None):
        """
        Set callback functions for status updates and download completion.
        
        Args:
            status_callback (callable): Function to call with status updates
            download_callback (callable): Function to call when download completes
        """
        self.status_callback = status_callback
        self.download_callback = download_callback
    
    def _update_status(self, message):
        """
        Update status via callback if available.
        
        Args:
            message (str): Status message
        """
        logger.info(message)
        if self.status_callback:
            self.status_callback(message)
    
    def configure(self, ae_title="PETCTVIEWER", download_dir=None):
        """
        Configure the PACS connector.
        
        Args:
            ae_title (str): Local AE title
            download_dir (str, optional): Directory for downloaded DICOM files
        """
        self.ae.ae_title = ae_title
        
        # Add presentation contexts for query/retrieve
        self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelFind)
        self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelGet)
        self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelMove)
        self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelFind)
        self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelGet)
        self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelMove)
        self.ae.add_requested_context(ModalityWorklistInformationFind)
        
        # Add presentation contexts for storage
        for context in AllStoragePresentationContexts:
            self.ae.add_requested_context(context.abstract_syntax)
        
        # Set download directory
        if download_dir:
            self.download_dir = download_dir
        else:
            self.download_dir = tempfile.mkdtemp(prefix="petct_viewer_")
        
        # Ensure download directory exists
        os.makedirs(self.download_dir, exist_ok=True)
        
        self._update_status(f"PACS connector configured with AE title: {ae_title}")
    
    def connect(self, host, port, ae_title="PACS"):
        """
        Connect to a PACS server.
        
        Args:
            host (str): PACS server hostname or IP
            port (int): PACS server port
            ae_title (str): Remote AE title
            
        Returns:
            bool: True if connection successful, False otherwise
        """
        self.remote_host = host
        self.remote_port = port
        self.remote_ae = ae_title
        
        try:
            # Test association
            assoc = self.ae.associate(host, port, ae_title=ae_title)
            if assoc.is_established:
                self.is_connected = True
                assoc.release()
                self._update_status(f"Connected to PACS server at {host}:{port}")
                return True
            else:
                self.is_connected = False
                self._update_status(f"Failed to connect to PACS server at {host}:{port}")
                return False
        except Exception as e:
            self.is_connected = False
            self._update_status(f"Error connecting to PACS server: {str(e)}")
            return False
    
    def disconnect(self):
        """Disconnect from the PACS server."""
        self.is_connected = False
        self._update_status("Disconnected from PACS server")
    
    def find_patients(self, patient_name=None, patient_id=None, modality=None):
        """
        Find patients in the PACS server.
        
        Args:
            patient_name (str, optional): Patient name (can include wildcards)
            patient_id (str, optional): Patient ID
            modality (str, optional): Modality filter
            
        Returns:
            list: List of patient records
        """
        if not self.is_connected:
            self._update_status("Not connected to PACS server")
            return []
        
        # Create C-FIND dataset
        ds = Dataset()
        ds.QueryRetrieveLevel = "PATIENT"
        
        # Add search parameters
        ds.PatientName = patient_name or ""
        ds.PatientID = patient_id or ""
        
        # Add requested fields
        ds.PatientBirthDate = ""
        ds.PatientSex = ""
        
        # Add modality filter if specified
        if modality:
            ds.ModalitiesInStudy = modality
        
        try:
            # Create association
            assoc = self.ae.associate(self.remote_host, self.remote_port, ae_title=self.remote_ae)
            if not assoc.is_established:
                self._update_status("Association rejected, aborted or never connected")
                return []
            
            # Send C-FIND request
            self._update_status("Searching for patients...")
            responses = assoc.send_c_find(ds, PatientRootQueryRetrieveInformationModelFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status.Status == 0xFF00:  # Pending
                    if dataset:
                        patient = {
                            'PatientName': str(dataset.PatientName) if hasattr(dataset, 'PatientName') else "Unknown",
                            'PatientID': dataset.PatientID if hasattr(dataset, 'PatientID') else "",
                            'PatientBirthDate': dataset.PatientBirthDate if hasattr(dataset, 'PatientBirthDate') else "",
                            'PatientSex': dataset.PatientSex if hasattr(dataset, 'PatientSex') else ""
                        }
                        results.append(patient)
            
            # Release association
            assoc.release()
            
            self._update_status(f"Found {len(results)} patients")
            return results
        except Exception as e:
            self._update_status(f"Error searching for patients: {str(e)}")
            return []
    
    def find_studies(self, patient_id=None, study_date=None, modality=None):
        """
        Find studies in the PACS server.
        
        Args:
            patient_id (str, optional): Patient ID
            study_date (str, optional): Study date or date range (YYYYMMDD-YYYYMMDD)
            modality (str, optional): Modality filter
            
        Returns:
            list: List of study records
        """
        if not self.is_connected:
            self._update_status("Not connected to PACS server")
            return []
        
        # Create C-FIND dataset
        ds = Dataset()
        ds.QueryRetrieveLevel = "STUDY"
        
        # Add search parameters
        if patient_id:
            ds.PatientID = patient_id
        else:
            ds.PatientID = ""
        
        if study_date:
            ds.StudyDate = study_date
        else:
            ds.StudyDate = ""
        
        if modality:
            ds.ModalitiesInStudy = modality
        
        # Add requested fields
        ds.PatientName = ""
        ds.StudyInstanceUID = ""
        ds.StudyDescription = ""
        ds.StudyTime = ""
        ds.AccessionNumber = ""
        ds.NumberOfStudyRelatedSeries = ""
        
        try:
            # Create association
            assoc = self.ae.associate(self.remote_host, self.remote_port, ae_title=self.remote_ae)
            if not assoc.is_established:
                self._update_status("Association rejected, aborted or never connected")
                return []
            
            # Send C-FIND request
            self._update_status("Searching for studies...")
            responses = assoc.send_c_find(ds, StudyRootQueryRetrieveInformationModelFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status.Status == 0xFF00:  # Pending
                    if dataset:
                        study = {
                            'PatientName': str(dataset.PatientName) if hasattr(dataset, 'PatientName') else "Unknown",
                            'PatientID': dataset.PatientID if hasattr(dataset, 'PatientID') else "",
                            'StudyInstanceUID': dataset.StudyInstanceUID if hasattr(dataset, 'StudyInstanceUID') else "",
                            'StudyDescription': dataset.StudyDescription if hasattr(dataset, 'StudyDescription') else "",
                            'StudyDate': dataset.StudyDate if hasattr(dataset, 'StudyDate') else "",
                            'StudyTime': dataset.StudyTime if hasattr(dataset, 'StudyTime') else "",
                            'AccessionNumber': dataset.AccessionNumber if hasattr(dataset, 'AccessionNumber') else "",
                            'NumberOfSeries': dataset.NumberOfStudyRelatedSeries if hasattr(dataset, 'NumberOfStudyRelatedSeries') else ""
                        }
                        results.append(study)
            
            # Release association
            assoc.release()
            
            self._update_status(f"Found {len(results)} studies")
            return results
        except Exception as e:
            self._update_status(f"Error searching for studies: {str(e)}")
            return []
    
    def find_series(self, study_instance_uid):
        """
        Find series for a specific study.
        
        Args:
            study_instance_uid (str): Study Instance UID
            
        Returns:
            list: List of series records
        """
        if not self.is_connected:
            self._update_status("Not connected to PACS server")
            return []
        
        # Create C-FIND dataset
        ds = Dataset()
        ds.QueryRetrieveLevel = "SERIES"
        ds.StudyInstanceUID = study_instance_uid
        
        # Add requested fields
        ds.SeriesInstanceUID = ""
        ds.SeriesNumber = ""
        ds.SeriesDescription = ""
        ds.Modality = ""
        ds.NumberOfSeriesRelatedInstances = ""
        
        try:
            # Create association
            assoc = self.ae.associate(self.remote_host, self.remote_port, ae_title=self.remote_ae)
            if not assoc.is_established:
                self._update_status("Association rejected, aborted or never connected")
                return []
            
            # Send C-FIND request
            self._update_status("Searching for series...")
            responses = assoc.send_c_find(ds, StudyRootQueryRetrieveInformationModelFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status.Status == 0xFF00:  # Pending
                    if dataset:
                        series = {
                            'SeriesInstanceUID': dataset.SeriesInstanceUID if hasattr(dataset, 'SeriesInstanceUID') else "",
                            'SeriesNumber': dataset.SeriesNumber if hasattr(dataset, 'SeriesNumber') else "",
                            'SeriesDescription': dataset.SeriesDescription if hasattr(dataset, 'SeriesDescription') else "",
                            'Modality': dataset.Modality if hasattr(dataset, 'Modality') else "",
                            'NumberOfInstances': dataset.NumberOfSeriesRelatedInstances if hasattr(dataset, 'NumberOfSeriesRelatedInstances') else ""
                        }
                        results.append(series)
            
            # Release association
            assoc.release()
            
            self._update_status(f"Found {len(results)} series")
            return results
        except Exception as e:
            self._update_status(f"Error searching for series: {str(e)}")
            return []
    
    def get_today_studies(self):
        """
        Get studies from today.
        
        Returns:
            list: List of today's study records
        """
        today = datetime.datetime.now().strftime("%Y%m%d")
        return self.find_studies(study_date=today)
    
    def retrieve_series(self, series_instance_uid, study_instance_uid):
        """
        Retrieve a series from the PACS server.
        
        Args:
            series_instance_uid (str): Series Instance UID
            study_instance_uid (str): Study Instance UID
            
        Returns:
            str: Path to the downloaded series directory, or None if failed
        """
        if not self.is_connected:
            self._update_status("Not connected to PACS server")
            return None
        
        # Create output directory
        series_dir = os.path.join(self.download_dir, series_instance_uid)
        os.makedirs(series_dir, exist_ok=True)
        
        # Create C-GET dataset
        ds = Dataset()
        ds.QueryRetrieveLevel = "SERIES"
        ds.StudyInstanceUID = study_instance_uid
        ds.SeriesInstanceUID = series_instance_uid
        
        # Add handler for incoming datasets
        def handle_store(event):
            """Handle a C-STORE request."""
            dataset = event.dataset
            try:
                # Save dataset to file
                if hasattr(dataset, 'SOPInstanceUID'):
                    filename = os.path.join(series_dir, f"{dataset.SOPInstanceUID}.dcm")
                    dataset.save_as(filename, write_like_original=False)
                    return 0x0000  # Success
                else:
                    return 0xC000  # Failed - Unable to process
            except Exception as e:
                logger.error(f"Error saving dataset: {str(e)}")
                return 0xC000  # Failed - Unable to process
        
        # Add handler for C-GET responses
        self.ae.add_handler(evt.EVT_C_STORE, handle_store)
        
        try:
            # Create association
            assoc = self.ae.associate(self.remote_host, self.remote_port, ae_title=self.remote_ae)
            if not assoc.is_established:
                self._update_status("Association rejected, aborted or never connected")
                return None
            
            # Send C-GET request
            self._update_status(f"Retrieving series {series_instance_uid}...")
            responses = assoc.send_c_get(ds, StudyRootQueryRetrieveInformationModelGet)
            
            # Process responses
            for (status, dataset) in responses:
                if status.Status != 0x0000:  # Not Success
                    logger.warning(f"C-GET status: {status}")
            
            # Release association
            assoc.release()
            
            # Check if files were downloaded
            files = os.listdir(series_dir)
            if files:
                self._update_status(f"Retrieved {len(files)} instances to {series_dir}")
                return series_dir
            else:
                self._update_status("No instances retrieved")
                return None
        except Exception as e:
            self._update_status(f"Error retrieving series: {str(e)}")
            return None
        finally:
            # Remove handler
            self.ae.remove_handlers(evt.EVT_C_STORE)
    
    def retrieve_study(self, study_instance_uid):
        """
        Retrieve a complete study from the PACS server.
        
        Args:
            study_instance_uid (str): Study Instance UID
            
        Returns:
            str: Path to the downloaded study directory, or None if failed
        """
        if not self.is_connected:
            self._update_status("Not connected to PACS server")
            return None
        
        # Create output directory
        study_dir = os.path.join(self.download_dir, study_instance_uid)
        os.makedirs(study_dir, exist_ok=True)
        
        # Create C-GET dataset
        ds = Dataset()
        ds.QueryRetrieveLevel = "STUDY"
        ds.StudyInstanceUID = study_instance_uid
        
        # Add handler for incoming datasets
        def handle_store(event):
            """Handle a C-STORE request."""
            dataset = event.dataset
            try:
                # Create series directory if needed
                if hasattr(dataset, 'SeriesInstanceUID'):
                    series_dir = os.path.join(study_dir, dataset.SeriesInstanceUID)
                    os.makedirs(series_dir, exist_ok=True)
                    
                    # Save dataset to file
                    if hasattr(dataset, 'SOPInstanceUID'):
                        filename = os.path.join(series_dir, f"{dataset.SOPInstanceUID}.dcm")
                        dataset.save_as(filename, write_like_original=False)
                        return 0x0000  # Success
                    else:
                        return 0xC000  # Failed - Unable to process
                else:
                    return 0xC000  # Failed - Unable to process
            except Exception as e:
                logger.error(f"Error saving dataset: {str(e)}")
                return 0xC000  # Failed - Unable to process
        
        # Add handler for C-GET responses
        self.ae.add_handler(evt.EVT_C_STORE, handle_store)
        
        try:
            # Create association
            assoc = self.ae.associate(self.remote_host, self.remote_port, ae_title=self.remote_ae)
            if not assoc.is_established:
                self._update_status("Association rejected, aborted or never connected")
                return None
            
            # Send C-GET request
            self._update_status(f"Retrieving study {study_instance_uid}...")
            responses = assoc.send_c_get(ds, StudyRootQueryRetrieveInformationModelGet)
            
            # Process responses
            for (status, dataset) in responses:
                if status.Status != 0x0000:  # Not Success
                    logger.warning(f"C-GET status: {status}")
            
            # Release association
            assoc.release()
            
            # Check if files were downloaded
            series_dirs = os.listdir(study_dir)
            if series_dirs:
                total_files = 0
                for series_dir in series_dirs:
                    series_path = os.path.join(study_dir, series_dir)
                    if os.path.isdir(series_path):
                        total_files += len(os.listdir(series_path))
                
                self._update_status(f"Retrieved {len(series_dirs)} series with {total_files} instances to {study_dir}")
                return study_dir
            else:
                self._update_status("No instances retrieved")
                return None
        except Exception as e:
            self._update_status(f"Error retrieving study: {str(e)}")
            return None
        finally:
            # Remove handler
            self.ae.remove_handlers(evt.EVT_C_STORE)
    
    def queue_download(self, item_type, uid, parent_uid=None):
        """
        Queue a download task.
        
        Args:
            item_type (str): Type of item to download ('study' or 'series')
            uid (str): UID of the item to download
            parent_uid (str, optional): Parent UID (required for series)
            
        Returns:
            bool: True if queued successfully, False otherwise
        """
        if item_type not in ['study', 'series']:
            self._update_status(f"Invalid download type: {item_type}")
            return False
        
        if item_type == 'series' and not parent_uid:
            self._update_status("Parent UID required for series download")
            return False
        
        # Add to queue
        self.download_queue.put((item_type, uid, parent_uid))
        
        # Start download thread if not already running
        if not self.download_in_progress:
            self._start_download_thread()
        
        self._update_status(f"Queued {item_type} {uid} for download")
        return True
    
    def _start_download_thread(self):
        """Start the download thread."""
        if self.download_thread is None or not self.download_thread.is_alive():
            self.download_thread = threading.Thread(target=self._download_worker)
            self.download_thread.daemon = True
            self.download_thread.start()
    
    def _download_worker(self):
        """Worker thread for processing download queue."""
        self.download_in_progress = True
        
        while not self.download_queue.empty():
            try:
                # Get next item from queue
                item_type, uid, parent_uid = self.download_queue.get(block=False)
                
                # Download item
                if item_type == 'study':
                    result = self.retrieve_study(uid)
                else:  # series
                    result = self.retrieve_series(uid, parent_uid)
                
                # Call callback if provided
                if self.download_callback:
                    self.download_callback(item_type, uid, result)
                
                # Mark task as done
                self.download_queue.task_done()
                
                # Small delay to prevent overloading the PACS server
                time.sleep(1)
            except queue.Empty:
                break
            except Exception as e:
                self._update_status(f"Error in download worker: {str(e)}")
                # Mark task as done to avoid blocking
                self.download_queue.task_done()
        
        self.download_in_progress = False
    
    def get_modality_worklist(self, scheduled_date=None, modality=None):
        """
        Get modality worklist from the PACS server.
        
        Args:
            scheduled_date (str, optional): Scheduled date (YYYYMMDD)
            modality (str, optional): Modality filter
            
        Returns:
            list: List of worklist items
        """
        if not self.is_connected:
            self._update_status("Not connected to PACS server")
            return []
        
        # Create C-FIND dataset
        ds = Dataset()
        
        # Add search parameters
        if scheduled_date:
            ds.ScheduledProcedureStepStartDate = scheduled_date
        
        if modality:
            ds.ModalitiesInStudy = modality
        
        # Add requested fields
        ds.PatientName = ""
        ds.PatientID = ""
        ds.AccessionNumber = ""
        ds.RequestedProcedureDescription = ""
        ds.ScheduledProcedureStepStartTime = ""
        ds.Modality = ""
        
        try:
            # Create association
            assoc = self.ae.associate(self.remote_host, self.remote_port, ae_title=self.remote_ae)
            if not assoc.is_established:
                self._update_status("Association rejected, aborted or never connected")
                return []
            
            # Send C-FIND request
            self._update_status("Retrieving modality worklist...")
            responses = assoc.send_c_find(ds, ModalityWorklistInformationFind)
            
            # Process responses
            results = []
            for (status, dataset) in responses:
                if status.Status == 0xFF00:  # Pending
                    if dataset:
                        worklist_item = {
                            'PatientName': str(dataset.PatientName) if hasattr(dataset, 'PatientName') else "Unknown",
                            'PatientID': dataset.PatientID if hasattr(dataset, 'PatientID') else "",
                            'AccessionNumber': dataset.AccessionNumber if hasattr(dataset, 'AccessionNumber') else "",
                            'RequestedProcedureDescription': dataset.RequestedProcedureDescription if hasattr(dataset, 'RequestedProcedureDescription') else "",
                            'ScheduledDate': dataset.ScheduledProcedureStepStartDate if hasattr(dataset, 'ScheduledProcedureStepStartDate') else "",
                            'ScheduledTime': dataset.ScheduledProcedureStepStartTime if hasattr(dataset, 'ScheduledProcedureStepStartTime') else "",
                            'Modality': dataset.Modality if hasattr(dataset, 'Modality') else ""
                        }
                        results.append(worklist_item)
            
            # Release association
            assoc.release()
            
            self._update_status(f"Retrieved {len(results)} worklist items")
            return results
        except Exception as e:
            self._update_status(f"Error retrieving worklist: {str(e)}")
            return []


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    pacs = PacsConnector()
    pacs.configure()
    
    # Check if connection parameters were provided
    if len(sys.argv) >= 4:
        host = sys.argv[1]
        port = int(sys.argv[2])
        ae_title = sys.argv[3]
        
        if pacs.connect(host, port, ae_title):
            print("Connected to PACS server")
            
            # Get today's studies
            studies = pacs.get_today_studies()
            print(f"Found {len(studies)} studies today")
            
            for i, study in enumerate(studies[:5]):  # Show first 5
                print(f"\nStudy {i+1}:")
                print(f"  Patient: {study['PatientName']}")
                print(f"  Description: {study['StudyDescription']}")
                print(f"  Date/Time: {study['StudyDate']} {study['StudyTime']}")
                
                # Get series for this study
                series_list = pacs.find_series(study['StudyInstanceUID'])
                print(f"  Series: {len(series_list)}")
                
                for j, series in enumerate(series_list[:3]):  # Show first 3
                    print(f"    Series {j+1}: {series['SeriesDescription']} ({series['Modality']})")
            
            pacs.disconnect()
        else:
            print("Failed to connect to PACS server")
    else:
        print("Usage: python pacs_connector.py <host> <port> <ae_title>")
