#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
High-Value LUT Module for PET/CT Viewer
-------------------------------------
This module provides high-value lookup tables for OpenGL rendering.
"""

import os
import sys
import logging
import numpy as np
import vtk
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('HighValueLUT')

class HighValueLUTManager:
    """
    Class for managing high-value lookup tables for OpenGL rendering.
    """
    
    # Constants for modality types
    PET = 0
    CT = 1
    FUSION = 2
    
    # Constants for predefined LUT types
    LUT_16BIT = 0
    LUT_32BIT = 1
    LUT_FLOAT = 2
    
    # Constants for predefined color maps
    COLORMAP_GRAYSCALE = 0
    COLORMAP_HOT_METAL = 1
    COLORMAP_RAINBOW = 2
    COLORMAP_JET = 3
    COLORMAP_VIRIDIS = 4
    COLORMAP_PLASMA = 5
    COLORMAP_BONE = 6
    COLORMAP_COOL = 7
    COLORMAP_HOT = 8
    COLORMAP_SPRING = 9
    COLORMAP_SUMMER = 10
    COLORMAP_AUTUMN = 11
    COLORMAP_WINTER = 12
    COLORMAP_COPPER = 13
    COLORMAP_SPECTRAL = 14
    COLORMAP_NIPY_SPECTRAL = 15
    
    def __init__(self):
        """Initialize the HighValueLUTManager."""
        # Initialize color maps
        self.color_maps = self._create_predefined_color_maps()
        
        # Initialize lookup tables
        self.luts = {}
        
        # Create default LUTs
        self._create_default_luts()
        
        # Initialize window/level values
        self.pet_window = 6.0
        self.pet_level = 3.0
        self.ct_window = 400.0
        self.ct_level = 40.0
    
    def _create_predefined_color_maps(self):
        """
        Create predefined color maps.
        
        Returns:
            dict: Dictionary of color maps
        """
        color_maps = {}
        
        # Grayscale
        color_maps[self.COLORMAP_GRAYSCALE] = [
            (0.0, 0, 0, 0),
            (1.0, 1, 1, 1)
        ]
        
        # Hot Metal
        color_maps[self.COLORMAP_HOT_METAL] = [
            (0.0, 0, 0, 0),      # Black
            (0.2, 0.5, 0, 0),    # Dark red
            (0.4, 0.9, 0.2, 0),  # Red-orange
            (0.6, 1, 0.5, 0),    # Orange
            (0.8, 1, 0.8, 0.2),  # Yellow-orange
            (1.0, 1, 1, 1)       # White
        ]
        
        # Rainbow
        color_maps[self.COLORMAP_RAINBOW] = [
            (0.0, 0, 0, 1),    # Blue
            (0.25, 0, 1, 1),   # Cyan
            (0.5, 0, 1, 0),    # Green
            (0.75, 1, 1, 0),   # Yellow
            (1.0, 1, 0, 0)     # Red
        ]
        
        # Jet
        color_maps[self.COLORMAP_JET] = [
            (0.0, 0, 0, 0.5),
            (0.1, 0, 0, 1),
            (0.3, 0, 1, 1),
            (0.5, 0, 1, 0),
            (0.7, 1, 1, 0),
            (0.9, 1, 0, 0),
            (1.0, 0.5, 0, 0)
        ]
        
        # Viridis
        color_maps[self.COLORMAP_VIRIDIS] = [
            (0.0, 0.267, 0.005, 0.329),
            (0.14, 0.283, 0.141, 0.458),
            (0.29, 0.232, 0.318, 0.544),
            (0.43, 0.171, 0.466, 0.558),
            (0.57, 0.129, 0.6, 0.553),
            (0.71, 0.157, 0.712, 0.431),
            (0.86, 0.365, 0.8, 0.276),
            (1.0, 0.993, 0.906, 0.144)
        ]
        
        # Plasma
        color_maps[self.COLORMAP_PLASMA] = [
            (0.0, 0.05, 0.03, 0.52),
            (0.14, 0.36, 0.04, 0.57),
            (0.29, 0.56, 0.01, 0.53),
            (0.43, 0.71, 0.15, 0.45),
            (0.57, 0.83, 0.28, 0.35),
            (0.71, 0.93, 0.43, 0.26),
            (0.86, 0.99, 0.68, 0.38),
            (1.0, 0.94, 0.98, 0.68)
        ]
        
        # Bone
        color_maps[self.COLORMAP_BONE] = [
            (0.0, 0, 0, 0),
            (0.4, 0.3, 0.3, 0.3),
            (0.7, 0.7, 0.7, 0.7),
            (1.0, 1, 1, 1)
        ]
        
        # Cool
        color_maps[self.COLORMAP_COOL] = [
            (0.0, 0, 1, 1),
            (1.0, 1, 0, 1)
        ]
        
        # Hot
        color_maps[self.COLORMAP_HOT] = [
            (0.0, 0.0416, 0, 0),
            (0.365, 1, 0, 0),
            (0.746, 1, 1, 0),
            (1.0, 1, 1, 1)
        ]
        
        # Spring
        color_maps[self.COLORMAP_SPRING] = [
            (0.0, 1, 0, 1),
            (1.0, 1, 1, 0)
        ]
        
        # Summer
        color_maps[self.COLORMAP_SUMMER] = [
            (0.0, 0, 0.5, 0.4),
            (1.0, 1, 1, 0.4)
        ]
        
        # Autumn
        color_maps[self.COLORMAP_AUTUMN] = [
            (0.0, 1, 0, 0),
            (1.0, 1, 1, 0)
        ]
        
        # Winter
        color_maps[self.COLORMAP_WINTER] = [
            (0.0, 0, 0, 1),
            (1.0, 0, 1, 0.5)
        ]
        
        # Copper
        color_maps[self.COLORMAP_COPPER] = [
            (0.0, 0, 0, 0),
            (0.8, 1, 0.5, 0.3),
            (1.0, 1, 0.7, 0.5)
        ]
        
        # Spectral
        color_maps[self.COLORMAP_SPECTRAL] = [
            (0.0, 0.6, 0, 0.05),
            (0.1, 0.9, 0.1, 0),
            (0.2, 0.9, 0.3, 0),
            (0.3, 0.9, 0.6, 0),
            (0.4, 0.9, 0.9, 0),
            (0.5, 0.6, 0.9, 0.1),
            (0.6, 0.4, 0.7, 0.2),
            (0.7, 0.2, 0.5, 0.4),
            (0.8, 0.1, 0.3, 0.6),
            (0.9, 0.1, 0.1, 0.8),
            (1.0, 0.1, 0, 0.5)
        ]
        
        # NIPY Spectral
        color_maps[self.COLORMAP_NIPY_SPECTRAL] = [
            (0.0, 0, 0, 0),
            (0.05, 0.4667, 0, 0.5333),
            (0.1, 0, 0, 1),
            (0.15, 0, 0.5, 1),
            (0.2, 0, 1, 1),
            (0.25, 0.5, 1, 0.5),
            (0.3, 0.5, 1, 0),
            (0.35, 1, 1, 0),
            (0.4, 1, 0.6667, 0),
            (0.45, 1, 0.3333, 0),
            (0.5, 1, 0, 0),
            (0.55, 1, 0, 0),
            (0.6, 0.9333, 0, 0),
            (0.65, 0.8, 0, 0),
            (0.7, 0.6667, 0, 0),
            (0.75, 0.5333, 0, 0),
            (0.8, 0.4, 0, 0),
            (0.85, 0.2667, 0, 0),
            (0.9, 0.1333, 0, 0),
            (0.95, 0, 0, 0),
            (1.0, 0, 0, 0)
        ]
        
        return color_maps
    
    def get_color_map_names(self):
        """
        Get the names of available color maps.
        
        Returns:
            list: List of color map names
        """
        return [
            "Grayscale",
            "Hot Metal",
            "Rainbow",
            "Jet",
            "Viridis",
            "Plasma",
            "Bone",
            "Cool",
            "Hot",
            "Spring",
            "Summer",
            "Autumn",
            "Winter",
            "Copper",
            "Spectral",
            "NIPY Spectral"
        ]
    
    def _create_default_luts(self):
        """Create default lookup tables."""
        # Create 16-bit LUTs
        self._create_lut(self.LUT_16BIT, self.PET, self.COLORMAP_HOT_METAL)
        self._create_lut(self.LUT_16BIT, self.CT, self.COLORMAP_GRAYSCALE)
        self._create_lut(self.LUT_16BIT, self.FUSION, self.COLORMAP_JET)
        
        # Create 32-bit LUTs
        self._create_lut(self.LUT_32BIT, self.PET, self.COLORMAP_HOT_METAL)
        self._create_lut(self.LUT_32BIT, self.CT, self.COLORMAP_GRAYSCALE)
        self._create_lut(self.LUT_32BIT, self.FUSION, self.COLORMAP_JET)
        
        # Create float LUTs
        self._create_lut(self.LUT_FLOAT, self.PET, self.COLORMAP_HOT_METAL)
        self._create_lut(self.LUT_FLOAT, self.CT, self.COLORMAP_GRAYSCALE)
        self._create_lut(self.LUT_FLOAT, self.FUSION, self.COLORMAP_JET)
    
    def _create_lut(self, lut_type, modality, color_map_id):
        """
        Create a lookup table.
        
        Args:
            lut_type (int): LUT type (16-bit, 32-bit, or float)
            modality (int): Modality type (PET, CT, or FUSION)
            color_map_id (int): Color map identifier
            
        Returns:
            vtkLookupTable: VTK lookup table
        """
        if color_map_id not in self.color_maps:
            logger.warning(f"Unknown color map: {color_map_id}")
            color_map_id = self.COLORMAP_GRAYSCALE
        
        # Get color map
        color_map = self.color_maps[color_map_id]
        
        # Create lookup table based on type
        if lut_type == self.LUT_16BIT:
            lut = vtk.vtkLookupTable()
            lut.SetNumberOfTableValues(65536)  # 16-bit
            lut.SetRange(0, 65535)
        elif lut_type == self.LUT_32BIT:
            lut = vtk.vtkLookupTable()
            lut.SetNumberOfTableValues(4096)  # Reduced from 2^32 for practicality
            lut.SetRange(0, 4095)
        elif lut_type == self.LUT_FLOAT:
            lut = vtk.vtkColorTransferFunction()
        else:
            logger.warning(f"Unknown LUT type: {lut_type}")
            return None
        
        # Set colors from color map
        if lut_type == self.LUT_FLOAT:
            # For float LUT, add points directly
            for value, r, g, b in color_map:
                lut.AddRGBPoint(value, r, g, b)
        else:
            # For discrete LUTs, set table values
            num_values = lut.GetNumberOfTableValues()
            for i in range(num_values):
                # Normalize index to 0-1 range
                value = i / (num_values - 1)
                
                # Get color from color map
                r, g, b = self._get_color_from_map(color_map, value)
                
                # Set table value
                lut.SetTableValue(i, r, g, b, 1.0)
        
        # Build lookup table
        if lut_type != self.LUT_FLOAT:
            lut.Build()
        
        # Store lookup table
        key = (lut_type, modality, color_map_id)
        self.luts[key] = lut
        
        return lut
    
    def get_lut(self, lut_type, modality, color_map_id):
        """
        Get a lookup table.
        
        Args:
            lut_type (int): LUT type (16-bit, 32-bit, or float)
            modality (int): Modality type (PET, CT, or FUSION)
            color_map_id (int): Color map identifier
            
        Returns:
            vtkLookupTable or vtkColorTransferFunction: Lookup table
        """
        key = (lut_type, modality, color_map_id)
        if key not in self.luts:
            # Create LUT if it doesn't exist
            return self._create_lut(lut_type, modality, color_map_id)
        
        return self.luts[key]
    
    def set_window_level(self, lut_type, modality, color_map_id, window, level):
        """
        Set window/level values for a lookup table.
        
        Args:
            lut_type (int): LUT type (16-bit, 32-bit, or float)
            modality (int): Modality type (PET, CT, or FUSION)
            color_map_id (int): Color map identifier
            window (float): Window value
            level (float): Level value
        """
        # Get lookup table
        lut = self.get_lut(lut_type, modality, color_map_id)
        if not lut:
            return
        
        # Set range based on window/level
        min_val = level - window/2
        max_val = level + window/2
        
        # Apply range
        if lut_type == self.LUT_FLOAT:
            # For float LUT, recreate with new range
            color_map = self.color_maps[color_map_id]
            lut.RemoveAllPoints()
            for value, r, g, b in color_map:
                # Map value from 0-1 to min_val-max_val
                mapped_value = min_val + value * (max_val - min_val)
                lut.AddRGBPoint(mapped_value, r, g, b)
        else:
            # For discrete LUTs, set range
            lut.SetRange(min_val, max_val)
            lut.Build()
    
    def create_high_dynamic_range_lut(self, modality, color_map_id, bit_depth=16):
        """
        Create a high dynamic range lookup table.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            color_map_id (int): Color map identifier
            bit_depth (int): Bit depth (8, 12, 16, or 32)
            
        Returns:
            vtkLookupTable: High dynamic range lookup table
        """
        if color_map_id not in self.color_maps:
            logger.warning(f"Unknown color map: {color_map_id}")
            color_map_id = self.COLORMAP_GRAYSCALE
        
        # Get color map
        color_map = self.color_maps[color_map_id]
        
        # Determine number of table values based on bit depth
        if bit_depth == 8:
            num_values = 256
        elif bit_depth == 12:
            num_values = 4096
        elif bit_depth == 16:
            num_values = 65536
        elif bit_depth == 32:
            num_values = 4096  # Reduced from 2^32 for practicality
        else:
            logger.warning(f"Unsupported bit depth: {bit_depth}")
            num_values = 256
        
        # Create lookup table
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(num_values)
        
        # Set colors from color map
        for i in range(num_values):
            # Normalize index to 0-1 range
            value = i / (num_values - 1)
            
            # Get color from color map
            r, g, b = self._get_color_from_map(color_map, value)
            
            # Set table value
            lut.SetTableValue(i, r, g, b, 1.0)
        
        # Set range based on modality
        if modality == self.PET:
            lut.SetRange(0, 10)  # SUV range
        elif modality == self.CT:
            lut.SetRange(-1000, 1000)  # HU range
        else:
            lut.SetRange(0, 1)  # Normalized range
        
        # Build lookup table
        lut.Build()
        
        return lut
    
    def create_optimized_texture_lut(self, modality, color_map_id, texture_size):
        """
        Create a lookup table optimized for texture size.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            color_map_id (int): Color map identifier
            texture_size (int): Maximum texture size
            
        Returns:
            vtkLookupTable: Optimized lookup table
        """
        if color_map_id not in self.color_maps:
            logger.warning(f"Unknown color map: {color_map_id}")
            color_map_id = self.COLORMAP_GRAYSCALE
        
        # Get color map
        color_map = self.color_maps[color_map_id]
        
        # Determine optimal number of table values
        # Ensure it's less than the maximum texture size
        num_values = min(4096, texture_size)
        
        # Create lookup table
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(num_values)
        
        # Set colors from color map
        for i in range(num_values):
            # Normalize index to 0-1 range
            value = i / (num_values - 1)
            
            # Get color from color map
            r, g, b = self._get_color_from_map(color_map, value)
            
            # Set table value
            lut.SetTableValue(i, r, g, b, 1.0)
        
        # Set range based on modality
        if modality == self.PET:
            lut.SetRange(0, 10)  # SUV range
        elif modality == self.CT:
            lut.SetRange(-1000, 1000)  # HU range
        else:
            lut.SetRange(0, 1)  # Normalized range
        
        # Build lookup table
        lut.Build()
        
        return lut
    
    def _get_color_from_map(self, color_map, value):
        """
        Get color from color map for a specific value.
        
        Args:
            color_map (list): Color map as list of (value, r, g, b) tuples
            value (float): Value to get color for (0-1)
            
        Returns:
            tuple: (r, g, b) color values (0-1)
        """
        # Handle edge cases
        if value <= color_map[0][0]:
            return color_map[0][1:]
        
        if value >= color_map[-1][0]:
            return color_map[-1][1:]
        
        # Find surrounding points in color map
        for i in range(len(color_map) - 1):
            if color_map[i][0] <= value < color_map[i+1][0]:
                # Interpolate between points
                t = (value - color_map[i][0]) / (color_map[i+1][0] - color_map[i][0])
                r = color_map[i][1] + t * (color_map[i+1][1] - color_map[i][1])
                g = color_map[i][2] + t * (color_map[i+1][2] - color_map[i][2])
                b = color_map[i][3] + t * (color_map[i+1][3] - color_map[i][3])
                return (r, g, b)
        
        # Fallback
        return (0, 0, 0)


class OpenGLTextureOptimizer:
    """
    Class for optimizing textures for OpenGL rendering.
    """
    
    def __init__(self):
        """Initialize the OpenGLTextureOptimizer."""
        # Get maximum texture size
        self.max_texture_size = self._get_max_texture_size()
        
        # Initialize high-value LUT manager
        self.lut_manager = HighValueLUTManager()
    
    def _get_max_texture_size(self):
        """
        Get the maximum texture size supported by OpenGL.
        
        Returns:
            int: Maximum texture size
        """
        try:
            # Create a temporary QOpenGLWidget to query OpenGL info
            app = QtWidgets.QApplication.instance()
            if not app:
                app = QtWidgets.QApplication([])
            
            gl_widget = QtWidgets.QOpenGLWidget()
            gl_widget.show()
            gl_widget.hide()
            
            # Get OpenGL context
            context = gl_widget.context()
            if not context.isValid():
                logger.warning("OpenGL context is not valid")
                return 2048  # Default fallback
            
            # Get maximum texture size
            functions = context.functions()
            max_size = functions.glGetIntegerv(0x0D33)  # GL_MAX_TEXTURE_SIZE
            
            return max_size
        except Exception as e:
            logger.error(f"Error getting maximum texture size: {str(e)}")
            return 2048  # Default fallback
    
    def optimize_texture_size(self, width, height, depth=1):
        """
        Optimize texture size to fit within OpenGL limits.
        
        Args:
            width (int): Texture width
            height (int): Texture height
            depth (int): Texture depth (for 3D textures)
            
        Returns:
            tuple: Optimized (width, height, depth)
        """
        # Check if texture size exceeds maximum
        if width <= self.max_texture_size and height <= self.max_texture_size and depth <= self.max_texture_size:
            return (width, height, depth)
        
        # Calculate scale factor
        scale_factor = min(
            self.max_texture_size / width,
            self.max_texture_size / height,
            self.max_texture_size / max(1, depth)
        )
        
        # Apply scale factor
        new_width = int(width * scale_factor)
        new_height = int(height * scale_factor)
        new_depth = int(depth * scale_factor)
        
        # Ensure minimum size
        new_width = max(1, new_width)
        new_height = max(1, new_height)
        new_depth = max(1, new_depth)
        
        logger.info(f"Optimized texture size: {width}x{height}x{depth} -> {new_width}x{new_height}x{new_depth}")
        
        return (new_width, new_height, new_depth)
    
    def create_optimized_texture(self, image_data, modality, color_map_id):
        """
        Create an optimized texture from image data.
        
        Args:
            image_data (vtkImageData): Image data
            modality (int): Modality type (PET, CT, or FUSION)
            color_map_id (int): Color map identifier
            
        Returns:
            vtkTexture: Optimized texture
        """
        if not image_data:
            logger.warning("No image data provided")
            return None
        
        try:
            # Get image dimensions
            dims = image_data.GetDimensions()
            
            # Optimize dimensions
            new_dims = self.optimize_texture_size(dims[0], dims[1], dims[2] if len(dims) > 2 else 1)
            
            # Resize image if needed
            if new_dims != dims:
                # Create resample filter
                resample = vtk.vtkImageResample()
                resample.SetInputData(image_data)
                resample.SetAxisMagnificationFactor(0, new_dims[0] / dims[0])
                resample.SetAxisMagnificationFactor(1, new_dims[1] / dims[1])
                if len(dims) > 2:
                    resample.SetAxisMagnificationFactor(2, new_dims[2] / dims[2])
                resample.Update()
                
                # Get resampled image
                image_data = resample.GetOutput()
            
            # Create optimized lookup table
            lut = self.lut_manager.create_optimized_texture_lut(modality, color_map_id, self.max_texture_size)
            
            # Create texture
            texture = vtk.vtkTexture()
            texture.SetInputData(image_data)
            texture.SetLookupTable(lut)
            texture.SetColorModeToMapScalars()
            texture.InterpolateOn()
            
            return texture
        except Exception as e:
            logger.error(f"Error creating optimized texture: {str(e)}")
            return None
    
    def create_high_dynamic_range_texture(self, image_data, modality, color_map_id, bit_depth=16):
        """
        Create a high dynamic range texture from image data.
        
        Args:
            image_data (vtkImageData): Image data
            modality (int): Modality type (PET, CT, or FUSION)
            color_map_id (int): Color map identifier
            bit_depth (int): Bit depth (8, 12, 16, or 32)
            
        Returns:
            vtkTexture: High dynamic range texture
        """
        if not image_data:
            logger.warning("No image data provided")
            return None
        
        try:
            # Get image dimensions
            dims = image_data.GetDimensions()
            
            # Optimize dimensions
            new_dims = self.optimize_texture_size(dims[0], dims[1], dims[2] if len(dims) > 2 else 1)
            
            # Resize image if needed
            if new_dims != dims:
                # Create resample filter
                resample = vtk.vtkImageResample()
                resample.SetInputData(image_data)
                resample.SetAxisMagnificationFactor(0, new_dims[0] / dims[0])
                resample.SetAxisMagnificationFactor(1, new_dims[1] / dims[1])
                if len(dims) > 2:
                    resample.SetAxisMagnificationFactor(2, new_dims[2] / dims[2])
                resample.Update()
                
                # Get resampled image
                image_data = resample.GetOutput()
            
            # Create high dynamic range lookup table
            lut = self.lut_manager.create_high_dynamic_range_lut(modality, color_map_id, bit_depth)
            
            # Create texture
            texture = vtk.vtkTexture()
            texture.SetInputData(image_data)
            texture.SetLookupTable(lut)
            texture.SetColorModeToMapScalars()
            texture.InterpolateOn()
            
            return texture
        except Exception as e:
            logger.error(f"Error creating high dynamic range texture: {str(e)}")
            return None


class HighValueLUTWidget(QtWidgets.QWidget):
    """
    Widget for selecting and customizing high-value lookup tables.
    """
    
    # Signal emitted when LUT changes
    lutChanged = QtCore.pyqtSignal(int, int, int)  # lut_type, modality, color_map_id
    
    # Signal emitted when window/level changes
    windowLevelChanged = QtCore.pyqtSignal(float, float)
    
    def __init__(self, parent=None):
        """
        Initialize the HighValueLUTWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(HighValueLUTWidget, self).__init__(parent)
        
        # Create high-value LUT manager
        self.lut_manager = HighValueLUTManager()
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create LUT type selector
        type_layout = QtWidgets.QHBoxLayout()
        type_label = QtWidgets.QLabel("LUT Type:")
        self.type_combo = QtWidgets.QComboBox()
        self.type_combo.addItems(["16-bit", "32-bit", "Float"])
        self.type_combo.currentIndexChanged.connect(self._on_lut_changed)
        
        type_layout.addWidget(type_label)
        type_layout.addWidget(self.type_combo, 1)
        
        # Create modality selector
        modality_layout = QtWidgets.QHBoxLayout()
        modality_label = QtWidgets.QLabel("Modality:")
        self.modality_combo = QtWidgets.QComboBox()
        self.modality_combo.addItems(["PET", "CT", "Fusion"])
        self.modality_combo.currentIndexChanged.connect(self._on_lut_changed)
        
        modality_layout.addWidget(modality_label)
        modality_layout.addWidget(self.modality_combo, 1)
        
        # Create color map selector
        color_map_layout = QtWidgets.QHBoxLayout()
        color_map_label = QtWidgets.QLabel("Color Map:")
        self.color_map_combo = QtWidgets.QComboBox()
        self.color_map_combo.addItems(self.lut_manager.get_color_map_names())
        self.color_map_combo.currentIndexChanged.connect(self._on_lut_changed)
        
        color_map_layout.addWidget(color_map_label)
        color_map_layout.addWidget(self.color_map_combo, 1)
        
        # Create window/level controls
        wl_layout = QtWidgets.QGridLayout()
        
        # Window control
        window_label = QtWidgets.QLabel("Window:")
        self.window_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.window_slider.setMinimum(1)
        self.window_slider.setMaximum(1000)
        self.window_slider.setValue(400)
        self.window_slider.valueChanged.connect(self._on_window_changed)
        
        self.window_spin = QtWidgets.QSpinBox()
        self.window_spin.setMinimum(1)
        self.window_spin.setMaximum(5000)
        self.window_spin.setValue(400)
        self.window_spin.valueChanged.connect(self._on_window_spin_changed)
        
        # Level control
        level_label = QtWidgets.QLabel("Level:")
        self.level_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.level_slider.setMinimum(-1000)
        self.level_slider.setMaximum(1000)
        self.level_slider.setValue(40)
        self.level_slider.valueChanged.connect(self._on_level_changed)
        
        self.level_spin = QtWidgets.QSpinBox()
        self.level_spin.setMinimum(-1000)
        self.level_spin.setMaximum(3000)
        self.level_spin.setValue(40)
        self.level_spin.valueChanged.connect(self._on_level_spin_changed)
        
        # Add controls to layout
        wl_layout.addWidget(window_label, 0, 0)
        wl_layout.addWidget(self.window_slider, 0, 1)
        wl_layout.addWidget(self.window_spin, 0, 2)
        wl_layout.addWidget(level_label, 1, 0)
        wl_layout.addWidget(self.level_slider, 1, 1)
        wl_layout.addWidget(self.level_spin, 1, 2)
        
        # Create preset buttons
        preset_layout = QtWidgets.QHBoxLayout()
        
        # CT presets
        self.preset_lung = QtWidgets.QPushButton("Lung")
        self.preset_lung.clicked.connect(lambda: self._set_preset(1500, -600))
        
        self.preset_bone = QtWidgets.QPushButton("Bone")
        self.preset_bone.clicked.connect(lambda: self._set_preset(2000, 400))
        
        self.preset_soft = QtWidgets.QPushButton("Soft Tissue")
        self.preset_soft.clicked.connect(lambda: self._set_preset(400, 40))
        
        self.preset_brain = QtWidgets.QPushButton("Brain")
        self.preset_brain.clicked.connect(lambda: self._set_preset(80, 40))
        
        # Add buttons to layout
        preset_layout.addWidget(self.preset_lung)
        preset_layout.addWidget(self.preset_bone)
        preset_layout.addWidget(self.preset_soft)
        preset_layout.addWidget(self.preset_brain)
        
        # Create color bar preview
        self.color_bar = QtWidgets.QLabel()
        self.color_bar.setMinimumHeight(150)
        self.color_bar.setStyleSheet("border: 1px solid #aaa;")
        
        # Add widgets to main layout
        layout.addLayout(type_layout)
        layout.addLayout(modality_layout)
        layout.addLayout(color_map_layout)
        layout.addLayout(wl_layout)
        layout.addLayout(preset_layout)
        layout.addWidget(self.color_bar, 1)
        
        # Initialize color bar
        self._update_color_bar()
    
    def set_modality(self, modality):
        """
        Set the modality for this widget.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
        """
        self.modality_combo.setCurrentIndex(modality)
        
        # Set appropriate color map and window/level values
        if modality == HighValueLUTManager.PET:
            self.color_map_combo.setCurrentIndex(HighValueLUTManager.COLORMAP_HOT_METAL)
            self._set_window_level(6.0, 3.0)
        elif modality == HighValueLUTManager.CT:
            self.color_map_combo.setCurrentIndex(HighValueLUTManager.COLORMAP_GRAYSCALE)
            self._set_window_level(400.0, 40.0)
        elif modality == HighValueLUTManager.FUSION:
            self.color_map_combo.setCurrentIndex(HighValueLUTManager.COLORMAP_JET)
            self._set_window_level(400.0, 40.0)
    
    def get_current_lut(self):
        """
        Get the current lookup table.
        
        Returns:
            vtkLookupTable or vtkColorTransferFunction: Current lookup table
        """
        lut_type = self.type_combo.currentIndex()
        modality = self.modality_combo.currentIndex()
        color_map_id = self.color_map_combo.currentIndex()
        
        return self.lut_manager.get_lut(lut_type, modality, color_map_id)
    
    def _on_lut_changed(self):
        """Handle LUT change."""
        lut_type = self.type_combo.currentIndex()
        modality = self.modality_combo.currentIndex()
        color_map_id = self.color_map_combo.currentIndex()
        
        # Update window/level
        window = self.window_spin.value()
        level = self.level_spin.value()
        self.lut_manager.set_window_level(lut_type, modality, color_map_id, window, level)
        
        # Update color bar
        self._update_color_bar()
        
        # Emit signal
        self.lutChanged.emit(lut_type, modality, color_map_id)
    
    def _on_window_changed(self, value):
        """
        Handle window slider change.
        
        Args:
            value (int): Window value
        """
        self.window_spin.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _on_window_spin_changed(self, value):
        """
        Handle window spin box change.
        
        Args:
            value (int): Window value
        """
        self.window_slider.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _on_level_changed(self, value):
        """
        Handle level slider change.
        
        Args:
            value (int): Level value
        """
        self.level_spin.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _on_level_spin_changed(self, value):
        """
        Handle level spin box change.
        
        Args:
            value (int): Level value
        """
        self.level_slider.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _emit_window_level(self):
        """Emit window/level changed signal."""
        window = self.window_spin.value()
        level = self.level_spin.value()
        
        # Update LUT
        lut_type = self.type_combo.currentIndex()
        modality = self.modality_combo.currentIndex()
        color_map_id = self.color_map_combo.currentIndex()
        self.lut_manager.set_window_level(lut_type, modality, color_map_id, window, level)
        
        # Emit signal
        self.windowLevelChanged.emit(float(window), float(level))
    
    def _set_preset(self, window, level):
        """
        Set a window/level preset.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        self._set_window_level(window, level)
        self._emit_window_level()
        self._update_color_bar()
    
    def _set_window_level(self, window, level):
        """
        Set window/level values.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        # Update controls
        self.window_slider.setValue(min(1000, int(window)))
        self.window_spin.setValue(int(window))
        self.level_slider.setValue(max(-1000, min(1000, int(level))))
        self.level_spin.setValue(int(level))
    
    def _update_color_bar(self):
        """Update the color bar preview."""
        # Get current color map
        color_map_id = self.color_map_combo.currentIndex()
        
        # Get window/level values
        window = self.window_spin.value()
        level = self.level_spin.value()
        
        # Create gradient image
        width = 20
        height = 150
        image = QtGui.QImage(width, height, QtGui.QImage.Format_RGB32)
        
        # Get color map
        color_map = self.lut_manager.color_maps[color_map_id]
        
        # Calculate value range
        min_val = level - window/2
        max_val = level + window/2
        
        # Fill image with gradient
        for y in range(height):
            # Calculate value (bottom to top)
            value = min_val + (max_val - min_val) * (height - 1 - y) / (height - 1)
            
            # Normalize value to 0-1 range
            norm_value = (value - min_val) / (max_val - min_val)
            norm_value = max(0, min(1, norm_value))
            
            # Find color in color map
            r, g, b = self.lut_manager._get_color_from_map(color_map, norm_value)
            
            # Fill row with color
            color = QtGui.qRgb(int(r*255), int(g*255), int(b*255))
            for x in range(width):
                image.setPixel(x, y, color)
        
        # Create pixmap and set to label
        pixmap = QtGui.QPixmap.fromImage(image)
        self.color_bar.setPixmap(pixmap)


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("High-Value LUT Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QVBoxLayout(central_widget)
    
    # Create high-value LUT widget
    lut_widget = HighValueLUTWidget()
    layout.addWidget(lut_widget)
    
    # Create texture optimizer
    texture_optimizer = OpenGLTextureOptimizer()
    
    # Print maximum texture size
    max_size_label = QtWidgets.QLabel(f"Maximum OpenGL Texture Size: {texture_optimizer.max_texture_size}")
    layout.addWidget(max_size_label)
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
