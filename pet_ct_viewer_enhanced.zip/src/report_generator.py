#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Report Generation Module for PET/CT Viewer
----------------------------------------
This module provides tools for generating reports from annotations and measurements.
"""

import os
import sys
import logging
import datetime
import json
import base64
from io import BytesIO
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import tempfile

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('ReportGenerator')

class ReportGenerator:
    """
    Class for generating reports from annotations and measurements.
    """
    
    def __init__(self):
        """Initialize the ReportGenerator."""
        self.annotations = []
        self.measurements = []
        self.patient_info = {}
        self.study_info = {}
        self.screenshots = []
        self.report_title = "PET/CT Imaging Report"
        self.report_date = datetime.datetime.now().strftime("%Y-%m-%d")
        self.institution = "Medical Imaging Center"
        self.physician = "Reporting Physician"
    
    def set_annotations(self, annotations):
        """Set annotations for the report."""
        self.annotations = annotations
    
    def set_measurements(self, measurements):
        """Set measurements for the report."""
        self.measurements = measurements
    
    def set_patient_info(self, patient_info):
        """Set patient information for the report."""
        self.patient_info = patient_info
    
    def set_study_info(self, study_info):
        """Set study information for the report."""
        self.study_info = study_info
    
    def set_report_metadata(self, title=None, institution=None, physician=None):
        """
        Set report metadata.
        
        Args:
            title (str, optional): Report title
            institution (str, optional): Institution name
            physician (str, optional): Physician name
        """
        if title:
            self.report_title = title
        if institution:
            self.institution = institution
        if physician:
            self.physician = physician
    
    def add_screenshot(self, image_path=None, image_data=None, description=""):
        """
        Add a screenshot to the report.
        
        Args:
            image_path (str, optional): Path to the screenshot image
            image_data (numpy.ndarray, optional): Image data as numpy array
            description (str, optional): Description of the screenshot
        """
        if image_path and os.path.exists(image_path):
            self.screenshots.append({
                'path': image_path,
                'data': None,
                'description': description
            })
        elif image_data is not None:
            # Save image data to temporary file
            temp_file = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
            plt.imsave(temp_file.name, image_data)
            temp_file.close()
            
            self.screenshots.append({
                'path': temp_file.name,
                'data': image_data,
                'description': description
            })
    
    def generate_report_html(self, output_path):
        """
        Generate an HTML report.
        
        Args:
            output_path (str): Path to save the HTML report
            
        Returns:
            bool: True if report generated successfully, False otherwise
        """
        try:
            # Create HTML content
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>{self.report_title}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; }}
                    h1 {{ color: #333366; }}
                    h2 {{ color: #336699; }}
                    table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f2f2f2; }}
                    .screenshot {{ margin: 20px 0; max-width: 100%; }}
                    .screenshot img {{ max-width: 100%; border: 1px solid #ddd; }}
                    .header {{ display: flex; justify-content: space-between; align-items: center; }}
                    .header-left {{ flex: 1; }}
                    .header-right {{ flex: 1; text-align: right; }}
                    .footer {{ margin-top: 30px; border-top: 1px solid #ddd; padding-top: 10px; font-size: 0.8em; }}
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="header-left">
                        <h1>{self.report_title}</h1>
                        <p>{self.institution}</p>
                    </div>
                    <div class="header-right">
                        <p>Date: {self.report_date}</p>
                        <p>Physician: {self.physician}</p>
                    </div>
                </div>
            """
            
            # Add patient information
            html_content += "<h2>Patient Information</h2>"
            html_content += "<table>"
            for key, value in self.patient_info.items():
                html_content += f"<tr><th>{key}</th><td>{value}</td></tr>"
            html_content += "</table>"
            
            # Add study information
            html_content += "<h2>Study Information</h2>"
            html_content += "<table>"
            for key, value in self.study_info.items():
                html_content += f"<tr><th>{key}</th><td>{value}</td></tr>"
            html_content += "</table>"
            
            # Add measurements
            if self.measurements:
                html_content += "<h2>Measurements</h2>"
                html_content += "<table>"
                html_content += "<tr><th>Type</th><th>Value</th><th>Unit</th><th>Location</th></tr>"
                for m in self.measurements:
                    m_type = m.get('type', 'Unknown')
                    m_value = m.get('value', 'N/A')
                    m_unit = m.get('unit', '')
                    m_location = ''
                    
                    if 'points' in m:
                        m_location = f"Points: {m['points']}"
                    elif 'point' in m:
                        m_location = f"Point: {m['point']}"
                    
                    html_content += f"<tr><td>{m_type}</td><td>{m_value}</td><td>{m_unit}</td><td>{m_location}</td></tr>"
                html_content += "</table>"
            
            # Add annotations
            if self.annotations:
                html_content += "<h2>Annotations</h2>"
                html_content += "<table>"
                html_content += "<tr><th>Type</th><th>Description</th><th>Location</th></tr>"
                for a in self.annotations:
                    a_type = a.get('type', 'Unknown')
                    a_desc = a.get('text', '') if a_type == 'text' else ''
                    a_location = ''
                    
                    if 'position' in a:
                        a_location = f"Position: {a['position']}"
                    elif 'points' in a:
                        a_location = f"Points: {a['points']}"
                    elif 'start_point' in a and 'end_point' in a:
                        a_location = f"From {a['start_point']} to {a['end_point']}"
                    
                    html_content += f"<tr><td>{a_type}</td><td>{a_desc}</td><td>{a_location}</td></tr>"
                html_content += "</table>"
            
            # Add findings section
            html_content += """
            <h2>Findings</h2>
            <p><em>This section should be completed by the physician.</em></p>
            <div style="border: 1px solid #ddd; padding: 10px; min-height: 200px;">
                <p>Findings will be entered here.</p>
            </div>
            """
            
            # Add impression section
            html_content += """
            <h2>Impression</h2>
            <p><em>This section should be completed by the physician.</em></p>
            <div style="border: 1px solid #ddd; padding: 10px; min-height: 100px;">
                <p>Impression will be entered here.</p>
            </div>
            """
            
            # Add screenshots
            if self.screenshots:
                html_content += "<h2>Images</h2>"
                for i, screenshot in enumerate(self.screenshots):
                    html_content += f"""
                    <div class="screenshot">
                        <h3>Image {i+1}</h3>
                        <p>{screenshot['description']}</p>
                        <img src="{screenshot['path']}" alt="Screenshot {i+1}">
                    </div>
                    """
            
            # Add footer
            html_content += f"""
            <div class="footer">
                <p>Generated on {self.report_date} by PET/CT DICOM Viewer</p>
            </div>
            """
            
            # Close HTML
            html_content += """
            </body>
            </html>
            """
            
            # Write to file
            with open(output_path, 'w') as f:
                f.write(html_content)
            
            logger.info(f"HTML report generated: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Error generating HTML report: {str(e)}")
            return False
    
    def generate_report_docx(self, output_path):
        """
        Generate a Word (DOCX) report.
        
        Args:
            output_path (str): Path to save the DOCX report
            
        Returns:
            bool: True if report generated successfully, False otherwise
        """
        try:
            # Import docx library (python-docx)
            from docx import Document
            from docx.shared import Inches, Pt
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            
            # Create a new document
            document = Document()
            
            # Add title
            title = document.add_heading(self.report_title, level=0)
            title.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # Add header with institution and date
            header = document.add_paragraph()
            header.add_run(f"{self.institution}").bold = True
            header.add_run(f"\nDate: {self.report_date}")
            header.add_run(f"\nPhysician: {self.physician}")
            
            # Add patient information
            document.add_heading('Patient Information', level=1)
            table = document.add_table(rows=1, cols=2)
            table.style = 'Table Grid'
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = 'Field'
            hdr_cells[1].text = 'Value'
            
            for key, value in self.patient_info.items():
                row_cells = table.add_row().cells
                row_cells[0].text = key
                row_cells[1].text = str(value)
            
            # Add study information
            document.add_heading('Study Information', level=1)
            table = document.add_table(rows=1, cols=2)
            table.style = 'Table Grid'
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = 'Field'
            hdr_cells[1].text = 'Value'
            
            for key, value in self.study_info.items():
                row_cells = table.add_row().cells
                row_cells[0].text = key
                row_cells[1].text = str(value)
            
            # Add measurements
            if self.measurements:
                document.add_heading('Measurements', level=1)
                table = document.add_table(rows=1, cols=4)
                table.style = 'Table Grid'
                hdr_cells = table.rows[0].cells
                hdr_cells[0].text = 'Type'
                hdr_cells[1].text = 'Value'
                hdr_cells[2].text = 'Unit'
                hdr_cells[3].text = 'Location'
                
                for m in self.measurements:
                    m_type = m.get('type', 'Unknown')
                    m_value = m.get('value', 'N/A')
                    m_unit = m.get('unit', '')
                    m_location = ''
                    
                    if 'points' in m:
                        m_location = f"Points: {m['points']}"
                    elif 'point' in m:
                        m_location = f"Point: {m['point']}"
                    
                    row_cells = table.add_row().cells
                    row_cells[0].text = str(m_type)
                    row_cells[1].text = str(m_value)
                    row_cells[2].text = str(m_unit)
                    row_cells[3].text = str(m_location)
            
            # Add annotations
            if self.annotations:
                document.add_heading('Annotations', level=1)
                table = document.add_table(rows=1, cols=3)
                table.style = 'Table Grid'
                hdr_cells = table.rows[0].cells
                hdr_cells[0].text = 'Type'
                hdr_cells[1].text = 'Description'
                hdr_cells[2].text = 'Location'
                
                for a in self.annotations:
                    a_type = a.get('type', 'Unknown')
                    a_desc = a.get('text', '') if a_type == 'text' else ''
                    a_location = ''
                    
                    if 'position' in a:
                        a_location = f"Position: {a['position']}"
                    elif 'points' in a:
                        a_location = f"Points: {a['points']}"
                    elif 'start_point' in a and 'end_point' in a:
                        a_location = f"From {a['start_point']} to {a['end_point']}"
                    
                    row_cells = table.add_row().cells
                    row_cells[0].text = str(a_type)
                    row_cells[1].text = str(a_desc)
                    row_cells[2].text = str(a_location)
            
            # Add findings section
            document.add_heading('Findings', level=1)
            document.add_paragraph('This section should be completed by the physician.')
            document.add_paragraph('_' * 50)
            document.add_paragraph('_' * 50)
            
            # Add impression section
            document.add_heading('Impression', level=1)
            document.add_paragraph('This section should be completed by the physician.')
            document.add_paragraph('_' * 50)
            
            # Add screenshots
            if self.screenshots:
                document.add_heading('Images', level=1)
                for i, screenshot in enumerate(self.screenshots):
                    document.add_heading(f'Image {i+1}', level=2)
                    document.add_paragraph(screenshot['description'])
                    document.add_picture(screenshot['path'], width=Inches(6.0))
            
            # Add footer
            footer = document.sections[0].footer
            footer_para = footer.paragraphs[0]
            footer_para.text = f"Generated on {self.report_date} by PET/CT DICOM Viewer"
            
            # Save the document
            document.save(output_path)
            
            logger.info(f"DOCX report generated: {output_path}")
            return True
        except ImportError:
            logger.error("python-docx library not installed. Install with: pip install python-docx")
            return False
        except Exception as e:
            logger.error(f"Error generating DOCX report: {str(e)}")
            return False
    
    def generate_report_pdf(self, output_path):
        """
        Generate a PDF report.
        
        Args:
            output_path (str): Path to save the PDF report
            
        Returns:
            bool: True if report generated successfully, False otherwise
        """
        try:
            # First generate HTML report
            html_path = output_path.replace('.pdf', '.html')
            if not self.generate_report_html(html_path):
                return False
            
            # Convert HTML to PDF using weasyprint
            from weasyprint import HTML
            HTML(html_path).write_pdf(output_path)
            
            # Remove temporary HTML file
            os.remove(html_path)
            
            logger.info(f"PDF report generated: {output_path}")
            return True
        except ImportError:
            logger.error("weasyprint library not installed. Install with: pip install weasyprint")
            return False
        except Exception as e:
            logger.error(f"Error generating PDF report: {str(e)}")
            return False
    
    def export_annotations_to_json(self, output_path):
        """
        Export annotations to a JSON file.
        
        Args:
            output_path (str): Path to save the JSON file
            
        Returns:
            bool: True if export successful, False otherwise
        """
        try:
            data = {
                'patient_info': self.patient_info,
                'study_info': self.study_info,
                'annotations': self.annotations,
                'measurements': self.measurements,
                'report_date': self.report_date,
                'report_title': self.report_title,
                'institution': self.institution,
                'physician': self.physician
            }
            
            with open(output_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info(f"Annotations exported to JSON: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Error exporting annotations to JSON: {str(e)}")
            return False
    
    def import_annotations_from_json(self, input_path):
        """
        Import annotations from a JSON file.
        
        Args:
            input_path (str): Path to the JSON file
            
        Returns:
            bool: True if import successful, False otherwise
        """
        try:
            with open(input_path, 'r') as f:
                data = json.load(f)
            
            if 'patient_info' in data:
                self.patient_info = data['patient_info']
            
            if 'study_info' in data:
                self.study_info = data['study_info']
            
            if 'annotations' in data:
                self.annotations = data['annotations']
            
            if 'measurements' in data:
                self.measurements = data['measurements']
            
            if 'report_title' in data:
                self.report_title = data['report_title']
            
            if 'institution' in data:
                self.institution = data['institution']
            
            if 'physician' in data:
                self.physician = data['physician']
            
            logger.info(f"Annotations imported from JSON: {input_path}")
            return True
        except Exception as e:
            logger.error(f"Error importing annotations from JSON: {str(e)}")
            return False


class AnnotationExporter:
    """
    Class for exporting annotations to various formats.
    """
    
    def __init__(self):
        """Initialize the AnnotationExporter."""
        pass
    
    def export_to_dicom_sr(self, annotations, measurements, output_path):
        """
        Export annotations to DICOM Structured Report.
        
        Args:
            annotations (list): List of annotations
            measurements (list): List of measurements
            output_path (str): Path to save the DICOM SR file
            
        Returns:
            bool: True if export successful, False otherwise
        """
        try:
            # This would use pydicom to create a DICOM SR
            # For simplicity, we'll just create a placeholder function
            logger.warning("DICOM SR export not fully implemented")
            
            # In a real implementation, we would:
            # 1. Create a DICOM SR dataset
            # 2. Add annotations and measurements
            # 3. Save the dataset
            
            return False
        except Exception as e:
            logger.error(f"Error exporting to DICOM SR: {str(e)}")
            return False
    
    def export_to_csv(self, measurements, output_path):
        """
        Export measurements to CSV file.
        
        Args:
            measurements (list): List of measurements
            output_path (str): Path to save the CSV file
            
        Returns:
            bool: True if export successful, False otherwise
        """
        try:
            import csv
            
            # Define CSV headers based on measurement types
            headers = ['Type', 'Value', 'Unit', 'Location']
            
            with open(output_path, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(headers)
                
                for m in measurements:
                    m_type = m.get('type', 'Unknown')
                    m_value = m.get('value', 'N/A')
                    m_unit = m.get('unit', '')
                    m_location = ''
                    
                    if 'points' in m:
                        m_location = f"Points: {m['points']}"
                    elif 'point' in m:
                        m_location = f"Point: {m['point']}"
                    
                    writer.writerow([m_type, m_value, m_unit, m_location])
            
            logger.info(f"Measurements exported to CSV: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Error exporting to CSV: {str(e)}")
            return False
    
    def export_to_excel(self, measurements, annotations, output_path):
        """
        Export measurements and annotations to Excel file.
        
        Args:
            measurements (list): List of measurements
            annotations (list): List of annotations
            output_path (str): Path to save the Excel file
            
        Returns:
            bool: True if export successful, False otherwise
        """
        try:
            import pandas as pd
            
            # Create measurements dataframe
            measurements_data = []
            for m in measurements:
                m_type = m.get('type', 'Unknown')
                m_value = m.get('value', 'N/A')
                m_unit = m.get('unit', '')
                m_location = ''
                
                if 'points' in m:
                    m_location = f"Points: {m['points']}"
                elif 'point' in m:
                    m_location = f"Point: {m['point']}"
                
                measurements_data.append({
                    'Type': m_type,
                    'Value': m_value,
                    'Unit': m_unit,
                    'Location': m_location
                })
            
            # Create annotations dataframe
            annotations_data = []
            for a in annotations:
                a_type = a.get('type', 'Unknown')
                a_desc = a.get('text', '') if a_type == 'text' else ''
                a_location = ''
                
                if 'position' in a:
                    a_location = f"Position: {a['position']}"
                elif 'points' in a:
                    a_location = f"Points: {a['points']}"
                elif 'start_point' in a and 'end_point' in a:
                    a_location = f"From {a['start_point']} to {a['end_point']}"
                
                annotations_data.append({
                    'Type': a_type,
                    'Description': a_desc,
                    'Location': a_location
                })
            
            # Create Excel writer
            with pd.ExcelWriter(output_path) as writer:
                # Write measurements to sheet
                if measurements_data:
                    pd.DataFrame(measurements_data).to_excel(writer, sheet_name='Measurements', index=False)
                
                # Write annotations to sheet
                if annotations_data:
                    pd.DataFrame(annotations_data).to_excel(writer, sheet_name='Annotations', index=False)
            
            logger.info(f"Data exported to Excel: {output_path}")
            return True
        except ImportError:
            logger.error("pandas library not installed. Install with: pip install pandas openpyxl")
            return False
        except Exception as e:
            logger.error(f"Error exporting to Excel: {str(e)}")
            return False


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    report_gen = ReportGenerator()
    
    # Set sample data
    report_gen.set_patient_info({
        'PatientName': 'John Doe',
        'PatientID': '12345',
        'PatientBirthDate': '19700101',
        'PatientSex': 'M'
    })
    
    report_gen.set_study_info({
        'StudyDescription': 'Whole Body PET/CT',
        'StudyDate': '20250101',
        'StudyTime': '120000',
        'Modality': 'PT/CT'
    })
    
    # Add sample measurements
    report_gen.set_measurements([
        {
            'type': 'distance',
            'value': 45.7,
            'unit': 'mm',
            'points': [(10, 20, 30), (50, 60, 70)]
        },
        {
            'type': 'SUV',
            'value': 5.2,
            'unit': 'g/ml',
            'point': (25, 35, 45)
        }
    ])
    
    # Add sample annotations
    report_gen.set_annotations([
        {
            'type': 'text',
            'text': 'Suspicious lesion',
            'position': (30, 40, 50)
        },
        {
            'type': 'arrow',
            'start_point': (10, 20, 30),
            'end_point': (40, 50, 60)
        }
    ])
    
    # Check if output directory was provided
    if len(sys.argv) > 1:
        output_dir = sys.argv[1]
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate reports
        html_path = os.path.join(output_dir, 'report.html')
        report_gen.generate_report_html(html_path)
        
        try:
            docx_path = os.path.join(output_dir, 'report.docx')
            report_gen.generate_report_docx(docx_path)
        except ImportError:
            print("Skipping DOCX report - python-docx not installed")
        
        try:
            pdf_path = os.path.join(output_dir, 'report.pdf')
            report_gen.generate_report_pdf(pdf_path)
        except ImportError:
            print("Skipping PDF report - weasyprint not installed")
        
        # Export annotations
        json_path = os.path.join(output_dir, 'annotations.json')
        report_gen.export_annotations_to_json(json_path)
        
        # Export measurements using AnnotationExporter
        exporter = AnnotationExporter()
        csv_path = os.path.join(output_dir, 'measurements.csv')
        exporter.export_to_csv(report_gen.measurements, csv_path)
        
        try:
            excel_path = os.path.join(output_dir, 'data.xlsx')
            exporter.export_to_excel(report_gen.measurements, report_gen.annotations, excel_path)
        except ImportError:
            print("Skipping Excel export - pandas not installed")
    else:
        print("Usage: python report_generator.py <output_directory>")
