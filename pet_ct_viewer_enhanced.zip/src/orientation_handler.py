#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Orientation Handler Module for PET/CT Viewer
------------------------------------------
This module provides orientation adjustment and standardization for DICOM images.
"""

import os
import sys
import logging
import numpy as np
import vtk
from scipy import ndimage

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('OrientationHandler')

class OrientationHandler:
    """
    Class for handling orientation adjustment and standardization of DICOM images.
    """
    
    # Constants for standard orientations
    ORIENTATION_AXIAL = 0
    ORIENTATION_CORONAL = 1
    ORIENTATION_SAGITTAL = 2
    
    # Constants for standard planes
    PLANE_AXIAL = 0    # XY plane
    PLANE_CORONAL = 1  # XZ plane
    PLANE_SAGITTAL = 2 # YZ plane
    
    # Constants for standard directions
    DIRECTION_LR = 0  # Left to Right
    DIRECTION_RL = 1  # Right to Left
    DIRECTION_AP = 2  # Anterior to Posterior
    DIRECTION_PA = 3  # Posterior to Anterior
    DIRECTION_IS = 4  # Inferior to Superior
    DIRECTION_SI = 5  # Superior to Inferior
    
    def __init__(self):
        """Initialize the OrientationHandler."""
        # Initialize orientation matrices
        self.orientation_matrices = self._create_standard_orientation_matrices()
        
        # Current orientation for each plane
        self.current_orientations = {
            self.PLANE_AXIAL: self.ORIENTATION_AXIAL,
            self.PLANE_CORONAL: self.ORIENTATION_CORONAL,
            self.PLANE_SAGITTAL: self.ORIENTATION_SAGITTAL
        }
        
        # Current directions for each plane
        self.current_directions = {
            self.PLANE_AXIAL: {
                'horizontal': self.DIRECTION_LR,
                'vertical': self.DIRECTION_AP
            },
            self.PLANE_CORONAL: {
                'horizontal': self.DIRECTION_LR,
                'vertical': self.DIRECTION_IS
            },
            self.PLANE_SAGITTAL: {
                'horizontal': self.DIRECTION_AP,
                'vertical': self.DIRECTION_IS
            }
        }
    
    def _create_standard_orientation_matrices(self):
        """
        Create standard orientation matrices.
        
        Returns:
            dict: Dictionary of orientation matrices
        """
        # Create matrices
        matrices = {}
        
        # Axial orientation (XY plane, Z points up)
        axial = vtk.vtkMatrix4x4()
        axial.Identity()
        matrices[self.ORIENTATION_AXIAL] = axial
        
        # Coronal orientation (XZ plane, Y points up)
        coronal = vtk.vtkMatrix4x4()
        coronal.Identity()
        coronal.SetElement(1, 1, 0)
        coronal.SetElement(1, 2, 1)
        coronal.SetElement(2, 1, 1)
        coronal.SetElement(2, 2, 0)
        matrices[self.ORIENTATION_CORONAL] = coronal
        
        # Sagittal orientation (YZ plane, X points up)
        sagittal = vtk.vtkMatrix4x4()
        sagittal.Identity()
        sagittal.SetElement(0, 0, 0)
        sagittal.SetElement(0, 2, 1)
        sagittal.SetElement(2, 0, 1)
        sagittal.SetElement(2, 2, 0)
        matrices[self.ORIENTATION_SAGITTAL] = sagittal
        
        return matrices
    
    def get_orientation_matrix(self, orientation):
        """
        Get the orientation matrix for a specific orientation.
        
        Args:
            orientation (int): Orientation constant
            
        Returns:
            vtkMatrix4x4: Orientation matrix
        """
        if orientation in self.orientation_matrices:
            return self.orientation_matrices[orientation]
        else:
            logger.warning(f"Unknown orientation: {orientation}")
            return vtk.vtkMatrix4x4()
    
    def get_current_orientation(self, plane):
        """
        Get the current orientation for a specific plane.
        
        Args:
            plane (int): Plane constant
            
        Returns:
            int: Orientation constant
        """
        if plane in self.current_orientations:
            return self.current_orientations[plane]
        else:
            logger.warning(f"Unknown plane: {plane}")
            return self.ORIENTATION_AXIAL
    
    def set_current_orientation(self, plane, orientation):
        """
        Set the current orientation for a specific plane.
        
        Args:
            plane (int): Plane constant
            orientation (int): Orientation constant
            
        Returns:
            bool: True if successful, False otherwise
        """
        if plane not in self.current_orientations:
            logger.warning(f"Unknown plane: {plane}")
            return False
        
        if orientation not in self.orientation_matrices:
            logger.warning(f"Unknown orientation: {orientation}")
            return False
        
        self.current_orientations[plane] = orientation
        return True
    
    def flip_horizontal(self, plane):
        """
        Flip the horizontal direction for a specific plane.
        
        Args:
            plane (int): Plane constant
            
        Returns:
            bool: True if successful, False otherwise
        """
        if plane not in self.current_directions:
            logger.warning(f"Unknown plane: {plane}")
            return False
        
        # Get current direction
        current = self.current_directions[plane]['horizontal']
        
        # Flip direction
        if current == self.DIRECTION_LR:
            self.current_directions[plane]['horizontal'] = self.DIRECTION_RL
        elif current == self.DIRECTION_RL:
            self.current_directions[plane]['horizontal'] = self.DIRECTION_LR
        elif current == self.DIRECTION_AP:
            self.current_directions[plane]['horizontal'] = self.DIRECTION_PA
        elif current == self.DIRECTION_PA:
            self.current_directions[plane]['horizontal'] = self.DIRECTION_AP
        
        return True
    
    def flip_vertical(self, plane):
        """
        Flip the vertical direction for a specific plane.
        
        Args:
            plane (int): Plane constant
            
        Returns:
            bool: True if successful, False otherwise
        """
        if plane not in self.current_directions:
            logger.warning(f"Unknown plane: {plane}")
            return False
        
        # Get current direction
        current = self.current_directions[plane]['vertical']
        
        # Flip direction
        if current == self.DIRECTION_IS:
            self.current_directions[plane]['vertical'] = self.DIRECTION_SI
        elif current == self.DIRECTION_SI:
            self.current_directions[plane]['vertical'] = self.DIRECTION_IS
        elif current == self.DIRECTION_AP:
            self.current_directions[plane]['vertical'] = self.DIRECTION_PA
        elif current == self.DIRECTION_PA:
            self.current_directions[plane]['vertical'] = self.DIRECTION_AP
        
        return True
    
    def get_direction_labels(self, plane):
        """
        Get the direction labels for a specific plane.
        
        Args:
            plane (int): Plane constant
            
        Returns:
            dict: Dictionary with direction labels
        """
        if plane not in self.current_directions:
            logger.warning(f"Unknown plane: {plane}")
            return {'left': 'L', 'right': 'R', 'top': 'T', 'bottom': 'B'}
        
        # Get current directions
        horizontal = self.current_directions[plane]['horizontal']
        vertical = self.current_directions[plane]['vertical']
        
        # Set labels based on directions
        labels = {}
        
        # Horizontal labels
        if horizontal == self.DIRECTION_LR:
            labels['left'] = 'L'
            labels['right'] = 'R'
        elif horizontal == self.DIRECTION_RL:
            labels['left'] = 'R'
            labels['right'] = 'L'
        elif horizontal == self.DIRECTION_AP:
            labels['left'] = 'A'
            labels['right'] = 'P'
        elif horizontal == self.DIRECTION_PA:
            labels['left'] = 'P'
            labels['right'] = 'A'
        
        # Vertical labels
        if vertical == self.DIRECTION_IS:
            labels['top'] = 'I'
            labels['bottom'] = 'S'
        elif vertical == self.DIRECTION_SI:
            labels['top'] = 'S'
            labels['bottom'] = 'I'
        elif vertical == self.DIRECTION_AP:
            labels['top'] = 'A'
            labels['bottom'] = 'P'
        elif vertical == self.DIRECTION_PA:
            labels['top'] = 'P'
            labels['bottom'] = 'A'
        
        return labels
    
    def create_standard_orientation_matrix(self):
        """
        Create a standard radiological orientation matrix.
        
        Returns:
            vtkMatrix4x4: Standard orientation matrix
        """
        # Create standard orientation matrix (radiological convention)
        matrix = vtk.vtkMatrix4x4()
        matrix.Identity()
        
        # Set to RAI orientation (Right-Anterior-Inferior)
        # X increases from patient right to left
        # Y increases from patient posterior to anterior
        # Z increases from patient inferior to superior
        matrix.SetElement(0, 0, -1)  # Flip X
        
        return matrix
    
    def apply_orientation_to_volume(self, volume, orientation_matrix):
        """
        Apply an orientation matrix to a volume.
        
        Args:
            volume (vtkImageData): Volume to orient
            orientation_matrix (vtkMatrix4x4): Orientation matrix
            
        Returns:
            vtkImageData: Oriented volume
        """
        if volume is None or orientation_matrix is None:
            logger.warning("Volume or orientation matrix is None")
            return None
        
        try:
            # Create transform
            transform = vtk.vtkTransform()
            transform.SetMatrix(orientation_matrix)
            
            # Apply transform to volume
            transformer = vtk.vtkImageReslice()
            transformer.SetInputData(volume)
            transformer.SetResliceTransform(transform)
            transformer.SetInterpolationModeToLinear()
            transformer.Update()
            
            return transformer.GetOutput()
        except Exception as e:
            logger.error(f"Error applying orientation: {str(e)}")
            return None
    
    def apply_orientation_to_array(self, array, orientation_code):
        """
        Apply an orientation to a numpy array.
        
        Args:
            array (numpy.ndarray): Array to orient
            orientation_code (str): Orientation code (e.g., 'RAI', 'LPS')
            
        Returns:
            numpy.ndarray: Oriented array
        """
        if array is None or not orientation_code:
            logger.warning("Array or orientation code is None")
            return None
        
        try:
            # Parse orientation code
            if len(orientation_code) != 3:
                logger.warning(f"Invalid orientation code: {orientation_code}")
                return array
            
            # Get current orientation (assuming RAS by default)
            current_orientation = 'RAS'
            
            # Create a copy of the array
            result = array.copy()
            
            # Apply flips as needed
            if current_orientation[0] != orientation_code[0]:
                result = np.flip(result, axis=2)  # Flip X
            
            if current_orientation[1] != orientation_code[1]:
                result = np.flip(result, axis=1)  # Flip Y
            
            if current_orientation[2] != orientation_code[2]:
                result = np.flip(result, axis=0)  # Flip Z
            
            return result
        except Exception as e:
            logger.error(f"Error applying orientation to array: {str(e)}")
            return array
    
    def standardize_orientation(self, array, metadata=None):
        """
        Standardize the orientation of a numpy array to radiological convention.
        
        Args:
            array (numpy.ndarray): Array to standardize
            metadata (dict, optional): DICOM metadata with orientation information
            
        Returns:
            numpy.ndarray: Standardized array
        """
        if array is None:
            logger.warning("Array is None")
            return None
        
        try:
            # If metadata is available, use it to determine orientation
            if metadata and 'ImageOrientationPatient' in metadata:
                # Extract orientation vectors
                orientation = metadata['ImageOrientationPatient']
                if len(orientation) == 6:
                    # Extract row and column vectors
                    row_vector = np.array(orientation[:3])
                    col_vector = np.array(orientation[3:])
                    
                    # Calculate normal vector (cross product)
                    normal_vector = np.cross(row_vector, col_vector)
                    
                    # Determine orientation based on vectors
                    # This is a simplified approach; a real implementation would be more complex
                    if abs(normal_vector[0]) > abs(normal_vector[1]) and abs(normal_vector[0]) > abs(normal_vector[2]):
                        # Sagittal orientation
                        if normal_vector[0] > 0:
                            return self.apply_orientation_to_array(array, 'RAS')
                        else:
                            return self.apply_orientation_to_array(array, 'LAS')
                    elif abs(normal_vector[1]) > abs(normal_vector[0]) and abs(normal_vector[1]) > abs(normal_vector[2]):
                        # Coronal orientation
                        if normal_vector[1] > 0:
                            return self.apply_orientation_to_array(array, 'RPS')
                        else:
                            return self.apply_orientation_to_array(array, 'RAS')
                    else:
                        # Axial orientation
                        if normal_vector[2] > 0:
                            return self.apply_orientation_to_array(array, 'RAI')
                        else:
                            return self.apply_orientation_to_array(array, 'RAS')
            
            # Default to radiological convention (RAI)
            return self.apply_orientation_to_array(array, 'RAI')
        except Exception as e:
            logger.error(f"Error standardizing orientation: {str(e)}")
            return array
    
    def rotate_array(self, array, axis, angle_degrees):
        """
        Rotate a numpy array around an axis.
        
        Args:
            array (numpy.ndarray): Array to rotate
            axis (int): Axis to rotate around (0=X, 1=Y, 2=Z)
            angle_degrees (float): Rotation angle in degrees
            
        Returns:
            numpy.ndarray: Rotated array
        """
        if array is None:
            logger.warning("Array is None")
            return None
        
        try:
            # Convert angle to radians
            angle_rad = np.radians(angle_degrees)
            
            # Rotate using scipy's ndimage
            return ndimage.rotate(array, angle_degrees, axes=((axis+1)%3, (axis+2)%3), reshape=False, order=1)
        except Exception as e:
            logger.error(f"Error rotating array: {str(e)}")
            return array
    
    def create_orientation_actors(self, renderer, viewport_id=0):
        """
        Create orientation marker actors for a renderer.
        
        Args:
            renderer (vtkRenderer): Renderer to add actors to
            viewport_id (int): Viewport ID for orientation
            
        Returns:
            list: List of orientation actors
        """
        if renderer is None:
            logger.warning("Renderer is None")
            return []
        
        try:
            # Get direction labels based on viewport
            plane = viewport_id % 3  # Map viewport to plane
            labels = self.get_direction_labels(plane)
            
            # Create actors for each label
            actors = []
            
            # Create text actors
            for position, label in labels.items():
                text_actor = vtk.vtkTextActor()
                text_actor.SetInput(label)
                
                # Set text properties
                text_property = text_actor.GetTextProperty()
                text_property.SetColor(1, 1, 1)  # White text
                text_property.SetFontSize(14)
                text_property.SetBold(True)
                text_property.SetShadow(True)
                
                # Set position
                if position == 'left':
                    text_actor.SetPosition(10, renderer.GetSize()[1] // 2)
                elif position == 'right':
                    text_actor.SetPosition(renderer.GetSize()[0] - 20, renderer.GetSize()[1] // 2)
                elif position == 'top':
                    text_actor.SetPosition(renderer.GetSize()[0] // 2, renderer.GetSize()[1] - 20)
                elif position == 'bottom':
                    text_actor.SetPosition(renderer.GetSize()[0] // 2, 10)
                
                # Add to renderer
                renderer.AddActor2D(text_actor)
                actors.append(text_actor)
            
            return actors
        except Exception as e:
            logger.error(f"Error creating orientation actors: {str(e)}")
            return []


class OrientationWidget(vtk.vtkOrientationMarkerWidget):
    """
    Widget for displaying orientation markers.
    """
    
    def __init__(self, renderer=None, viewport_id=0):
        """
        Initialize the OrientationWidget.
        
        Args:
            renderer (vtkRenderer, optional): Renderer to attach to
            viewport_id (int): Viewport ID for orientation
        """
        super(OrientationWidget, self).__init__()
        
        # Create orientation handler
        self.orientation_handler = OrientationHandler()
        
        # Create axes actor
        self.axes_actor = vtk.vtkAxesActor()
        
        # Set up labels based on viewport
        plane = viewport_id % 3  # Map viewport to plane
        labels = self.orientation_handler.get_direction_labels(plane)
        
        # Set axis labels
        self.axes_actor.SetXAxisLabelText(labels.get('right', 'R'))
        self.axes_actor.GetXAxisCaptionActor2D().GetTextActor().GetTextProperty().SetColor(1, 0, 0)
        
        self.axes_actor.SetYAxisLabelText(labels.get('top', 'S'))
        self.axes_actor.GetYAxisCaptionActor2D().GetTextActor().GetTextProperty().SetColor(0, 1, 0)
        
        self.axes_actor.SetZAxisLabelText("Z")
        self.axes_actor.GetZAxisCaptionActor2D().GetTextActor().GetTextProperty().SetColor(0, 0, 1)
        
        # Set up widget
        self.SetOrientationMarker(self.axes_actor)
        self.SetViewport(0.0, 0.0, 0.2, 0.2)  # Bottom-left corner
        self.SetEnabled(1)
        self.InteractiveOff()
        
        # Attach to renderer if provided
        if renderer:
            self.SetDefaultRenderer(renderer)
            self.SetInteractor(renderer.GetRenderWindow().GetInteractor())
    
    def update_orientation(self, plane):
        """
        Update the orientation based on plane.
        
        Args:
            plane (int): Plane constant
        """
        # Get direction labels
        labels = self.orientation_handler.get_direction_labels(plane)
        
        # Update axis labels
        self.axes_actor.SetXAxisLabelText(labels.get('right', 'R'))
        self.axes_actor.SetYAxisLabelText(labels.get('top', 'S'))


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    orientation_handler = OrientationHandler()
    
    # Print direction labels for each plane
    for plane in [OrientationHandler.PLANE_AXIAL, OrientationHandler.PLANE_CORONAL, OrientationHandler.PLANE_SAGITTAL]:
        labels = orientation_handler.get_direction_labels(plane)
        print(f"Plane {plane} labels: {labels}")
    
    # Test flipping
    orientation_handler.flip_horizontal(OrientationHandler.PLANE_AXIAL)
    labels = orientation_handler.get_direction_labels(OrientationHandler.PLANE_AXIAL)
    print(f"After horizontal flip, axial labels: {labels}")
    
    orientation_handler.flip_vertical(OrientationHandler.PLANE_AXIAL)
    labels = orientation_handler.get_direction_labels(OrientationHandler.PLANE_AXIAL)
    print(f"After vertical flip, axial labels: {labels}")
    
    # Create a standard orientation matrix
    matrix = orientation_handler.create_standard_orientation_matrix()
    print("Standard orientation matrix:")
    for i in range(4):
        row = [matrix.GetElement(i, j) for j in range(4)]
        print(row)
