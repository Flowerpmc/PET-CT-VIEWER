#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Progress Indicator Module for PET/CT Viewer
------------------------------------------
This module provides progress tracking and visualization for data loading operations.
"""

import os
import sys
import logging
import time
import threading
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('ProgressIndicator')

class ProgressTracker:
    """
    Class for tracking progress of operations.
    """
    
    def __init__(self):
        """Initialize the ProgressTracker."""
        self.total_items = 0
        self.completed_items = 0
        self.current_item_name = ""
        self.current_item_progress = 0
        self.start_time = None
        self.is_active = False
        self.callbacks = []
    
    def start(self, total_items=0, item_name=""):
        """
        Start tracking progress.
        
        Args:
            total_items (int): Total number of items to process
            item_name (str): Name of the first item
        """
        self.total_items = total_items
        self.completed_items = 0
        self.current_item_name = item_name
        self.current_item_progress = 0
        self.start_time = time.time()
        self.is_active = True
        self._notify_callbacks()
    
    def update_total(self, total_items):
        """
        Update the total number of items.
        
        Args:
            total_items (int): New total number of items
        """
        self.total_items = total_items
        self._notify_callbacks()
    
    def update_item(self, item_name, progress=0):
        """
        Update the current item.
        
        Args:
            item_name (str): Name of the current item
            progress (float): Progress of the current item (0-100)
        """
        self.current_item_name = item_name
        self.current_item_progress = progress
        self._notify_callbacks()
    
    def increment_completed(self):
        """Increment the number of completed items."""
        self.completed_items += 1
        self.current_item_progress = 0
        self._notify_callbacks()
    
    def complete(self):
        """Mark the tracking as complete."""
        self.completed_items = self.total_items
        self.current_item_progress = 100
        self.is_active = False
        self._notify_callbacks()
    
    def get_overall_progress(self):
        """
        Get the overall progress percentage.
        
        Returns:
            float: Progress percentage (0-100)
        """
        if self.total_items == 0:
            return 0
        
        # Calculate base progress from completed items
        base_progress = (self.completed_items / self.total_items) * 100
        
        # Add progress from current item
        if self.completed_items < self.total_items:
            item_contribution = (1 / self.total_items) * self.current_item_progress
            return base_progress + item_contribution
        else:
            return 100
    
    def get_elapsed_time(self):
        """
        Get the elapsed time in seconds.
        
        Returns:
            float: Elapsed time in seconds
        """
        if self.start_time is None:
            return 0
        return time.time() - self.start_time
    
    def get_estimated_time_remaining(self):
        """
        Get the estimated time remaining in seconds.
        
        Returns:
            float: Estimated time remaining in seconds, or None if unknown
        """
        if not self.is_active or self.total_items == 0 or self.completed_items == 0:
            return None
        
        progress = self.get_overall_progress() / 100
        if progress <= 0:
            return None
        
        elapsed = self.get_elapsed_time()
        total_estimated = elapsed / progress
        remaining = total_estimated - elapsed
        
        return max(0, remaining)
    
    def add_callback(self, callback):
        """
        Add a callback function to be called on progress updates.
        
        Args:
            callback (callable): Function to call with progress updates
        """
        if callback not in self.callbacks:
            self.callbacks.append(callback)
    
    def remove_callback(self, callback):
        """
        Remove a callback function.
        
        Args:
            callback (callable): Function to remove
        """
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def _notify_callbacks(self):
        """Notify all registered callbacks of progress update."""
        progress_info = {
            'total_items': self.total_items,
            'completed_items': self.completed_items,
            'current_item': self.current_item_name,
            'current_progress': self.current_item_progress,
            'overall_progress': self.get_overall_progress(),
            'elapsed_time': self.get_elapsed_time(),
            'remaining_time': self.get_estimated_time_remaining(),
            'is_active': self.is_active
        }
        
        for callback in self.callbacks:
            try:
                callback(progress_info)
            except Exception as e:
                logger.error(f"Error in progress callback: {str(e)}")


class ProgressDialog(QtWidgets.QDialog):
    """
    Dialog for displaying progress information.
    """
    
    def __init__(self, parent=None, tracker=None):
        """
        Initialize the ProgressDialog.
        
        Args:
            parent (QWidget, optional): Parent widget
            tracker (ProgressTracker, optional): Progress tracker
        """
        super(ProgressDialog, self).__init__(parent)
        
        # Set dialog properties
        self.setWindowTitle("Loading Progress")
        self.setMinimumWidth(400)
        self.setMinimumHeight(150)
        self.setModal(True)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create labels
        self.status_label = QtWidgets.QLabel("Initializing...")
        self.item_label = QtWidgets.QLabel("")
        self.time_label = QtWidgets.QLabel("")
        
        # Create progress bars
        self.overall_progress = QtWidgets.QProgressBar()
        self.overall_progress.setRange(0, 100)
        self.overall_progress.setValue(0)
        
        self.item_progress = QtWidgets.QProgressBar()
        self.item_progress.setRange(0, 100)
        self.item_progress.setValue(0)
        
        # Create cancel button
        self.cancel_button = QtWidgets.QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        
        # Add widgets to layout
        layout.addWidget(self.status_label)
        layout.addWidget(self.overall_progress)
        layout.addWidget(self.item_label)
        layout.addWidget(self.item_progress)
        layout.addWidget(self.time_label)
        layout.addWidget(self.cancel_button, 0, QtCore.Qt.AlignRight)
        
        # Set tracker
        self.tracker = tracker
        if self.tracker:
            self.tracker.add_callback(self.update_progress)
        
        # Create timer for updates
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  # Update every second
    
    def update_progress(self, progress_info):
        """
        Update the dialog with progress information.
        
        Args:
            progress_info (dict): Progress information
        """
        # Update overall progress
        self.overall_progress.setValue(int(progress_info['overall_progress']))
        
        # Update status label
        status_text = f"Processing {progress_info['completed_items']} of {progress_info['total_items']} items"
        self.status_label.setText(status_text)
        
        # Update item progress
        self.item_label.setText(progress_info['current_item'])
        self.item_progress.setValue(int(progress_info['current_progress']))
        
        # Update time label
        self.update_time()
        
        # Auto-close if complete
        if not progress_info['is_active']:
            self.timer.stop()
            QtCore.QTimer.singleShot(1000, self.accept)
    
    def update_time(self):
        """Update the time label with elapsed and remaining time."""
        if not self.tracker:
            return
        
        elapsed = self.tracker.get_elapsed_time()
        remaining = self.tracker.get_estimated_time_remaining()
        
        elapsed_str = self._format_time(elapsed)
        time_text = f"Elapsed: {elapsed_str}"
        
        if remaining is not None:
            remaining_str = self._format_time(remaining)
            time_text += f" | Remaining: {remaining_str}"
        
        self.time_label.setText(time_text)
    
    def _format_time(self, seconds):
        """
        Format time in seconds to a human-readable string.
        
        Args:
            seconds (float): Time in seconds
            
        Returns:
            str: Formatted time string
        """
        if seconds is None:
            return "Unknown"
        
        minutes, seconds = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"


class ProgressBar(QtWidgets.QWidget):
    """
    Widget for displaying progress information in the main UI.
    """
    
    def __init__(self, parent=None, tracker=None):
        """
        Initialize the ProgressBar.
        
        Args:
            parent (QWidget, optional): Parent widget
            tracker (ProgressTracker, optional): Progress tracker
        """
        super(ProgressBar, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create progress bar
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        
        # Create status label
        self.status_label = QtWidgets.QLabel("")
        
        # Add widgets to layout
        layout.addWidget(self.progress_bar, 1)
        layout.addWidget(self.status_label)
        
        # Set tracker
        self.tracker = tracker
        if self.tracker:
            self.tracker.add_callback(self.update_progress)
        
        # Hide initially
        self.setVisible(False)
    
    def update_progress(self, progress_info):
        """
        Update the progress bar with progress information.
        
        Args:
            progress_info (dict): Progress information
        """
        # Show if active
        self.setVisible(progress_info['is_active'])
        
        if not progress_info['is_active']:
            return
        
        # Update progress bar
        self.progress_bar.setValue(int(progress_info['overall_progress']))
        
        # Update status label
        if progress_info['total_items'] > 0:
            status_text = f"{progress_info['completed_items']}/{progress_info['total_items']}"
            if progress_info['current_item']:
                status_text += f" - {progress_info['current_item']}"
            self.status_label.setText(status_text)
        else:
            self.status_label.setText(progress_info['current_item'])


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create tracker
    tracker = ProgressTracker()
    
    # Create dialog
    dialog = ProgressDialog(tracker=tracker)
    dialog.show()
    
    # Simulate progress in a separate thread
    def simulate_progress():
        tracker.start(10, "Loading DICOM files")
        
        for i in range(10):
            # Simulate item progress
            for j in range(0, 101, 10):
                tracker.update_item(f"Processing file {i+1}", j)
                time.sleep(0.1)
            
            # Mark item as complete
            tracker.increment_completed()
            time.sleep(0.2)
        
        # Mark all as complete
        tracker.complete()
    
    thread = threading.Thread(target=simulate_progress)
    thread.daemon = True
    thread.start()
    
    sys.exit(app.exec_())
