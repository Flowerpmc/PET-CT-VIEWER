#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Enhanced DICOM Loader Module for PET/CT Viewer
--------------------------------------------
This module provides enhanced DICOM loading capabilities with progress tracking.
"""

import os
import sys
import logging
import numpy as np
import pydicom
from pydicom.errors import InvalidDicomError
from progress_indicator import ProgressTracker

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('DicomLoader')

class DicomLoader:
    """
    Class for loading and processing DICOM files with progress tracking.
    """
    
    def __init__(self):
        """Initialize the DicomLoader."""
        self.pet_series_list = []
        self.ct_series_list = []
        self.selected_pet_series = None
        self.selected_ct_series = None
        self.pet_array = None
        self.ct_array = None
        self.pet_metadata = {}
        self.ct_metadata = {}
        self.patient_info = {}
        self.progress_tracker = ProgressTracker()
    
    def load_directory(self, directory_path):
        """
        Load DICOM files from a directory.
        
        Args:
            directory_path (str): Path to directory containing DICOM files
            
        Returns:
            dict: Dictionary with loading results
        """
        if not os.path.exists(directory_path):
            logger.error(f"Directory does not exist: {directory_path}")
            return {'status': 'error', 'message': f"Directory does not exist: {directory_path}"}
        
        try:
            # Start progress tracking
            self.progress_tracker.start(0, "Scanning directory")
            
            # Find all potential DICOM files
            dicom_files = []
            for root, _, files in os.walk(directory_path):
                for file in files:
                    if file.lower().endswith(('.dcm', '.ima')) or '.' not in file:
                        dicom_files.append(os.path.join(root, file))
            
            if not dicom_files:
                self.progress_tracker.complete()
                logger.warning(f"No DICOM files found in: {directory_path}")
                return {'status': 'error', 'message': f"No DICOM files found in: {directory_path}"}
            
            # Update total items
            self.progress_tracker.update_total(len(dicom_files))
            
            # Process DICOM files
            self.pet_series_list = []
            self.ct_series_list = []
            series_dict = {}
            
            for i, file_path in enumerate(dicom_files):
                self.progress_tracker.update_item(f"Reading {os.path.basename(file_path)}", 0)
                
                try:
                    # Read DICOM file
                    ds = pydicom.dcmread(file_path, force=True)
                    
                    # Check if it's a valid DICOM file with required attributes
                    if not hasattr(ds, 'SOPClassUID') or not hasattr(ds, 'SeriesInstanceUID'):
                        continue
                    
                    # Get series UID
                    series_uid = ds.SeriesInstanceUID
                    
                    # Add to series dictionary
                    if series_uid not in series_dict:
                        series_dict[series_uid] = {
                            'files': [],
                            'modality': ds.Modality if hasattr(ds, 'Modality') else 'Unknown',
                            'series_number': int(ds.SeriesNumber) if hasattr(ds, 'SeriesNumber') else 0,
                            'series_description': ds.SeriesDescription if hasattr(ds, 'SeriesDescription') else 'Unknown',
                            'patient_id': ds.PatientID if hasattr(ds, 'PatientID') else 'Unknown',
                            'patient_name': str(ds.PatientName) if hasattr(ds, 'PatientName') else 'Unknown',
                            'study_instance_uid': ds.StudyInstanceUID if hasattr(ds, 'StudyInstanceUID') else '',
                            'study_description': ds.StudyDescription if hasattr(ds, 'StudyDescription') else 'Unknown'
                        }
                    
                    # Add file to series
                    series_dict[series_uid]['files'].append((file_path, ds))
                    
                    # Update progress
                    self.progress_tracker.update_item(f"Reading {os.path.basename(file_path)}", 100)
                    self.progress_tracker.increment_completed()
                    
                except (InvalidDicomError, AttributeError, IOError) as e:
                    logger.warning(f"Error reading file {file_path}: {str(e)}")
                    self.progress_tracker.increment_completed()
            
            # Organize series by modality
            for series_uid, series_info in series_dict.items():
                if series_info['modality'] == 'PT':
                    self.pet_series_list.append({
                        'SeriesInstanceUID': series_uid,
                        'SeriesNumber': series_info['series_number'],
                        'SeriesDescription': series_info['series_description'],
                        'PatientID': series_info['patient_id'],
                        'PatientName': series_info['patient_name'],
                        'StudyInstanceUID': series_info['study_instance_uid'],
                        'StudyDescription': series_info['study_description'],
                        'SliceCount': len(series_info['files']),
                        'Files': series_info['files']
                    })
                elif series_info['modality'] == 'CT':
                    self.ct_series_list.append({
                        'SeriesInstanceUID': series_uid,
                        'SeriesNumber': series_info['series_number'],
                        'SeriesDescription': series_info['series_description'],
                        'PatientID': series_info['patient_id'],
                        'PatientName': series_info['patient_name'],
                        'StudyInstanceUID': series_info['study_instance_uid'],
                        'StudyDescription': series_info['study_description'],
                        'SliceCount': len(series_info['files']),
                        'Files': series_info['files']
                    })
            
            # Sort series by series number
            self.pet_series_list.sort(key=lambda x: x['SeriesNumber'])
            self.ct_series_list.sort(key=lambda x: x['SeriesNumber'])
            
            # Extract patient information from first series
            if self.pet_series_list:
                _, ds = self.pet_series_list[0]['Files'][0]
                self._extract_patient_info(ds)
            elif self.ct_series_list:
                _, ds = self.ct_series_list[0]['Files'][0]
                self._extract_patient_info(ds)
            
            # Complete progress tracking
            self.progress_tracker.complete()
            
            # Return success
            return {
                'status': 'success',
                'message': f"Found {len(self.pet_series_list)} PET series and {len(self.ct_series_list)} CT series",
                'pet_series_count': len(self.pet_series_list),
                'ct_series_count': len(self.ct_series_list)
            }
        except Exception as e:
            self.progress_tracker.complete()
            logger.error(f"Error loading directory: {str(e)}")
            return {'status': 'error', 'message': f"Error loading directory: {str(e)}"}
    
    def _extract_patient_info(self, ds):
        """
        Extract patient information from a DICOM dataset.
        
        Args:
            ds (pydicom.dataset.Dataset): DICOM dataset
        """
        self.patient_info = {
            'PatientID': ds.PatientID if hasattr(ds, 'PatientID') else 'Unknown',
            'PatientName': str(ds.PatientName) if hasattr(ds, 'PatientName') else 'Unknown',
            'PatientBirthDate': ds.PatientBirthDate if hasattr(ds, 'PatientBirthDate') else '',
            'PatientSex': ds.PatientSex if hasattr(ds, 'PatientSex') else '',
            'StudyDate': ds.StudyDate if hasattr(ds, 'StudyDate') else '',
            'StudyTime': ds.StudyTime if hasattr(ds, 'StudyTime') else '',
            'StudyDescription': ds.StudyDescription if hasattr(ds, 'StudyDescription') else '',
            'StudyID': ds.StudyID if hasattr(ds, 'StudyID') else '',
            'AccessionNumber': ds.AccessionNumber if hasattr(ds, 'AccessionNumber') else ''
        }
    
    def get_pet_series_list(self):
        """
        Get the list of PET series.
        
        Returns:
            list: List of PET series
        """
        return self.pet_series_list
    
    def get_ct_series_list(self):
        """
        Get the list of CT series.
        
        Returns:
            list: List of CT series
        """
        return self.ct_series_list
    
    def select_pet_series(self, series_number):
        """
        Select a PET series by series number.
        
        Args:
            series_number (int): Series number
            
        Returns:
            bool: True if series was selected, False otherwise
        """
        # Find series with matching series number
        for series in self.pet_series_list:
            if series['SeriesNumber'] == series_number:
                self.selected_pet_series = series
                self._load_pet_series()
                return True
        
        logger.warning(f"PET series {series_number} not found")
        return False
    
    def select_ct_series(self, series_number):
        """
        Select a CT series by series number.
        
        Args:
            series_number (int): Series number
            
        Returns:
            bool: True if series was selected, False otherwise
        """
        # Find series with matching series number
        for series in self.ct_series_list:
            if series['SeriesNumber'] == series_number:
                self.selected_ct_series = series
                self._load_ct_series()
                return True
        
        logger.warning(f"CT series {series_number} not found")
        return False
    
    def select_pet_series_by_uid(self, series_uid):
        """
        Select a PET series by series UID.
        
        Args:
            series_uid (str): Series UID
            
        Returns:
            bool: True if series was selected, False otherwise
        """
        # Find series with matching UID
        for series in self.pet_series_list:
            if series['SeriesInstanceUID'] == series_uid:
                self.selected_pet_series = series
                self._load_pet_series()
                return True
        
        logger.warning(f"PET series {series_uid} not found")
        return False
    
    def select_ct_series_by_uid(self, series_uid):
        """
        Select a CT series by series UID.
        
        Args:
            series_uid (str): Series UID
            
        Returns:
            bool: True if series was selected, False otherwise
        """
        # Find series with matching UID
        for series in self.ct_series_list:
            if series['SeriesInstanceUID'] == series_uid:
                self.selected_ct_series = series
                self._load_ct_series()
                return True
        
        logger.warning(f"CT series {series_uid} not found")
        return False
    
    def _load_pet_series(self):
        """Load the selected PET series."""
        if not self.selected_pet_series:
            logger.warning("No PET series selected")
            return
        
        try:
            # Start progress tracking
            self.progress_tracker.start(len(self.selected_pet_series['Files']), "Loading PET series")
            
            # Sort files by instance number
            files = self.selected_pet_series['Files']
            files.sort(key=lambda x: self._get_instance_number(x[1]))
            
            # Read first file to get dimensions
            _, first_ds = files[0]
            rows = first_ds.Rows
            cols = first_ds.Columns
            slices = len(files)
            
            # Create 3D array
            self.pet_array = np.zeros((slices, rows, cols), dtype=np.float32)
            
            # Extract metadata
            self.pet_metadata = {
                'PixelSpacing': first_ds.PixelSpacing if hasattr(first_ds, 'PixelSpacing') else [1.0, 1.0],
                'SliceThickness': float(first_ds.SliceThickness) if hasattr(first_ds, 'SliceThickness') else 1.0,
                'RescaleSlope': float(first_ds.RescaleSlope) if hasattr(first_ds, 'RescaleSlope') else 1.0,
                'RescaleIntercept': float(first_ds.RescaleIntercept) if hasattr(first_ds, 'RescaleIntercept') else 0.0
            }
            
            # Extract SUV factors if available
            if hasattr(first_ds, 'RadiopharmaceuticalInformationSequence'):
                try:
                    rad_info = first_ds.RadiopharmaceuticalInformationSequence[0]
                    if hasattr(rad_info, 'RadionuclideTotalDose'):
                        self.pet_metadata['RadionuclideTotalDose'] = float(rad_info.RadionuclideTotalDose)
                    if hasattr(rad_info, 'RadiopharmaceuticalStartTime'):
                        self.pet_metadata['RadiopharmaceuticalStartTime'] = rad_info.RadiopharmaceuticalStartTime
                except Exception as e:
                    logger.warning(f"Error extracting radiopharmaceutical info: {str(e)}")
            
            if hasattr(first_ds, 'PatientWeight'):
                self.pet_metadata['PatientWeight'] = float(first_ds.PatientWeight)
            
            # Load pixel data for each slice
            for i, (file_path, ds) in enumerate(files):
                self.progress_tracker.update_item(f"Loading slice {i+1}/{slices}", 0)
                
                # Get pixel data
                pixel_array = ds.pixel_array.astype(np.float32)
                
                # Apply rescale slope and intercept
                rescale_slope = float(ds.RescaleSlope) if hasattr(ds, 'RescaleSlope') else 1.0
                rescale_intercept = float(ds.RescaleIntercept) if hasattr(ds, 'RescaleIntercept') else 0.0
                pixel_array = pixel_array * rescale_slope + rescale_intercept
                
                # Store in 3D array
                self.pet_array[i, :, :] = pixel_array
                
                # Update progress
                self.progress_tracker.update_item(f"Loading slice {i+1}/{slices}", 100)
                self.progress_tracker.increment_completed()
            
            # Complete progress tracking
            self.progress_tracker.complete()
            
            logger.info(f"Loaded PET series with {slices} slices")
        except Exception as e:
            self.progress_tracker.complete()
            logger.error(f"Error loading PET series: {str(e)}")
    
    def _load_ct_series(self):
        """Load the selected CT series."""
        if not self.selected_ct_series:
            logger.warning("No CT series selected")
            return
        
        try:
            # Start progress tracking
            self.progress_tracker.start(len(self.selected_ct_series['Files']), "Loading CT series")
            
            # Sort files by instance number
            files = self.selected_ct_series['Files']
            files.sort(key=lambda x: self._get_instance_number(x[1]))
            
            # Read first file to get dimensions
            _, first_ds = files[0]
            rows = first_ds.Rows
            cols = first_ds.Columns
            slices = len(files)
            
            # Create 3D array
            self.ct_array = np.zeros((slices, rows, cols), dtype=np.int16)
            
            # Extract metadata
            self.ct_metadata = {
                'PixelSpacing': first_ds.PixelSpacing if hasattr(first_ds, 'PixelSpacing') else [1.0, 1.0],
                'SliceThickness': float(first_ds.SliceThickness) if hasattr(first_ds, 'SliceThickness') else 1.0,
                'RescaleSlope': float(first_ds.RescaleSlope) if hasattr(first_ds, 'RescaleSlope') else 1.0,
                'RescaleIntercept': float(first_ds.RescaleIntercept) if hasattr(first_ds, 'RescaleIntercept') else 0.0
            }
            
            # Load pixel data for each slice
            for i, (file_path, ds) in enumerate(files):
                self.progress_tracker.update_item(f"Loading slice {i+1}/{slices}", 0)
                
                # Get pixel data
                pixel_array = ds.pixel_array.astype(np.int16)
                
                # Apply rescale slope and intercept
                rescale_slope = float(ds.RescaleSlope) if hasattr(ds, 'RescaleSlope') else 1.0
                rescale_intercept = float(ds.RescaleIntercept) if hasattr(ds, 'RescaleIntercept') else 0.0
                pixel_array = pixel_array * rescale_slope + rescale_intercept
                
                # Store in 3D array
                self.ct_array[i, :, :] = pixel_array
                
                # Update progress
                self.progress_tracker.update_item(f"Loading slice {i+1}/{slices}", 100)
                self.progress_tracker.increment_completed()
            
            # Complete progress tracking
            self.progress_tracker.complete()
            
            logger.info(f"Loaded CT series with {slices} slices")
        except Exception as e:
            self.progress_tracker.complete()
            logger.error(f"Error loading CT series: {str(e)}")
    
    def _get_instance_number(self, ds):
        """
        Get the instance number from a DICOM dataset.
        
        Args:
            ds (pydicom.dataset.Dataset): DICOM dataset
            
        Returns:
            int: Instance number
        """
        if hasattr(ds, 'InstanceNumber'):
            return int(ds.InstanceNumber)
        return 0
    
    def get_pet_array(self):
        """
        Get the PET array.
        
        Returns:
            numpy.ndarray: 3D array of PET data
        """
        return self.pet_array
    
    def get_ct_array(self):
        """
        Get the CT array.
        
        Returns:
            numpy.ndarray: 3D array of CT data
        """
        return self.ct_array
    
    def get_pet_metadata(self):
        """
        Get the PET metadata.
        
        Returns:
            dict: Dictionary of PET metadata
        """
        return self.pet_metadata
    
    def get_ct_metadata(self):
        """
        Get the CT metadata.
        
        Returns:
            dict: Dictionary of CT metadata
        """
        return self.ct_metadata
    
    def get_patient_info(self):
        """
        Get the patient information.
        
        Returns:
            dict: Dictionary of patient information
        """
        return self.patient_info
    
    def create_fusion_array(self):
        """
        Create a fusion array from PET and CT data.
        
        Returns:
            numpy.ndarray: 3D array of fusion data, or None if not possible
        """
        if self.pet_array is None or self.ct_array is None:
            logger.warning("Cannot create fusion: PET or CT data missing")
            return None
        
        try:
            # Start progress tracking
            self.progress_tracker.start(1, "Creating fusion")
            self.progress_tracker.update_item("Aligning PET and CT data", 0)
            
            # Check if dimensions match
            pet_shape = self.pet_array.shape
            ct_shape = self.ct_array.shape
            
            if pet_shape != ct_shape:
                logger.warning(f"PET shape {pet_shape} does not match CT shape {ct_shape}")
                logger.info("Resampling CT to match PET dimensions")
                
                # For simplicity, we'll just resize CT to match PET
                # In a real application, proper resampling would be needed
                from scipy.ndimage import zoom
                
                # Calculate zoom factors
                zoom_factors = [pet_dim / ct_dim for pet_dim, ct_dim in zip(pet_shape, ct_shape)]
                
                # Resize CT array
                self.progress_tracker.update_item("Resampling CT data", 50)
                resampled_ct = zoom(self.ct_array, zoom_factors, order=1)
                
                # Create fusion array
                self.progress_tracker.update_item("Creating fusion data", 75)
                
                # Normalize CT to 0-1 range
                ct_min = -1000  # Typical min HU value
                ct_max = 1000   # Typical max HU value
                ct_normalized = (np.clip(resampled_ct, ct_min, ct_max) - ct_min) / (ct_max - ct_min)
                
                # Normalize PET to 0-1 range
                pet_max = np.max(self.pet_array)
                if pet_max > 0:
                    pet_normalized = self.pet_array / pet_max
                else:
                    pet_normalized = self.pet_array
                
                # Create RGB fusion (R: PET, G: mixed, B: CT)
                fusion = np.zeros(pet_shape + (3,), dtype=np.float32)
                fusion[..., 0] = pet_normalized  # Red channel (PET)
                fusion[..., 1] = 0.5 * pet_normalized + 0.5 * ct_normalized  # Green channel (mixed)
                fusion[..., 2] = ct_normalized  # Blue channel (CT)
                
                # Scale to 0-255 for display
                fusion = (fusion * 255).astype(np.uint8)
            else:
                # Create fusion array directly
                self.progress_tracker.update_item("Creating fusion data", 50)
                
                # Normalize CT to 0-1 range
                ct_min = -1000  # Typical min HU value
                ct_max = 1000   # Typical max HU value
                ct_normalized = (np.clip(self.ct_array, ct_min, ct_max) - ct_min) / (ct_max - ct_min)
                
                # Normalize PET to 0-1 range
                pet_max = np.max(self.pet_array)
                if pet_max > 0:
                    pet_normalized = self.pet_array / pet_max
                else:
                    pet_normalized = self.pet_array
                
                # Create RGB fusion (R: PET, G: mixed, B: CT)
                fusion = np.zeros(pet_shape + (3,), dtype=np.float32)
                fusion[..., 0] = pet_normalized  # Red channel (PET)
                fusion[..., 1] = 0.5 * pet_normalized + 0.5 * ct_normalized  # Green channel (mixed)
                fusion[..., 2] = ct_normalized  # Blue channel (CT)
                
                # Scale to 0-255 for display
                fusion = (fusion * 255).astype(np.uint8)
            
            # Complete progress tracking
            self.progress_tracker.update_item("Fusion complete", 100)
            self.progress_tracker.increment_completed()
            self.progress_tracker.complete()
            
            return fusion
        except Exception as e:
            self.progress_tracker.complete()
            logger.error(f"Error creating fusion: {str(e)}")
            return None
    
    def load_dicom_file(self, file_path):
        """
        Load a single DICOM file.
        
        Args:
            file_path (str): Path to DICOM file
            
        Returns:
            dict: Dictionary with loading results
        """
        if not os.path.exists(file_path):
            logger.error(f"File does not exist: {file_path}")
            return {'status': 'error', 'message': f"File does not exist: {file_path}"}
        
        try:
            # Start progress tracking
            self.progress_tracker.start(1, f"Loading {os.path.basename(file_path)}")
            
            # Read DICOM file
            ds = pydicom.dcmread(file_path, force=True)
            
            # Check if it's a valid DICOM file with required attributes
            if not hasattr(ds, 'SOPClassUID'):
                self.progress_tracker.complete()
                return {'status': 'error', 'message': "Not a valid DICOM file"}
            
            # Get modality
            modality = ds.Modality if hasattr(ds, 'Modality') else 'Unknown'
            
            # Extract basic information
            info = {
                'Modality': modality,
                'SeriesNumber': int(ds.SeriesNumber) if hasattr(ds, 'SeriesNumber') else 0,
                'SeriesDescription': ds.SeriesDescription if hasattr(ds, 'SeriesDescription') else 'Unknown',
                'PatientID': ds.PatientID if hasattr(ds, 'PatientID') else 'Unknown',
                'PatientName': str(ds.PatientName) if hasattr(ds, 'PatientName') else 'Unknown',
                'StudyInstanceUID': ds.StudyInstanceUID if hasattr(ds, 'StudyInstanceUID') else '',
                'StudyDescription': ds.StudyDescription if hasattr(ds, 'StudyDescription') else 'Unknown'
            }
            
            # Complete progress tracking
            self.progress_tracker.update_item(f"Loaded {os.path.basename(file_path)}", 100)
            self.progress_tracker.increment_completed()
            self.progress_tracker.complete()
            
            return {
                'status': 'success',
                'message': f"Loaded {modality} file",
                'info': info,
                'dataset': ds
            }
        except Exception as e:
            self.progress_tracker.complete()
            logger.error(f"Error loading file: {str(e)}")
            return {'status': 'error', 'message': f"Error loading file: {str(e)}"}


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    loader = DicomLoader()
    
    # Check if a directory path was provided
    if len(sys.argv) > 1:
        directory_path = sys.argv[1]
        result = loader.load_directory(directory_path)
        print(f"Loading result: {result}")
        
        # Print series information
        pet_series = loader.get_pet_series_list()
        ct_series = loader.get_ct_series_list()
        
        print(f"\nFound {len(pet_series)} PET series:")
        for i, series in enumerate(pet_series):
            print(f"  {i+1}. {series['SeriesDescription']} ({series['SliceCount']} slices)")
        
        print(f"\nFound {len(ct_series)} CT series:")
        for i, series in enumerate(ct_series):
            print(f"  {i+1}. {series['SeriesDescription']} ({series['SliceCount']} slices)")
        
        # Load first series if available
        if pet_series:
            loader.select_pet_series(pet_series[0]['SeriesNumber'])
            print("\nLoaded PET series")
        
        if ct_series:
            loader.select_ct_series(ct_series[0]['SeriesNumber'])
            print("Loaded CT series")
        
        # Create fusion if both PET and CT are loaded
        if loader.get_pet_array() is not None and loader.get_ct_array() is not None:
            fusion = loader.create_fusion_array()
            if fusion is not None:
                print(f"Created fusion array with shape {fusion.shape}")
    else:
        print("Usage: python enhanced_dicom_loader.py <dicom_directory>")
