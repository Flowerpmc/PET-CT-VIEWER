#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Error Handling and Validation Module for PET/CT Viewer
---------------------------------------------------
This module provides error handling, validation, and testing utilities.
"""

import os
import sys
import logging
import traceback
import numpy as np
import pydicom
from pydicom.errors import InvalidDicomError

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('DicomValidator')

class DicomValidator:
    """
    Class for validating DICOM files and datasets.
    """
    
    def __init__(self):
        """Initialize the DicomValidator."""
        pass
    
    def validate_directory(self, directory_path):
        """
        Validate DICOM files in a directory.
        
        Args:
            directory_path (str): Path to directory containing DICOM files
            
        Returns:
            dict: Dictionary with validation results
        """
        if not os.path.exists(directory_path):
            logger.error(f"Directory does not exist: {directory_path}")
            return {'status': 'error', 'message': f"Directory does not exist: {directory_path}"}
        
        # Find all potential DICOM files
        dicom_files = []
        for root, _, files in os.walk(directory_path):
            for file in files:
                if file.lower().endswith(('.dcm', '.ima')) or '.' not in file:
                    dicom_files.append(os.path.join(root, file))
        
        if not dicom_files:
            logger.warning(f"No DICOM files found in: {directory_path}")
            return {'status': 'error', 'message': f"No DICOM files found in: {directory_path}"}
        
        # Validate each file
        valid_files = []
        invalid_files = []
        pet_files = []
        ct_files = []
        other_files = []
        
        for file_path in dicom_files:
            result = self.validate_file(file_path)
            if result['status'] == 'valid':
                valid_files.append(file_path)
                if result['modality'] == 'PT':
                    pet_files.append(file_path)
                elif result['modality'] == 'CT':
                    ct_files.append(file_path)
                else:
                    other_files.append(file_path)
            else:
                invalid_files.append((file_path, result['message']))
        
        # Check if we have both PET and CT files
        has_pet_ct = len(pet_files) > 0 and len(ct_files) > 0
        
        return {
            'status': 'success',
            'total_files': len(dicom_files),
            'valid_files': len(valid_files),
            'invalid_files': len(invalid_files),
            'pet_files': len(pet_files),
            'ct_files': len(ct_files),
            'other_files': len(other_files),
            'has_pet_ct': has_pet_ct,
            'invalid_details': invalid_files
        }
    
    def validate_file(self, file_path):
        """
        Validate a single DICOM file.
        
        Args:
            file_path (str): Path to DICOM file
            
        Returns:
            dict: Dictionary with validation results
        """
        try:
            # Try to read the DICOM file
            ds = pydicom.dcmread(file_path, force=True)
            
            # Check if it's a valid DICOM file with required attributes
            if not hasattr(ds, 'SOPClassUID'):
                return {'status': 'invalid', 'message': 'Missing SOPClassUID'}
            
            # Get modality
            modality = ds.Modality if hasattr(ds, 'Modality') else 'Unknown'
            
            # Check for pixel data
            has_pixel_data = hasattr(ds, 'PixelData')
            
            # Get additional metadata
            metadata = {
                'PatientName': str(ds.PatientName) if hasattr(ds, 'PatientName') else 'Unknown',
                'PatientID': ds.PatientID if hasattr(ds, 'PatientID') else 'Unknown',
                'StudyDescription': ds.StudyDescription if hasattr(ds, 'StudyDescription') else 'Unknown',
                'SeriesDescription': ds.SeriesDescription if hasattr(ds, 'SeriesDescription') else 'Unknown',
                'Rows': ds.Rows if hasattr(ds, 'Rows') else 0,
                'Columns': ds.Columns if hasattr(ds, 'Columns') else 0
            }
            
            return {
                'status': 'valid',
                'modality': modality,
                'has_pixel_data': has_pixel_data,
                'metadata': metadata
            }
        except InvalidDicomError:
            return {'status': 'invalid', 'message': 'Not a valid DICOM file'}
        except Exception as e:
            return {'status': 'invalid', 'message': str(e)}
    
    def validate_pet_ct_compatibility(self, pet_file, ct_file):
        """
        Validate compatibility between PET and CT files.
        
        Args:
            pet_file (str): Path to PET DICOM file
            ct_file (str): Path to CT DICOM file
            
        Returns:
            dict: Dictionary with validation results
        """
        try:
            # Read the DICOM files
            pet_ds = pydicom.dcmread(pet_file, force=True)
            ct_ds = pydicom.dcmread(ct_file, force=True)
            
            # Check modalities
            if not hasattr(pet_ds, 'Modality') or pet_ds.Modality != 'PT':
                return {'status': 'invalid', 'message': 'First file is not a PET image'}
            
            if not hasattr(ct_ds, 'Modality') or ct_ds.Modality != 'CT':
                return {'status': 'invalid', 'message': 'Second file is not a CT image'}
            
            # Check patient information
            same_patient = False
            if hasattr(pet_ds, 'PatientID') and hasattr(ct_ds, 'PatientID'):
                same_patient = pet_ds.PatientID == ct_ds.PatientID
            
            # Check study information
            same_study = False
            if hasattr(pet_ds, 'StudyInstanceUID') and hasattr(ct_ds, 'StudyInstanceUID'):
                same_study = pet_ds.StudyInstanceUID == ct_ds.StudyInstanceUID
            
            # Check image dimensions
            same_dimensions = False
            if (hasattr(pet_ds, 'Rows') and hasattr(pet_ds, 'Columns') and
                hasattr(ct_ds, 'Rows') and hasattr(ct_ds, 'Columns')):
                same_dimensions = (pet_ds.Rows == ct_ds.Rows and pet_ds.Columns == ct_ds.Columns)
            
            return {
                'status': 'valid',
                'same_patient': same_patient,
                'same_study': same_study,
                'same_dimensions': same_dimensions
            }
        except Exception as e:
            return {'status': 'invalid', 'message': str(e)}


class ErrorHandler:
    """
    Class for handling and logging errors.
    """
    
    def __init__(self, log_file=None):
        """
        Initialize the ErrorHandler.
        
        Args:
            log_file (str, optional): Path to log file
        """
        self.log_file = log_file
        
        # Configure file logging if log_file is provided
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
            logger.addHandler(file_handler)
    
    def handle_exception(self, exception, context=None):
        """
        Handle an exception.
        
        Args:
            exception (Exception): The exception to handle
            context (str, optional): Context information
            
        Returns:
            dict: Dictionary with error information
        """
        # Get exception details
        exc_type = type(exception).__name__
        exc_message = str(exception)
        exc_traceback = traceback.format_exc()
        
        # Log the exception
        if context:
            logger.error(f"Exception in {context}: {exc_type}: {exc_message}")
        else:
            logger.error(f"Exception: {exc_type}: {exc_message}")
        
        logger.debug(exc_traceback)
        
        # Return error information
        return {
            'type': exc_type,
            'message': exc_message,
            'traceback': exc_traceback,
            'context': context
        }
    
    def log_error(self, message, context=None):
        """
        Log an error message.
        
        Args:
            message (str): Error message
            context (str, optional): Context information
        """
        if context:
            logger.error(f"Error in {context}: {message}")
        else:
            logger.error(f"Error: {message}")
    
    def log_warning(self, message, context=None):
        """
        Log a warning message.
        
        Args:
            message (str): Warning message
            context (str, optional): Context information
        """
        if context:
            logger.warning(f"Warning in {context}: {message}")
        else:
            logger.warning(f"Warning: {message}")


class PerformanceOptimizer:
    """
    Class for optimizing performance of the application.
    """
    
    def __init__(self):
        """Initialize the PerformanceOptimizer."""
        pass
    
    def optimize_memory_usage(self, array):
        """
        Optimize memory usage for a numpy array.
        
        Args:
            array (numpy.ndarray): Array to optimize
            
        Returns:
            numpy.ndarray: Optimized array
        """
        # Check if array can be downcast to a lower precision
        if array.dtype == np.float64:
            # Downcast to float32 to save memory
            return array.astype(np.float32)
        elif array.dtype == np.int64:
            # Downcast to int32 or int16 if possible
            if np.max(array) <= 32767 and np.min(array) >= -32768:
                return array.astype(np.int16)
            else:
                return array.astype(np.int32)
        
        # Return original array if no optimization is possible
        return array
    
    def optimize_rendering_settings(self, renderer):
        """
        Optimize rendering settings for a VTK renderer.
        
        Args:
            renderer: VTK renderer object
            
        Returns:
            bool: True if optimization was applied, False otherwise
        """
        try:
            # Set rendering quality based on scene complexity
            actors = renderer.GetActors()
            actor_count = actors.GetNumberOfItems()
            
            if actor_count > 10:
                # Lower quality for complex scenes
                renderer.SetUseDepthPeeling(0)
                renderer.SetMaximumNumberOfPeels(1)
                renderer.SetOcclusionRatio(0.0)
                return True
            else:
                # Higher quality for simple scenes
                renderer.SetUseDepthPeeling(1)
                renderer.SetMaximumNumberOfPeels(4)
                renderer.SetOcclusionRatio(0.1)
                return True
        except Exception as e:
            logger.warning(f"Error optimizing renderer: {str(e)}")
            return False


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    validator = DicomValidator()
    
    # Check if a directory path was provided
    if len(sys.argv) > 1:
        directory_path = sys.argv[1]
        result = validator.validate_directory(directory_path)
        
        print(f"Validation result: {result['status']}")
        print(f"Total files: {result['total_files']}")
        print(f"Valid files: {result['valid_files']}")
        print(f"Invalid files: {result['invalid_files']}")
        print(f"PET files: {result['pet_files']}")
        print(f"CT files: {result['ct_files']}")
        print(f"Other files: {result['other_files']}")
        print(f"Has PET/CT pair: {result['has_pet_ct']}")
        
        if result['invalid_files'] > 0:
            print("\nInvalid files:")
            for file_path, message in result['invalid_details']:
                print(f"  {file_path}: {message}")
    else:
        print("Usage: python dicom_validator.py <dicom_directory>")
