#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Visualization Module for PET/CT Viewer
-------------------------------------
This module handles the visualization of PET, CT, and fused images using VTK.
It provides classes for different view types and rendering methods.
"""

import os
import sys
import logging
import numpy as np
import vtk
from vtk.util import numpy_support

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('DicomVisualizer')

class DicomVisualizer:
    """
    Class for visualizing DICOM data using VTK.
    Handles different view types (axial, coronal, sagittal) and rendering methods.
    """
    
    # Constants for orientation
    AXIAL = 0
    CORONAL = 1
    SAGITTAL = 2
    
    # Constants for modality
    PET = 0
    CT = 1
    FUSION = 2
    
    def __init__(self):
        """Initialize the DicomVisualizer with empty data."""
        self.pet_volume = None
        self.ct_volume = None
        self.fusion_volume = None
        self.pet_mapper = None
        self.ct_mapper = None
        self.fusion_mapper = None
        self.pet_color_function = None
        self.ct_color_function = None
        self.fusion_color_function = None
        self.pet_opacity_function = None
        self.ct_opacity_function = None
        self.fusion_opacity_function = None
        
        # Default window/level values
        self.ct_window = 400
        self.ct_level = 40
        self.pet_window = 6
        self.pet_level = 3
        
        # Default color maps
        self.pet_colormap = "Hot Metal"  # Options: Hot Metal, Rainbow, Jet, etc.
        self.ct_colormap = "Grayscale"   # Options: Grayscale, Bone, etc.
        
    def set_pet_data(self, array, spacing=(1.0, 1.0, 1.0)):
        """
        Set PET data for visualization.
        
        Args:
            array (numpy.ndarray): 3D array of PET data
            spacing (tuple): Voxel spacing in mm (x, y, z)
        """
        if array is None:
            logger.warning("Cannot set PET data: array is None")
            return False
        
        try:
            # Create VTK image data from numpy array
            self.pet_volume = self._create_vtk_image_data(array, spacing)
            
            # Create color and opacity transfer functions for PET
            self.pet_color_function = self._create_pet_color_function()
            self.pet_opacity_function = self._create_pet_opacity_function()
            
            return True
        except Exception as e:
            logger.error(f"Error setting PET data: {str(e)}")
            return False
    
    def set_ct_data(self, array, spacing=(1.0, 1.0, 1.0)):
        """
        Set CT data for visualization.
        
        Args:
            array (numpy.ndarray): 3D array of CT data
            spacing (tuple): Voxel spacing in mm (x, y, z)
        """
        if array is None:
            logger.warning("Cannot set CT data: array is None")
            return False
        
        try:
            # Create VTK image data from numpy array
            self.ct_volume = self._create_vtk_image_data(array, spacing)
            
            # Create color and opacity transfer functions for CT
            self.ct_color_function = self._create_ct_color_function()
            self.ct_opacity_function = self._create_ct_opacity_function()
            
            return True
        except Exception as e:
            logger.error(f"Error setting CT data: {str(e)}")
            return False
    
    def set_fusion_data(self, array, spacing=(1.0, 1.0, 1.0)):
        """
        Set fusion data for visualization.
        
        Args:
            array (numpy.ndarray): 3D array of fused PET/CT data
            spacing (tuple): Voxel spacing in mm (x, y, z)
        """
        if array is None:
            logger.warning("Cannot set fusion data: array is None")
            return False
        
        try:
            # Create VTK image data from numpy array
            self.fusion_volume = self._create_vtk_image_data(array, spacing)
            
            # Create color and opacity transfer functions for fusion
            self.fusion_color_function = self._create_fusion_color_function()
            self.fusion_opacity_function = self._create_fusion_opacity_function()
            
            return True
        except Exception as e:
            logger.error(f"Error setting fusion data: {str(e)}")
            return False
    
    def _create_vtk_image_data(self, array, spacing):
        """
        Create VTK image data from numpy array.
        
        Args:
            array (numpy.ndarray): 3D array of image data
            spacing (tuple): Voxel spacing in mm (x, y, z)
            
        Returns:
            vtkImageData: VTK image data object
        """
        # Ensure array is float32 for VTK
        if array.dtype != np.float32:
            array = array.astype(np.float32)
        
        # Get dimensions
        dims = array.shape
        
        # Create VTK image data
        vtk_image = vtk.vtkImageData()
        vtk_image.SetDimensions(dims[0], dims[1], dims[2])
        vtk_image.SetSpacing(spacing[0], spacing[1], spacing[2])
        vtk_image.SetOrigin(0, 0, 0)
        
        # Set point data
        flat_array = array.flatten('F')  # Flatten array in Fortran order (column-major)
        vtk_array = numpy_support.numpy_to_vtk(flat_array)
        vtk_image.GetPointData().SetScalars(vtk_array)
        
        return vtk_image
    
    def _create_pet_color_function(self):
        """Create color transfer function for PET data."""
        color_function = vtk.vtkColorTransferFunction()
        
        if self.pet_colormap == "Hot Metal":
            # Hot Metal colormap (black -> red -> yellow -> white)
            color_function.AddRGBPoint(0.0, 0.0, 0.0, 0.0)      # Black
            color_function.AddRGBPoint(1.0, 0.5, 0.0, 0.0)      # Dark red
            color_function.AddRGBPoint(2.0, 0.9, 0.0, 0.0)      # Red
            color_function.AddRGBPoint(3.0, 0.9, 0.6, 0.0)      # Orange
            color_function.AddRGBPoint(4.0, 1.0, 0.9, 0.0)      # Yellow
            color_function.AddRGBPoint(5.0, 1.0, 1.0, 0.7)      # Light yellow
            color_function.AddRGBPoint(6.0, 1.0, 1.0, 1.0)      # White
        elif self.pet_colormap == "Rainbow":
            # Rainbow colormap (blue -> cyan -> green -> yellow -> red)
            color_function.AddRGBPoint(0.0, 0.0, 0.0, 0.0)      # Black
            color_function.AddRGBPoint(1.0, 0.0, 0.0, 1.0)      # Blue
            color_function.AddRGBPoint(2.0, 0.0, 1.0, 1.0)      # Cyan
            color_function.AddRGBPoint(3.0, 0.0, 1.0, 0.0)      # Green
            color_function.AddRGBPoint(4.0, 1.0, 1.0, 0.0)      # Yellow
            color_function.AddRGBPoint(5.0, 1.0, 0.0, 0.0)      # Red
            color_function.AddRGBPoint(6.0, 1.0, 1.0, 1.0)      # White
        else:
            # Default grayscale
            color_function.AddRGBPoint(0.0, 0.0, 0.0, 0.0)      # Black
            color_function.AddRGBPoint(6.0, 1.0, 1.0, 1.0)      # White
        
        return color_function
    
    def _create_ct_color_function(self):
        """Create color transfer function for CT data."""
        color_function = vtk.vtkColorTransferFunction()
        
        if self.ct_colormap == "Grayscale":
            # Standard CT window/level
            lower_bound = self.ct_level - self.ct_window/2
            upper_bound = self.ct_level + self.ct_window/2
            
            color_function.AddRGBPoint(lower_bound, 0.0, 0.0, 0.0)  # Black
            color_function.AddRGBPoint(upper_bound, 1.0, 1.0, 1.0)  # White
        elif self.ct_colormap == "Bone":
            # Bone window preset
            color_function.AddRGBPoint(-1000, 0.0, 0.0, 0.0)        # Air
            color_function.AddRGBPoint(-100, 0.2, 0.2, 0.2)         # Fat
            color_function.AddRGBPoint(300, 0.8, 0.8, 0.7)          # Soft tissue
            color_function.AddRGBPoint(1000, 1.0, 1.0, 0.9)         # Bone
            color_function.AddRGBPoint(3000, 1.0, 1.0, 1.0)         # Dense bone/metal
        else:
            # Default grayscale
            color_function.AddRGBPoint(-1000, 0.0, 0.0, 0.0)        # Air
            color_function.AddRGBPoint(3000, 1.0, 1.0, 1.0)         # Dense bone/metal
        
        return color_function
    
    def _create_fusion_color_function(self):
        """Create color transfer function for fusion data."""
        color_function = vtk.vtkColorTransferFunction()
        
        # For fusion, we use a specialized colormap that shows CT in grayscale
        # and PET in color overlay
        color_function.AddRGBPoint(0.0, 0.0, 0.0, 0.0)      # Black
        color_function.AddRGBPoint(0.2, 0.2, 0.2, 0.2)      # Dark gray (CT)
        color_function.AddRGBPoint(0.4, 0.4, 0.4, 0.4)      # Gray (CT)
        color_function.AddRGBPoint(0.5, 0.7, 0.7, 0.7)      # Light gray (CT)
        color_function.AddRGBPoint(0.6, 0.9, 0.0, 0.0)      # Red (PET)
        color_function.AddRGBPoint(0.8, 1.0, 0.8, 0.0)      # Yellow (PET)
        color_function.AddRGBPoint(1.0, 1.0, 1.0, 1.0)      # White (PET)
        
        return color_function
    
    def _create_pet_opacity_function(self):
        """Create opacity transfer function for PET data."""
        opacity_function = vtk.vtkPiecewiseFunction()
        
        # PET opacity function - threshold to show only high uptake regions
        opacity_function.AddPoint(0.0, 0.0)   # Transparent
        opacity_function.AddPoint(0.5, 0.0)   # Transparent
        opacity_function.AddPoint(1.0, 0.2)   # Slightly visible
        opacity_function.AddPoint(2.0, 0.4)   # More visible
        opacity_function.AddPoint(3.0, 0.6)   # Visible
        opacity_function.AddPoint(4.0, 0.8)   # Mostly opaque
        opacity_function.AddPoint(6.0, 1.0)   # Opaque
        
        return opacity_function
    
    def _create_ct_opacity_function(self):
        """Create opacity transfer function for CT data."""
        opacity_function = vtk.vtkPiecewiseFunction()
        
        # CT opacity function - show all tissue
        lower_bound = self.ct_level - self.ct_window/2
        upper_bound = self.ct_level + self.ct_window/2
        
        opacity_function.AddPoint(lower_bound, 0.0)  # Transparent
        opacity_function.AddPoint(upper_bound, 1.0)  # Opaque
        
        return opacity_function
    
    def _create_fusion_opacity_function(self):
        """Create opacity transfer function for fusion data."""
        opacity_function = vtk.vtkPiecewiseFunction()
        
        # Fusion opacity function - show CT and high PET uptake
        opacity_function.AddPoint(0.0, 0.0)   # Transparent
        opacity_function.AddPoint(0.2, 0.6)   # CT partially visible
        opacity_function.AddPoint(0.4, 0.8)   # CT mostly visible
        opacity_function.AddPoint(0.6, 0.9)   # PET starts to appear
        opacity_function.AddPoint(0.8, 1.0)   # PET fully visible
        opacity_function.AddPoint(1.0, 1.0)   # Opaque
        
        return opacity_function
    
    def create_slice_actor(self, modality, orientation, slice_index=None):
        """
        Create a VTK actor for displaying a 2D slice.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            orientation (int): Slice orientation (AXIAL, CORONAL, or SAGITTAL)
            slice_index (int, optional): Slice index. If None, uses middle slice
            
        Returns:
            vtkActor: VTK actor for the slice, or None if creation fails
        """
        # Select volume based on modality
        if modality == self.PET:
            volume = self.pet_volume
            color_function = self.pet_color_function
        elif modality == self.CT:
            volume = self.ct_volume
            color_function = self.ct_color_function
        elif modality == self.FUSION:
            volume = self.fusion_volume
            color_function = self.fusion_color_function
        else:
            logger.error(f"Invalid modality: {modality}")
            return None
        
        if volume is None:
            logger.warning(f"No volume data available for modality {modality}")
            return None
        
        try:
            # Get volume dimensions
            dims = volume.GetDimensions()
            
            # Determine slice index if not provided
            if slice_index is None:
                if orientation == self.AXIAL:
                    slice_index = dims[2] // 2
                elif orientation == self.CORONAL:
                    slice_index = dims[1] // 2
                elif orientation == self.SAGITTAL:
                    slice_index = dims[0] // 2
            
            # Create slice
            reslice = vtk.vtkImageReslice()
            reslice.SetInputData(volume)
            reslice.SetInterpolationModeToLinear()
            
            # Set slice orientation
            if orientation == self.AXIAL:
                reslice.SetResliceAxesDirectionCosines(
                    1, 0, 0,
                    0, 1, 0,
                    0, 0, 1
                )
                reslice.SetResliceAxesOrigin(0, 0, slice_index)
            elif orientation == self.CORONAL:
                reslice.SetResliceAxesDirectionCosines(
                    1, 0, 0,
                    0, 0, 1,
                    0, 1, 0
                )
                reslice.SetResliceAxesOrigin(0, slice_index, 0)
            elif orientation == self.SAGITTAL:
                reslice.SetResliceAxesDirectionCosines(
                    0, 1, 0,
                    0, 0, 1,
                    1, 0, 0
                )
                reslice.SetResliceAxesOrigin(slice_index, 0, 0)
            
            reslice.Update()
            
            # Create color mapping
            color_map = vtk.vtkImageMapToColors()
            color_map.SetInputConnection(reslice.GetOutputPort())
            color_map.SetLookupTable(color_function)
            color_map.Update()
            
            # Create actor
            actor = vtk.vtkImageActor()
            actor.GetMapper().SetInputConnection(color_map.GetOutputPort())
            
            return actor
        except Exception as e:
            logger.error(f"Error creating slice actor: {str(e)}")
            return None
    
    def create_mip_actor(self, modality=PET):
        """
        Create a VTK actor for displaying a Maximum Intensity Projection (MIP).
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            
        Returns:
            vtkActor: VTK actor for the MIP, or None if creation fails
        """
        # Select volume based on modality
        if modality == self.PET:
            volume = self.pet_volume
            color_function = self.pet_color_function
            opacity_function = self.pet_opacity_function
        elif modality == self.CT:
            volume = self.ct_volume
            color_function = self.ct_color_function
            opacity_function = self.ct_opacity_function
        elif modality == self.FUSION:
            volume = self.fusion_volume
            color_function = self.fusion_color_function
            opacity_function = self.fusion_opacity_function
        else:
            logger.error(f"Invalid modality: {modality}")
            return None
        
        if volume is None:
            logger.warning(f"No volume data available for modality {modality}")
            return None
        
        try:
            # Create volume mapper for MIP
            volume_mapper = vtk.vtkGPUVolumeRayCastMapper()
            volume_mapper.SetInputData(volume)
            volume_mapper.SetBlendModeToMaximumIntensity()
            
            # Create volume property
            volume_property = vtk.vtkVolumeProperty()
            volume_property.SetColor(color_function)
            volume_property.SetScalarOpacity(opacity_function)
            volume_property.SetInterpolationTypeToLinear()
            volume_property.ShadeOff()
            
            # Create volume actor
            volume_actor = vtk.vtkVolume()
            volume_actor.SetMapper(volume_mapper)
            volume_actor.SetProperty(volume_property)
            
            return volume_actor
        except Exception as e:
            logger.error(f"Error creating MIP actor: {str(e)}")
            return None
    
    def set_window_level(self, modality, window, level):
        """
        Set window/level values for the specified modality.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            window (float): Window width
            level (float): Window level (center)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if modality == self.PET:
                self.pet_window = window
                self.pet_level = level
                self.pet_color_function = self._create_pet_color_function()
            elif modality == self.CT:
                self.ct_window = window
                self.ct_level = level
                self.ct_color_function = self._create_ct_color_function()
            elif modality == self.FUSION:
                # For fusion, we don't directly set window/level
                logger.warning("Window/level not directly applicable to fusion images")
                return False
            else:
                logger.error(f"Invalid modality: {modality}")
                return False
            
            return True
        except Exception as e:
            logger.error(f"Error setting window/level: {str(e)}")
            return False
    
    def set_colormap(self, modality, colormap):
        """
        Set colormap for the specified modality.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            colormap (str): Name of colormap
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if modality == self.PET:
                self.pet_colormap = colormap
                self.pet_color_function = self._create_pet_color_function()
            elif modality == self.CT:
                self.ct_colormap = colormap
                self.ct_color_function = self._create_ct_color_function()
            elif modality == self.FUSION:
                # For fusion, we don't directly set colormap
                logger.warning("Custom colormap not applicable to fusion images")
                return False
            else:
                logger.error(f"Invalid modality: {modality}")
                return False
            
            return True
        except Exception as e:
            logger.error(f"Error setting colormap: {str(e)}")
            return False
    
    def get_slice_count(self, modality, orientation):
        """
        Get the number of slices available for the specified modality and orientation.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            orientation (int): Slice orientation (AXIAL, CORONAL, or SAGITTAL)
            
        Returns:
            int: Number of slices, or 0 if data is not available
        """
        # Select volume based on modality
        if modality == self.PET:
            volume = self.pet_volume
        elif modality == self.CT:
            volume = self.ct_volume
        elif modality == self.FUSION:
            volume = self.fusion_volume
        else:
            logger.error(f"Invalid modality: {modality}")
            return 0
        
        if volume is None:
            return 0
        
        # Get dimensions based on orientation
        dims = volume.GetDimensions()
        if orientation == self.AXIAL:
            return dims[2]
        elif orientation == self.CORONAL:
            return dims[1]
        elif orientation == self.SAGITTAL:
            return dims[0]
        else:
            logger.error(f"Invalid orientation: {orientation}")
            return 0


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    import dicom_loader
    
    # Check if a directory path was provided
    if len(sys.argv) > 1:
        directory_path = sys.argv[1]
        
        # Load DICOM data
        loader = dicom_loader.DicomLoader()
        result = loader.load_directory(directory_path)
        
        if result['status'] == 'success':
            # Create visualizer
            visualizer = DicomVisualizer()
            
            # Set data
            if result['pet']:
                pet_array = loader.get_pet_array()
                pet_spacing = (1.0, 1.0, 1.0)  # Default spacing
                visualizer.set_pet_data(pet_array, pet_spacing)
                
                # Print some information
                print(f"PET data loaded with shape {pet_array.shape}")
                print(f"PET slice count: Axial={visualizer.get_slice_count(DicomVisualizer.PET, DicomVisualizer.AXIAL)}, "
                      f"Coronal={visualizer.get_slice_count(DicomVisualizer.PET, DicomVisualizer.CORONAL)}, "
                      f"Sagittal={visualizer.get_slice_count(DicomVisualizer.PET, DicomVisualizer.SAGITTAL)}")
            
            if result['ct']:
                ct_array = loader.get_ct_array()
                ct_spacing = (1.0, 1.0, 1.0)  # Default spacing
                visualizer.set_ct_data(ct_array, ct_spacing)
                
                # Print some information
                print(f"CT data loaded with shape {ct_array.shape}")
                print(f"CT slice count: Axial={visualizer.get_slice_count(DicomVisualizer.CT, DicomVisualizer.AXIAL)}, "
                      f"Coronal={visualizer.get_slice_count(DicomVisualizer.CT, DicomVisualizer.CORONAL)}, "
                      f"Sagittal={visualizer.get_slice_count(DicomVisualizer.CT, DicomVisualizer.SAGITTAL)}")
            
            if result['pet'] and result['ct']:
                fusion_array = loader.create_fusion_array()
                if fusion_array is not None:
                    fusion_spacing = (1.0, 1.0, 1.0)  # Default spacing
                    visualizer.set_fusion_data(fusion_array, fusion_spacing)
                    
                    # Print some information
                    print(f"Fusion data created with shape {fusion_array.shape}")
    else:
        print("Usage: python dicom_visualizer.py <dicom_directory>")
