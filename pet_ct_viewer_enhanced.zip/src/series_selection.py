#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Series Selection Module for PET/CT Viewer
---------------------------------------
This module provides enhanced series selection and loading functionality.
"""

import os
import sys
import logging
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('SeriesSelection')

class SeriesItem(QtWidgets.QListWidgetItem):
    """
    List widget item representing a DICOM series.
    """
    
    def __init__(self, series_info, parent=None):
        """
        Initialize the SeriesItem.
        
        Args:
            series_info (dict): Series information
            parent (QListWidget, optional): Parent list widget
        """
        super(SeriesItem, self).__init__(parent)
        
        # Store series information
        self.series_info = series_info
        
        # Set display text
        self.setText(self._format_display_text())
        
        # Set tooltip
        self.setToolTip(self._format_tooltip())
        
        # Set icon based on modality
        self.setIcon(self._get_modality_icon())
    
    def _format_display_text(self):
        """
        Format display text for the item.
        
        Returns:
            str: Formatted display text
        """
        # Get series information
        series_number = self.series_info.get('series_number', '')
        series_desc = self.series_info.get('series_description', '')
        modality = self.series_info.get('modality', '')
        
        # Format display text
        if series_number and series_desc:
            return f"{series_number}: {series_desc} ({modality})"
        elif series_desc:
            return f"{series_desc} ({modality})"
        elif series_number:
            return f"Series {series_number} ({modality})"
        else:
            return f"{modality} Series"
    
    def _format_tooltip(self):
        """
        Format tooltip text for the item.
        
        Returns:
            str: Formatted tooltip text
        """
        # Get series information
        series_number = self.series_info.get('series_number', '')
        series_desc = self.series_info.get('series_description', '')
        modality = self.series_info.get('modality', '')
        series_date = self.series_info.get('series_date', '')
        series_time = self.series_info.get('series_time', '')
        num_images = self.series_info.get('num_images', 0)
        
        # Format tooltip text
        lines = []
        if series_number:
            lines.append(f"Series Number: {series_number}")
        if series_desc:
            lines.append(f"Description: {series_desc}")
        if modality:
            lines.append(f"Modality: {modality}")
        if series_date:
            lines.append(f"Date: {series_date}")
        if series_time:
            lines.append(f"Time: {series_time}")
        if num_images:
            lines.append(f"Images: {num_images}")
        
        return "\n".join(lines)
    
    def _get_modality_icon(self):
        """
        Get icon based on modality.
        
        Returns:
            QIcon: Modality icon
        """
        # Get modality
        modality = self.series_info.get('modality', '').upper()
        
        # Return icon based on modality
        if modality == 'CT':
            return QtGui.QIcon.fromTheme('image-x-generic')
        elif modality == 'PT' or modality == 'PET':
            return QtGui.QIcon.fromTheme('image-x-generic')
        elif modality == 'MR':
            return QtGui.QIcon.fromTheme('image-x-generic')
        elif modality == 'NM':
            return QtGui.QIcon.fromTheme('image-x-generic')
        elif modality == 'US':
            return QtGui.QIcon.fromTheme('image-x-generic')
        elif modality == 'XA':
            return QtGui.QIcon.fromTheme('image-x-generic')
        else:
            return QtGui.QIcon.fromTheme('image-x-generic')


class SeriesListWidget(QtWidgets.QListWidget):
    """
    List widget for displaying and selecting DICOM series.
    """
    
    # Signal emitted when a series is selected
    seriesSelected = QtCore.pyqtSignal(dict)
    
    # Signal emitted when a series is double-clicked
    seriesDoubleClicked = QtCore.pyqtSignal(dict)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesListWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesListWidget, self).__init__(parent)
        
        # Set selection mode
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        
        # Set drag and drop
        self.setDragEnabled(True)
        self.setAcceptDrops(False)
        self.setDragDropMode(QtWidgets.QAbstractItemView.DragOnly)
        
        # Connect signals
        self.itemClicked.connect(self._on_item_clicked)
        self.itemDoubleClicked.connect(self._on_item_double_clicked)
        
        # Set style
        self.setStyleSheet("""
            QListWidget {
                border: 1px solid #ccc;
                border-radius: 3px;
                background-color: #fff;
            }
            QListWidget::item {
                border-bottom: 1px solid #eee;
                padding: 4px;
            }
            QListWidget::item:selected {
                background-color: #e0e0e0;
                color: #000;
            }
            QListWidget::item:hover {
                background-color: #f0f0f0;
            }
        """)
    
    def add_series(self, series_info):
        """
        Add a series to the list.
        
        Args:
            series_info (dict): Series information
            
        Returns:
            SeriesItem: Created series item
        """
        # Create series item
        item = SeriesItem(series_info, self)
        
        # Add to list
        self.addItem(item)
        
        return item
    
    def add_series_list(self, series_list):
        """
        Add multiple series to the list.
        
        Args:
            series_list (list): List of series information dictionaries
        """
        # Clear list
        self.clear()
        
        # Add series
        for series_info in series_list:
            self.add_series(series_info)
    
    def get_selected_series(self):
        """
        Get the selected series.
        
        Returns:
            list: List of selected series information dictionaries
        """
        # Get selected items
        selected_items = self.selectedItems()
        
        # Return series information
        return [item.series_info for item in selected_items]
    
    def _on_item_clicked(self, item):
        """
        Handle item click.
        
        Args:
            item (SeriesItem): Clicked item
        """
        # Emit signal
        self.seriesSelected.emit(item.series_info)
    
    def _on_item_double_clicked(self, item):
        """
        Handle item double click.
        
        Args:
            item (SeriesItem): Double-clicked item
        """
        # Emit signal
        self.seriesDoubleClicked.emit(item.series_info)


class SeriesFilterWidget(QtWidgets.QWidget):
    """
    Widget for filtering series list.
    """
    
    # Signal emitted when filter changes
    filterChanged = QtCore.pyqtSignal(dict)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesFilterWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesFilterWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create filter input
        self.filter_input = QtWidgets.QLineEdit()
        self.filter_input.setPlaceholderText("Filter series...")
        self.filter_input.setClearButtonEnabled(True)
        self.filter_input.textChanged.connect(self._on_filter_changed)
        layout.addWidget(self.filter_input, 1)
        
        # Create modality filter
        self.modality_combo = QtWidgets.QComboBox()
        self.modality_combo.addItem("All Modalities")
        self.modality_combo.addItem("CT")
        self.modality_combo.addItem("PET")
        self.modality_combo.addItem("MR")
        self.modality_combo.addItem("NM")
        self.modality_combo.addItem("US")
        self.modality_combo.addItem("XA")
        self.modality_combo.currentIndexChanged.connect(self._on_filter_changed)
        layout.addWidget(self.modality_combo)
        
        # Set style
        self.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ccc;
                border-radius: 3px;
                padding: 4px;
                background-color: #fff;
            }
            QComboBox {
                border: 1px solid #ccc;
                border-radius: 3px;
                padding: 4px;
                background-color: #fff;
            }
        """)
    
    def get_filter(self):
        """
        Get the current filter.
        
        Returns:
            dict: Filter criteria
        """
        # Get filter text
        filter_text = self.filter_input.text()
        
        # Get modality filter
        modality = self.modality_combo.currentText()
        if modality == "All Modalities":
            modality = ""
        
        return {
            'text': filter_text,
            'modality': modality
        }
    
    def _on_filter_changed(self):
        """Handle filter change."""
        # Emit signal
        self.filterChanged.emit(self.get_filter())


class SeriesMenuWidget(QtWidgets.QWidget):
    """
    Widget for displaying and selecting series from a menu.
    """
    
    # Signal emitted when a series is selected
    seriesSelected = QtCore.pyqtSignal(dict)
    
    # Signal emitted when series are loaded
    seriesLoaded = QtCore.pyqtSignal(list)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesMenuWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesMenuWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create filter widget
        self.filter_widget = SeriesFilterWidget()
        self.filter_widget.filterChanged.connect(self._on_filter_changed)
        layout.addWidget(self.filter_widget)
        
        # Create series list
        self.series_list = SeriesListWidget()
        self.series_list.seriesSelected.connect(self._on_series_selected)
        self.series_list.seriesDoubleClicked.connect(self._on_series_double_clicked)
        layout.addWidget(self.series_list, 1)
        
        # Create buttons
        button_layout = QtWidgets.QHBoxLayout()
        
        self.refresh_button = QtWidgets.QPushButton("Refresh")
        self.refresh_button.clicked.connect(self._on_refresh_clicked)
        button_layout.addWidget(self.refresh_button)
        
        button_layout.addStretch()
        
        self.open_button = QtWidgets.QPushButton("OPEN")
        self.open_button.clicked.connect(self._on_open_clicked)
        self.open_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
        """)
        button_layout.addWidget(self.open_button)
        
        layout.addLayout(button_layout)
        
        # Initialize variables
        self.all_series = []
        self.filtered_series = []
    
    def set_series_list(self, series_list):
        """
        Set the series list.
        
        Args:
            series_list (list): List of series information dictionaries
        """
        # Store all series
        self.all_series = series_list
        
        # Apply filter
        self._apply_filter()
    
    def get_selected_series(self):
        """
        Get the selected series.
        
        Returns:
            list: List of selected series information dictionaries
        """
        return self.series_list.get_selected_series()
    
    def _apply_filter(self):
        """Apply filter to series list."""
        # Get filter
        filter_criteria = self.filter_widget.get_filter()
        
        # Filter series
        filtered_series = []
        for series in self.all_series:
            # Check modality filter
            if filter_criteria['modality'] and series.get('modality', '').upper() != filter_criteria['modality'].upper():
                continue
            
            # Check text filter
            if filter_criteria['text']:
                # Search in series description and number
                series_desc = series.get('series_description', '').lower()
                series_number = str(series.get('series_number', '')).lower()
                filter_text = filter_criteria['text'].lower()
                
                if filter_text not in series_desc and filter_text not in series_number:
                    continue
            
            # Add to filtered list
            filtered_series.append(series)
        
        # Store filtered series
        self.filtered_series = filtered_series
        
        # Update series list
        self.series_list.add_series_list(filtered_series)
    
    def _on_filter_changed(self, filter_criteria):
        """
        Handle filter change.
        
        Args:
            filter_criteria (dict): Filter criteria
        """
        # Apply filter
        self._apply_filter()
    
    def _on_series_selected(self, series_info):
        """
        Handle series selection.
        
        Args:
            series_info (dict): Series information
        """
        # Emit signal
        self.seriesSelected.emit(series_info)
    
    def _on_series_double_clicked(self, series_info):
        """
        Handle series double click.
        
        Args:
            series_info (dict): Series information
        """
        # Load series
        self._load_selected_series()
    
    def _on_refresh_clicked(self):
        """Handle refresh button click."""
        # Emit signal to request refresh
        self.seriesLoaded.emit([])
    
    def _on_open_clicked(self):
        """Handle open button click."""
        # Load selected series
        self._load_selected_series()
    
    def _load_selected_series(self):
        """Load selected series."""
        # Get selected series
        selected_series = self.get_selected_series()
        
        # Emit signal
        if selected_series:
            self.seriesLoaded.emit(selected_series)


class SeriesDropTarget(QtWidgets.QWidget):
    """
    Widget that accepts series drops.
    """
    
    # Signal emitted when a series is dropped
    seriesDropped = QtCore.pyqtSignal(dict)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesDropTarget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesDropTarget, self).__init__(parent)
        
        # Enable drag and drop
        self.setAcceptDrops(True)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Create label
        self.label = QtWidgets.QLabel("Drop Series Here")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(self.label)
        
        # Set style
        self.setStyleSheet("""
            SeriesDropTarget {
                border: 2px dashed #ccc;
                border-radius: 5px;
                background-color: #f9f9f9;
            }
            SeriesDropTarget:hover {
                border-color: #999;
            }
        """)
    
    def dragEnterEvent(self, event):
        """
        Handle drag enter event.
        
        Args:
            event (QDragEnterEvent): Drag enter event
        """
        # Accept drag if it has series data
        if event.mimeData().hasFormat("application/x-qabstractitemmodeldatalist"):
            event.acceptProposedAction()
    
    def dropEvent(self, event):
        """
        Handle drop event.
        
        Args:
            event (QDropEvent): Drop event
        """
        # Get dropped data
        data = event.mimeData()
        
        # Process dropped data
        if data.hasFormat("application/x-qabstractitemmodeldatalist"):
            # Get source widget
            source = event.source()
            
            # Check if source is a SeriesListWidget
            if isinstance(source, SeriesListWidget):
                # Get selected series
                selected_series = source.get_selected_series()
                
                # Emit signal for each series
                for series_info in selected_series:
                    self.seriesDropped.emit(series_info)
        
        # Accept drop
        event.acceptProposedAction()


class SeriesTypeSelector(QtWidgets.QWidget):
    """
    Widget for selecting series type (PET, CT, etc.).
    """
    
    # Signal emitted when type is selected
    typeSelected = QtCore.pyqtSignal(str)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesTypeSelector.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesTypeSelector, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create type buttons
        self.type_buttons = {}
        
        # Create button group
        self.button_group = QtWidgets.QButtonGroup(self)
        self.button_group.setExclusive(True)
        
        # Add type buttons
        self._add_type_button("CT", "CT")
        self._add_type_button("PET", "PET")
        self._add_type_button("FUSION", "Fusion")
        
        # Add buttons to layout
        for button in self.type_buttons.values():
            layout.addWidget(button)
    
    def _add_type_button(self, type_id, label):
        """
        Add a type button.
        
        Args:
            type_id (str): Type identifier
            label (str): Button label
        """
        # Create button
        button = QtWidgets.QPushButton(label)
        button.setCheckable(True)
        button.clicked.connect(lambda checked, tid=type_id: self._on_type_selected(tid))
        
        # Add to button group
        self.button_group.addButton(button)
        
        # Store button
        self.type_buttons[type_id] = button
    
    def select_type(self, type_id):
        """
        Select a type.
        
        Args:
            type_id (str): Type identifier
            
        Returns:
            bool: True if type was selected, False otherwise
        """
        if type_id in self.type_buttons:
            self.type_buttons[type_id].setChecked(True)
            self.typeSelected.emit(type_id)
            return True
        return False
    
    def get_selected_type(self):
        """
        Get the selected type.
        
        Returns:
            str: Selected type, or None if no type is selected
        """
        for type_id, button in self.type_buttons.items():
            if button.isChecked():
                return type_id
        return None
    
    def _on_type_selected(self, type_id):
        """
        Handle type selection.
        
        Args:
            type_id (str): Type identifier
        """
        # Emit signal
        self.typeSelected.emit(type_id)


class SeriesAssignmentWidget(QtWidgets.QWidget):
    """
    Widget for assigning series to specific types (PET, CT, etc.).
    """
    
    # Signal emitted when series assignment changes
    assignmentChanged = QtCore.pyqtSignal(dict)
    
    def __init__(self, parent=None):
        """
        Initialize the SeriesAssignmentWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SeriesAssignmentWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create assignment widgets
        self.assignment_widgets = {}
        
        # Create CT assignment
        ct_layout = QtWidgets.QHBoxLayout()
        ct_layout.addWidget(QtWidgets.QLabel("CT Series:"))
        self.ct_label = QtWidgets.QLabel("None")
        self.ct_label.setStyleSheet("font-weight: bold;")
        ct_layout.addWidget(self.ct_label, 1)
        self.ct_clear_button = QtWidgets.QPushButton("Clear")
        self.ct_clear_button.clicked.connect(lambda: self._clear_assignment("CT"))
        ct_layout.addWidget(self.ct_clear_button)
        layout.addLayout(ct_layout)
        
        # Create PET assignment
        pet_layout = QtWidgets.QHBoxLayout()
        pet_layout.addWidget(QtWidgets.QLabel("PET Series:"))
        self.pet_label = QtWidgets.QLabel("None")
        self.pet_label.setStyleSheet("font-weight: bold;")
        pet_layout.addWidget(self.pet_label, 1)
        self.pet_clear_button = QtWidgets.QPushButton("Clear")
        self.pet_clear_button.clicked.connect(lambda: self._clear_assignment("PET"))
        pet_layout.addWidget(self.pet_clear_button)
        layout.addLayout(pet_layout)
        
        # Store assignment widgets
        self.assignment_widgets["CT"] = {
            'label': self.ct_label,
            'clear_button': self.ct_clear_button
        }
        self.assignment_widgets["PET"] = {
            'label': self.pet_label,
            'clear_button': self.pet_clear_button
        }
        
        # Create load button
        self.load_button = QtWidgets.QPushButton("Load Series")
        self.load_button.clicked.connect(self._on_load_clicked)
        self.load_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
        """)
        layout.addWidget(self.load_button)
        
        # Initialize variables
        self.assignments = {
            "CT": None,
            "PET": None
        }
    
    def set_assignment(self, type_id, series_info):
        """
        Set series assignment.
        
        Args:
            type_id (str): Type identifier
            series_info (dict): Series information
            
        Returns:
            bool: True if assignment was set, False otherwise
        """
        if type_id not in self.assignment_widgets:
            return False
        
        # Store assignment
        self.assignments[type_id] = series_info
        
        # Update label
        if series_info:
            # Get series information
            series_number = series_info.get('series_number', '')
            series_desc = series_info.get('series_description', '')
            modality = series_info.get('modality', '')
            
            # Format display text
            if series_number and series_desc:
                text = f"{series_number}: {series_desc} ({modality})"
            elif series_desc:
                text = f"{series_desc} ({modality})"
            elif series_number:
                text = f"Series {series_number} ({modality})"
            else:
                text = f"{modality} Series"
            
            self.assignment_widgets[type_id]['label'].setText(text)
        else:
            self.assignment_widgets[type_id]['label'].setText("None")
        
        # Emit signal
        self.assignmentChanged.emit(self.assignments)
        
        return True
    
    def get_assignments(self):
        """
        Get all series assignments.
        
        Returns:
            dict: Series assignments
        """
        return self.assignments
    
    def _clear_assignment(self, type_id):
        """
        Clear series assignment.
        
        Args:
            type_id (str): Type identifier
        """
        self.set_assignment(type_id, None)
    
    def _on_load_clicked(self):
        """Handle load button click."""
        # Check if any series is assigned
        has_assignment = False
        for series_info in self.assignments.values():
            if series_info:
                has_assignment = True
                break
        
        if not has_assignment:
            # Show warning
            QtWidgets.QMessageBox.warning(
                self,
                "No Series Assigned",
                "Please assign at least one series before loading."
            )
            return
        
        # Emit signal
        self.assignmentChanged.emit(self.assignments)


class SeriesSelectionDialog(QtWidgets.QDialog):
    """
    Dialog for selecting series.
    """
    
    def __init__(self, series_list=None, parent=None):
        """
        Initialize the SeriesSelectionDialog.
        
        Args:
            series_list (list, optional): List of series information dictionaries
            parent (QWidget, optional): Parent widget
        """
        super(SeriesSelectionDialog, self).__init__(parent)
        
        # Set window properties
        self.setWindowTitle("Select Series")
        self.setMinimumSize(600, 400)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create series menu
        self.series_menu = SeriesMenuWidget()
        layout.addWidget(self.series_menu, 1)
        
        # Create assignment widget
        self.assignment_widget = SeriesAssignmentWidget()
        layout.addWidget(self.assignment_widget)
        
        # Create buttons
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()
        
        self.cancel_button = QtWidgets.QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_button)
        
        self.ok_button = QtWidgets.QPushButton("OK")
        self.ok_button.clicked.connect(self.accept)
        self.ok_button.setDefault(True)
        button_layout.addWidget(self.ok_button)
        
        layout.addLayout(button_layout)
        
        # Connect signals
        self.series_menu.seriesSelected.connect(self._on_series_selected)
        self.series_menu.seriesLoaded.connect(self._on_series_loaded)
        
        # Set series list
        if series_list:
            self.series_menu.set_series_list(series_list)
    
    def get_assignments(self):
        """
        Get series assignments.
        
        Returns:
            dict: Series assignments
        """
        return self.assignment_widget.get_assignments()
    
    def _on_series_selected(self, series_info):
        """
        Handle series selection.
        
        Args:
            series_info (dict): Series information
        """
        # Get modality
        modality = series_info.get('modality', '').upper()
        
        # Assign to appropriate type
        if modality == 'CT':
            self.assignment_widget.set_assignment("CT", series_info)
        elif modality == 'PT' or modality == 'PET':
            self.assignment_widget.set_assignment("PET", series_info)
    
    def _on_series_loaded(self, selected_series):
        """
        Handle series loading.
        
        Args:
            selected_series (list): List of selected series information dictionaries
        """
        # Process each selected series
        for series_info in selected_series:
            self._on_series_selected(series_info)


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("Series Selection Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QHBoxLayout(central_widget)
    
    # Create series menu
    series_menu = SeriesMenuWidget()
    layout.addWidget(series_menu, 1)
    
    # Create right panel
    right_panel = QtWidgets.QWidget()
    right_layout = QtWidgets.QVBoxLayout(right_panel)
    
    # Create type selector
    type_selector = SeriesTypeSelector()
    right_layout.addWidget(type_selector)
    
    # Create drop target
    drop_target = SeriesDropTarget()
    right_layout.addWidget(drop_target, 1)
    
    # Create assignment widget
    assignment_widget = SeriesAssignmentWidget()
    right_layout.addWidget(assignment_widget)
    
    # Add right panel to layout
    layout.addWidget(right_panel)
    
    # Connect signals
    series_menu.seriesSelected.connect(lambda series_info: print(f"Series selected: {series_info}"))
    series_menu.seriesLoaded.connect(lambda series_list: print(f"Series loaded: {len(series_list)} series"))
    type_selector.typeSelected.connect(lambda type_id: print(f"Type selected: {type_id}"))
    drop_target.seriesDropped.connect(lambda series_info: assignment_widget.set_assignment(type_selector.get_selected_type(), series_info))
    assignment_widget.assignmentChanged.connect(lambda assignments: print(f"Assignments: {assignments}"))
    
    # Add some test series
    test_series = [
        {
            'series_number': '1',
            'series_description': 'CT Chest',
            'modality': 'CT',
            'series_date': '20250518',
            'series_time': '102030',
            'num_images': 120
        },
        {
            'series_number': '2',
            'series_description': 'PET Whole Body',
            'modality': 'PT',
            'series_date': '20250518',
            'series_time': '102030',
            'num_images': 80
        },
        {
            'series_number': '3',
            'series_description': 'CT Abdomen',
            'modality': 'CT',
            'series_date': '20250518',
            'series_time': '102030',
            'num_images': 100
        }
    ]
    series_menu.set_series_list(test_series)
    
    # Select default type
    type_selector.select_type("CT")
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
