#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Search and Tools UI Module for PET/CT Viewer
-----------------------------------------
This module provides enhanced search bar and tool display functionality.
"""

import os
import sys
import logging
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('SearchToolsUI')

class SearchBar(QtWidgets.QWidget):
    """
    Enhanced search bar widget with autocomplete and filtering capabilities.
    """
    
    # Signal emitted when search is performed
    searchPerformed = QtCore.pyqtSignal(str)
    
    # Signal emitted when search criteria changes
    searchCriteriaChanged = QtCore.pyqtSignal(dict)
    
    def __init__(self, parent=None):
        """
        Initialize the SearchBar.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SearchBar, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        
        # Create search icon
        search_icon = QtWidgets.QLabel()
        search_icon.setPixmap(self.style().standardIcon(QtWidgets.QStyle.SP_FileDialogContentsView).pixmap(16, 16))
        layout.addWidget(search_icon)
        
        # Create search input
        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText("Search by patient name, ID, date...")
        self.search_input.setClearButtonEnabled(True)
        self.search_input.returnPressed.connect(self._on_search)
        self.search_input.textChanged.connect(self._on_text_changed)
        layout.addWidget(self.search_input, 1)
        
        # Create search button
        self.search_button = QtWidgets.QPushButton("Search")
        self.search_button.clicked.connect(self._on_search)
        layout.addWidget(self.search_button)
        
        # Create advanced search button
        self.advanced_button = QtWidgets.QPushButton("Advanced")
        self.advanced_button.setCheckable(True)
        self.advanced_button.clicked.connect(self._on_advanced_toggled)
        layout.addWidget(self.advanced_button)
        
        # Create advanced search panel
        self.advanced_panel = QtWidgets.QWidget()
        self.advanced_panel.setVisible(False)
        
        # Create advanced search layout
        advanced_layout = QtWidgets.QGridLayout(self.advanced_panel)
        advanced_layout.setContentsMargins(0, 10, 0, 0)
        
        # Add advanced search fields
        advanced_layout.addWidget(QtWidgets.QLabel("Patient Name:"), 0, 0)
        self.patient_name_input = QtWidgets.QLineEdit()
        advanced_layout.addWidget(self.patient_name_input, 0, 1)
        
        advanced_layout.addWidget(QtWidgets.QLabel("Patient ID:"), 0, 2)
        self.patient_id_input = QtWidgets.QLineEdit()
        advanced_layout.addWidget(self.patient_id_input, 0, 3)
        
        advanced_layout.addWidget(QtWidgets.QLabel("Study Date:"), 1, 0)
        self.date_from_input = QtWidgets.QDateEdit(QtCore.QDate.currentDate().addDays(-30))
        self.date_from_input.setCalendarPopup(True)
        advanced_layout.addWidget(self.date_from_input, 1, 1)
        
        advanced_layout.addWidget(QtWidgets.QLabel("to"), 1, 2, QtCore.Qt.AlignCenter)
        self.date_to_input = QtWidgets.QDateEdit(QtCore.QDate.currentDate())
        self.date_to_input.setCalendarPopup(True)
        advanced_layout.addWidget(self.date_to_input, 1, 3)
        
        advanced_layout.addWidget(QtWidgets.QLabel("Study Type:"), 2, 0)
        self.study_type_combo = QtWidgets.QComboBox()
        self.study_type_combo.addItems(["All", "PET/CT", "CT", "PET"])
        advanced_layout.addWidget(self.study_type_combo, 2, 1)
        
        advanced_layout.addWidget(QtWidgets.QLabel("Modality:"), 2, 2)
        self.modality_combo = QtWidgets.QComboBox()
        self.modality_combo.addItems(["All", "PET", "CT", "MR", "NM", "US", "XA"])
        advanced_layout.addWidget(self.modality_combo, 2, 3)
        
        # Create advanced search buttons
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()
        
        self.clear_button = QtWidgets.QPushButton("Clear")
        self.clear_button.clicked.connect(self._on_clear)
        button_layout.addWidget(self.clear_button)
        
        self.apply_button = QtWidgets.QPushButton("Apply")
        self.apply_button.clicked.connect(self._on_apply)
        button_layout.addWidget(self.apply_button)
        
        advanced_layout.addLayout(button_layout, 3, 0, 1, 4)
        
        # Add advanced panel to main layout
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addLayout(layout)
        main_layout.addWidget(self.advanced_panel)
        
        self.setLayout(main_layout)
        
        # Set style
        self.setStyleSheet("""
            QLineEdit {
                border: 1px solid #ccc;
                border-radius: 3px;
                padding: 4px;
                background-color: #fff;
            }
            QPushButton {
                border: 1px solid #ccc;
                border-radius: 3px;
                padding: 4px 8px;
                background-color: #f5f5f5;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
            QPushButton:pressed {
                background-color: #d0d0d0;
            }
            QPushButton:checked {
                background-color: #d0d0d0;
            }
        """)
    
    def set_completer_items(self, items):
        """
        Set autocomplete items for the search input.
        
        Args:
            items (list): List of autocomplete items
        """
        completer = QtWidgets.QCompleter(items)
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.search_input.setCompleter(completer)
    
    def get_search_text(self):
        """
        Get the current search text.
        
        Returns:
            str: Search text
        """
        return self.search_input.text()
    
    def get_search_criteria(self):
        """
        Get the current search criteria.
        
        Returns:
            dict: Search criteria
        """
        return {
            'text': self.search_input.text(),
            'patient_name': self.patient_name_input.text(),
            'patient_id': self.patient_id_input.text(),
            'date_from': self.date_from_input.date().toString(QtCore.Qt.ISODate),
            'date_to': self.date_to_input.date().toString(QtCore.Qt.ISODate),
            'study_type': self.study_type_combo.currentText(),
            'modality': self.modality_combo.currentText()
        }
    
    def _on_search(self):
        """Handle search button click or Enter key press."""
        search_text = self.search_input.text()
        self.searchPerformed.emit(search_text)
    
    def _on_text_changed(self, text):
        """
        Handle search text change.
        
        Args:
            text (str): New search text
        """
        # Update advanced search fields if simple search changes
        if text and not self.patient_name_input.text():
            self.patient_name_input.setText(text)
        
        # Emit signal with updated criteria
        self.searchCriteriaChanged.emit(self.get_search_criteria())
    
    def _on_advanced_toggled(self, checked):
        """
        Handle advanced search button toggle.
        
        Args:
            checked (bool): Button checked state
        """
        self.advanced_panel.setVisible(checked)
        
        # Update layout
        self.updateGeometry()
        
        # Update parent layout if any
        parent = self.parentWidget()
        if parent:
            parent.updateGeometry()
    
    def _on_clear(self):
        """Handle clear button click."""
        self.search_input.clear()
        self.patient_name_input.clear()
        self.patient_id_input.clear()
        self.date_from_input.setDate(QtCore.QDate.currentDate().addDays(-30))
        self.date_to_input.setDate(QtCore.QDate.currentDate())
        self.study_type_combo.setCurrentIndex(0)
        self.modality_combo.setCurrentIndex(0)
        
        # Emit signal with updated criteria
        self.searchCriteriaChanged.emit(self.get_search_criteria())
    
    def _on_apply(self):
        """Handle apply button click."""
        # Update simple search field with patient name
        if self.patient_name_input.text() and not self.search_input.text():
            self.search_input.setText(self.patient_name_input.text())
        
        # Emit signal with updated criteria
        self.searchCriteriaChanged.emit(self.get_search_criteria())
        
        # Hide advanced panel
        self.advanced_button.setChecked(False)
        self.advanced_panel.setVisible(False)
        
        # Perform search
        self._on_search()


class ToolButton(QtWidgets.QPushButton):
    """
    Enhanced tool button with icon and tooltip.
    """
    
    def __init__(self, icon_name, text, tooltip="", parent=None):
        """
        Initialize the ToolButton.
        
        Args:
            icon_name (str): Icon name or path
            text (str): Button text
            tooltip (str): Button tooltip
            parent (QWidget, optional): Parent widget
        """
        super(ToolButton, self).__init__(parent)
        
        # Set properties
        self.setText(text)
        self.setToolTip(tooltip)
        self.setCheckable(True)
        self.setAutoExclusive(True)
        
        # Set icon
        if icon_name.startswith(":"):
            # Use resource path
            self.setIcon(QtGui.QIcon(icon_name))
        elif os.path.isfile(icon_name):
            # Use file path
            self.setIcon(QtGui.QIcon(icon_name))
        else:
            # Use standard icon
            self.setIcon(self.style().standardIcon(self._get_standard_icon(icon_name)))
        
        # Set size
        self.setIconSize(QtCore.QSize(24, 24))
        
        # Set style
        self.setStyleSheet("""
            QPushButton {
                border: 1px solid #ccc;
                border-radius: 3px;
                padding: 4px;
                background-color: #f5f5f5;
                min-width: 80px;
                max-width: 120px;
                min-height: 60px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
            QPushButton:pressed, QPushButton:checked {
                background-color: #d0d0d0;
                border: 1px solid #999;
            }
        """)
    
    def _get_standard_icon(self, name):
        """
        Get standard icon enum value from name.
        
        Args:
            name (str): Icon name
            
        Returns:
            QStyle.StandardPixmap: Standard icon enum value
        """
        icon_map = {
            "file": QtWidgets.QStyle.SP_FileIcon,
            "folder": QtWidgets.QStyle.SP_DirIcon,
            "save": QtWidgets.QStyle.SP_DialogSaveButton,
            "open": QtWidgets.QStyle.SP_DialogOpenButton,
            "close": QtWidgets.QStyle.SP_DialogCloseButton,
            "help": QtWidgets.QStyle.SP_DialogHelpButton,
            "refresh": QtWidgets.QStyle.SP_BrowserReload,
            "computer": QtWidgets.QStyle.SP_ComputerIcon,
            "home": QtWidgets.QStyle.SP_DirHomeIcon,
            "trash": QtWidgets.QStyle.SP_TrashIcon,
            "search": QtWidgets.QStyle.SP_FileDialogContentsView,
            "settings": QtWidgets.QStyle.SP_FileDialogDetailedView
        }
        
        return icon_map.get(name.lower(), QtWidgets.QStyle.SP_CustomBase)


class ToolBar(QtWidgets.QWidget):
    """
    Enhanced toolbar with tool buttons and groups.
    """
    
    # Signal emitted when a tool is selected
    toolSelected = QtCore.pyqtSignal(str, str)  # group_id, tool_id
    
    def __init__(self, parent=None):
        """
        Initialize the ToolBar.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(ToolBar, self).__init__(parent)
        
        # Create layout
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(5)
        
        # Create toolbar layout
        self.toolbar_layout = QtWidgets.QHBoxLayout()
        self.toolbar_layout.setContentsMargins(0, 0, 0, 0)
        self.toolbar_layout.setSpacing(10)
        self.main_layout.addLayout(self.toolbar_layout)
        
        # Initialize variables
        self.tool_groups = {}
        self.current_group = None
        self.current_tool = None
        
        # Set style
        self.setStyleSheet("""
            QWidget {
                background-color: #f0f0f0;
            }
            QGroupBox {
                border: 1px solid #ccc;
                border-radius: 3px;
                margin-top: 0.5em;
                padding-top: 0.5em;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
        """)
    
    def add_tool_group(self, group_id, title):
        """
        Add a tool group.
        
        Args:
            group_id (str): Group identifier
            title (str): Group title
            
        Returns:
            QGroupBox: Created group box
        """
        # Create group box
        group_box = QtWidgets.QGroupBox(title)
        
        # Create layout for group
        group_layout = QtWidgets.QHBoxLayout(group_box)
        group_layout.setContentsMargins(5, 5, 5, 5)
        group_layout.setSpacing(5)
        
        # Add to toolbar layout
        self.toolbar_layout.addWidget(group_box)
        
        # Store reference
        self.tool_groups[group_id] = {
            'group_box': group_box,
            'tools': {}
        }
        
        return group_box
    
    def add_tool(self, group_id, tool_id, icon_name, text, tooltip=""):
        """
        Add a tool button to a group.
        
        Args:
            group_id (str): Group identifier
            tool_id (str): Tool identifier
            icon_name (str): Icon name or path
            text (str): Button text
            tooltip (str): Button tooltip
            
        Returns:
            ToolButton: Created tool button
        """
        if group_id not in self.tool_groups:
            logger.warning(f"Tool group '{group_id}' not found")
            return None
        
        # Create tool button
        button = ToolButton(icon_name, text, tooltip)
        button.clicked.connect(lambda checked, gid=group_id, tid=tool_id: self._on_tool_selected(gid, tid))
        
        # Add to group layout
        group_box = self.tool_groups[group_id]['group_box']
        group_box.layout().addWidget(button)
        
        # Store reference
        self.tool_groups[group_id]['tools'][tool_id] = button
        
        return button
    
    def add_separator(self):
        """Add a separator to the toolbar."""
        separator = QtWidgets.QFrame()
        separator.setFrameShape(QtWidgets.QFrame.VLine)
        separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.toolbar_layout.addWidget(separator)
    
    def add_stretch(self):
        """Add stretch to the toolbar."""
        self.toolbar_layout.addStretch()
    
    def select_tool(self, group_id, tool_id):
        """
        Select a tool.
        
        Args:
            group_id (str): Group identifier
            tool_id (str): Tool identifier
            
        Returns:
            bool: True if tool was selected, False otherwise
        """
        if group_id not in self.tool_groups:
            logger.warning(f"Tool group '{group_id}' not found")
            return False
        
        if tool_id not in self.tool_groups[group_id]['tools']:
            logger.warning(f"Tool '{tool_id}' not found in group '{group_id}'")
            return False
        
        # Get tool button
        button = self.tool_groups[group_id]['tools'][tool_id]
        
        # Check button
        button.setChecked(True)
        
        # Update current tool
        self.current_group = group_id
        self.current_tool = tool_id
        
        # Emit signal
        self.toolSelected.emit(group_id, tool_id)
        
        return True
    
    def get_current_tool(self):
        """
        Get the current tool.
        
        Returns:
            tuple: (group_id, tool_id) or (None, None) if no tool is selected
        """
        return (self.current_group, self.current_tool)
    
    def _on_tool_selected(self, group_id, tool_id):
        """
        Handle tool selection.
        
        Args:
            group_id (str): Group identifier
            tool_id (str): Tool identifier
        """
        # Update current tool
        self.current_group = group_id
        self.current_tool = tool_id
        
        # Emit signal
        self.toolSelected.emit(group_id, tool_id)


class TopMenuBar(QtWidgets.QWidget):
    """
    Top menu bar with search and tools.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the TopMenuBar.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(TopMenuBar, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        
        # Create top bar layout
        top_layout = QtWidgets.QHBoxLayout()
        top_layout.setContentsMargins(5, 5, 5, 5)
        top_layout.setSpacing(10)
        
        # Create search bar
        self.search_bar = SearchBar()
        top_layout.addWidget(self.search_bar, 1)
        
        # Add top bar to main layout
        layout.addLayout(top_layout)
        
        # Create toolbar
        self.toolbar = ToolBar()
        layout.addWidget(self.toolbar)
        
        # Set fixed height
        self.setFixedHeight(self.sizeHint().height())
        
        # Set style
        self.setStyleSheet("""
            QWidget {
                background-color: #f0f0f0;
            }
        """)
        
        # Initialize toolbar with default tools
        self._init_default_tools()
    
    def _init_default_tools(self):
        """Initialize toolbar with default tools."""
        # Add file tools
        file_group = self.toolbar.add_tool_group("file", "File")
        self.toolbar.add_tool("file", "open", "open", "Open", "Open DICOM files")
        self.toolbar.add_tool("file", "save", "save", "Save", "Save current view")
        self.toolbar.add_tool("file", "export", "file", "Export", "Export to file")
        
        # Add separator
        self.toolbar.add_separator()
        
        # Add view tools
        view_group = self.toolbar.add_tool_group("view", "View")
        self.toolbar.add_tool("view", "layout_3x3", "settings", "3x3", "3x3 layout")
        self.toolbar.add_tool("view", "layout_2x2", "settings", "2x2", "2x2 layout")
        self.toolbar.add_tool("view", "layout_1x3", "settings", "1x3", "1x3 layout")
        
        # Add separator
        self.toolbar.add_separator()
        
        # Add measurement tools
        measure_group = self.toolbar.add_tool_group("measure", "Measure")
        self.toolbar.add_tool("measure", "pointer", "search", "Pointer", "Select tool")
        self.toolbar.add_tool("measure", "distance", "settings", "Distance", "Measure distance")
        self.toolbar.add_tool("measure", "angle", "settings", "Angle", "Measure angle")
        self.toolbar.add_tool("measure", "roi", "settings", "ROI", "Region of interest")
        self.toolbar.add_tool("measure", "suv", "settings", "SUV", "SUV measurement")
        
        # Add separator
        self.toolbar.add_separator()
        
        # Add window tools
        window_group = self.toolbar.add_tool_group("window", "Window")
        self.toolbar.add_tool("window", "soft_tissue", "settings", "Soft", "Soft tissue window")
        self.toolbar.add_tool("window", "lung", "settings", "Lung", "Lung window")
        self.toolbar.add_tool("window", "bone", "settings", "Bone", "Bone window")
        self.toolbar.add_tool("window", "brain", "settings", "Brain", "Brain window")
        
        # Add stretch
        self.toolbar.add_stretch()
        
        # Add PACS tools
        pacs_group = self.toolbar.add_tool_group("pacs", "PACS")
        self.toolbar.add_tool("pacs", "connect", "computer", "Connect", "Connect to PACS")
        self.toolbar.add_tool("pacs", "query", "search", "Query", "Query PACS")
        self.toolbar.add_tool("pacs", "retrieve", "folder", "Retrieve", "Retrieve from PACS")
        
        # Select default tool
        self.toolbar.select_tool("measure", "pointer")


class SearchResultsWidget(QtWidgets.QWidget):
    """
    Widget for displaying search results.
    """
    
    # Signal emitted when a result is selected
    resultSelected = QtCore.pyqtSignal(dict)
    
    def __init__(self, parent=None):
        """
        Initialize the SearchResultsWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(SearchResultsWidget, self).__init__(parent)
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create results table
        self.results_table = QtWidgets.QTableWidget()
        self.results_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.results_table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.results_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.results_table.setAlternatingRowColors(True)
        self.results_table.setColumnCount(5)
        self.results_table.setHorizontalHeaderLabels(["Patient Name", "Patient ID", "Study Date", "Modality", "Description"])
        self.results_table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.results_table.verticalHeader().setVisible(False)
        self.results_table.itemDoubleClicked.connect(self._on_item_double_clicked)
        
        # Create buttons
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()
        
        self.open_button = QtWidgets.QPushButton("Open")
        self.open_button.clicked.connect(self._on_open_clicked)
        button_layout.addWidget(self.open_button)
        
        # Add widgets to layout
        layout.addWidget(self.results_table)
        layout.addLayout(button_layout)
    
    def set_results(self, results):
        """
        Set search results.
        
        Args:
            results (list): List of result dictionaries
        """
        # Clear table
        self.results_table.setRowCount(0)
        
        # Add results
        for result in results:
            row = self.results_table.rowCount()
            self.results_table.insertRow(row)
            
            # Add items
            self.results_table.setItem(row, 0, QtWidgets.QTableWidgetItem(result.get('patient_name', '')))
            self.results_table.setItem(row, 1, QtWidgets.QTableWidgetItem(result.get('patient_id', '')))
            self.results_table.setItem(row, 2, QtWidgets.QTableWidgetItem(result.get('study_date', '')))
            self.results_table.setItem(row, 3, QtWidgets.QTableWidgetItem(result.get('modality', '')))
            self.results_table.setItem(row, 4, QtWidgets.QTableWidgetItem(result.get('description', '')))
            
            # Store result data
            for col in range(5):
                self.results_table.item(row, col).setData(QtCore.Qt.UserRole, result)
    
    def get_selected_result(self):
        """
        Get the selected result.
        
        Returns:
            dict: Selected result, or None if no result is selected
        """
        selected_items = self.results_table.selectedItems()
        if selected_items:
            return selected_items[0].data(QtCore.Qt.UserRole)
        return None
    
    def _on_item_double_clicked(self, item):
        """
        Handle item double click.
        
        Args:
            item (QTableWidgetItem): Clicked item
        """
        result = item.data(QtCore.Qt.UserRole)
        if result:
            self.resultSelected.emit(result)
    
    def _on_open_clicked(self):
        """Handle open button click."""
        result = self.get_selected_result()
        if result:
            self.resultSelected.emit(result)


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("Search and Tools UI Test")
    window.setGeometry(100, 100, 1000, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QVBoxLayout(central_widget)
    
    # Create top menu bar
    top_menu = TopMenuBar()
    layout.addWidget(top_menu)
    
    # Create search results widget
    results_widget = SearchResultsWidget()
    layout.addWidget(results_widget, 1)
    
    # Connect signals
    top_menu.search_bar.searchPerformed.connect(lambda text: print(f"Search: {text}"))
    top_menu.search_bar.searchCriteriaChanged.connect(lambda criteria: print(f"Criteria: {criteria}"))
    top_menu.toolbar.toolSelected.connect(lambda group, tool: print(f"Tool: {group}/{tool}"))
    results_widget.resultSelected.connect(lambda result: print(f"Result: {result}"))
    
    # Add some test results
    results = [
        {
            'patient_name': 'John Doe',
            'patient_id': '12345',
            'study_date': '2025-05-18',
            'modality': 'PET/CT',
            'description': 'Whole Body PET/CT'
        },
        {
            'patient_name': 'Jane Smith',
            'patient_id': '67890',
            'study_date': '2025-05-17',
            'modality': 'CT',
            'description': 'Chest CT'
        },
        {
            'patient_name': 'Bob Johnson',
            'patient_id': '24680',
            'study_date': '2025-05-16',
            'modality': 'PET',
            'description': 'Brain PET'
        }
    ]
    results_widget.set_results(results)
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
