#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Color Map and LUT Handler Module for PET/CT Viewer
-----------------------------------------------
This module provides color intensity bars and lookup table controls for DICOM images.
"""

import os
import sys
import logging
import numpy as np
import vtk
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('ColorMapHandler')

class ColorMapHandler:
    """
    Class for handling color maps and lookup tables for DICOM images.
    """
    
    # Constants for modality types
    PET = 0
    CT = 1
    FUSION = 2
    
    # Constants for predefined color maps
    COLORMAP_GRAYSCALE = 0
    COLORMAP_HOT_METAL = 1
    COLORMAP_RAINBOW = 2
    COLORMAP_JET = 3
    COLORMAP_VIRIDIS = 4
    COLORMAP_PLASMA = 5
    COLORMAP_BONE = 6
    COLORMAP_COOL = 7
    
    def __init__(self):
        """Initialize the ColorMapHandler."""
        # Initialize color maps
        self.color_maps = self._create_predefined_color_maps()
        
        # Initialize lookup tables
        self.pet_lut = self._create_lut(self.COLORMAP_HOT_METAL)
        self.ct_lut = self._create_lut(self.COLORMAP_GRAYSCALE)
        self.fusion_lut = self._create_lut(self.COLORMAP_JET)
        
        # Initialize window/level values
        self.pet_window = 6.0
        self.pet_level = 3.0
        self.ct_window = 400.0
        self.ct_level = 40.0
        
        # Update lookup tables with initial window/level values
        self._update_pet_lut()
        self._update_ct_lut()
        self._update_fusion_lut()
    
    def _create_predefined_color_maps(self):
        """
        Create predefined color maps.
        
        Returns:
            dict: Dictionary of color maps
        """
        color_maps = {}
        
        # Grayscale
        color_maps[self.COLORMAP_GRAYSCALE] = [
            (0.0, 0, 0, 0),
            (1.0, 1, 1, 1)
        ]
        
        # Hot Metal
        color_maps[self.COLORMAP_HOT_METAL] = [
            (0.0, 0, 0, 0),      # Black
            (0.2, 0.5, 0, 0),    # Dark red
            (0.4, 0.9, 0.2, 0),  # Red-orange
            (0.6, 1, 0.5, 0),    # Orange
            (0.8, 1, 0.8, 0.2),  # Yellow-orange
            (1.0, 1, 1, 1)       # White
        ]
        
        # Rainbow
        color_maps[self.COLORMAP_RAINBOW] = [
            (0.0, 0, 0, 1),    # Blue
            (0.25, 0, 1, 1),   # Cyan
            (0.5, 0, 1, 0),    # Green
            (0.75, 1, 1, 0),   # Yellow
            (1.0, 1, 0, 0)     # Red
        ]
        
        # Jet
        color_maps[self.COLORMAP_JET] = [
            (0.0, 0, 0, 0.5),
            (0.1, 0, 0, 1),
            (0.3, 0, 1, 1),
            (0.5, 0, 1, 0),
            (0.7, 1, 1, 0),
            (0.9, 1, 0, 0),
            (1.0, 0.5, 0, 0)
        ]
        
        # Viridis
        color_maps[self.COLORMAP_VIRIDIS] = [
            (0.0, 0.267, 0.005, 0.329),
            (0.14, 0.283, 0.141, 0.458),
            (0.29, 0.232, 0.318, 0.544),
            (0.43, 0.171, 0.466, 0.558),
            (0.57, 0.129, 0.6, 0.553),
            (0.71, 0.157, 0.712, 0.431),
            (0.86, 0.365, 0.8, 0.276),
            (1.0, 0.993, 0.906, 0.144)
        ]
        
        # Plasma
        color_maps[self.COLORMAP_PLASMA] = [
            (0.0, 0.05, 0.03, 0.52),
            (0.14, 0.36, 0.04, 0.57),
            (0.29, 0.56, 0.01, 0.53),
            (0.43, 0.71, 0.15, 0.45),
            (0.57, 0.83, 0.28, 0.35),
            (0.71, 0.93, 0.43, 0.26),
            (0.86, 0.99, 0.68, 0.38),
            (1.0, 0.94, 0.98, 0.68)
        ]
        
        # Bone
        color_maps[self.COLORMAP_BONE] = [
            (0.0, 0, 0, 0),
            (0.4, 0.3, 0.3, 0.3),
            (0.7, 0.7, 0.7, 0.7),
            (1.0, 1, 1, 1)
        ]
        
        # Cool
        color_maps[self.COLORMAP_COOL] = [
            (0.0, 0, 1, 1),
            (1.0, 1, 0, 1)
        ]
        
        return color_maps
    
    def get_color_map_names(self):
        """
        Get the names of available color maps.
        
        Returns:
            list: List of color map names
        """
        return [
            "Grayscale",
            "Hot Metal",
            "Rainbow",
            "Jet",
            "Viridis",
            "Plasma",
            "Bone",
            "Cool"
        ]
    
    def _create_lut(self, color_map_id):
        """
        Create a lookup table from a color map.
        
        Args:
            color_map_id (int): Color map identifier
            
        Returns:
            vtkLookupTable: VTK lookup table
        """
        if color_map_id not in self.color_maps:
            logger.warning(f"Unknown color map: {color_map_id}")
            color_map_id = self.COLORMAP_GRAYSCALE
        
        # Get color map
        color_map = self.color_maps[color_map_id]
        
        # Create lookup table
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(256)
        lut.SetRampToLinear()
        
        # Set colors from color map
        for value, r, g, b in color_map:
            index = int(value * 255)
            lut.SetTableValue(index, r, g, b, 1.0)
        
        # Interpolate intermediate colors
        lut.Build()
        
        return lut
    
    def set_pet_colormap(self, color_map_id):
        """
        Set the color map for PET images.
        
        Args:
            color_map_id (int): Color map identifier
        """
        self.pet_lut = self._create_lut(color_map_id)
        self._update_pet_lut()
    
    def set_ct_colormap(self, color_map_id):
        """
        Set the color map for CT images.
        
        Args:
            color_map_id (int): Color map identifier
        """
        self.ct_lut = self._create_lut(color_map_id)
        self._update_ct_lut()
    
    def set_fusion_colormap(self, color_map_id):
        """
        Set the color map for fusion images.
        
        Args:
            color_map_id (int): Color map identifier
        """
        self.fusion_lut = self._create_lut(color_map_id)
        self._update_fusion_lut()
    
    def set_pet_window_level(self, window, level):
        """
        Set window/level values for PET images.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        self.pet_window = window
        self.pet_level = level
        self._update_pet_lut()
    
    def set_ct_window_level(self, window, level):
        """
        Set window/level values for CT images.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        self.ct_window = window
        self.ct_level = level
        self._update_ct_lut()
    
    def set_fusion_window_level(self, window, level):
        """
        Set window/level values for fusion images.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        # For fusion, we update both PET and CT
        self.pet_window = window
        self.pet_level = level
        self.ct_window = window
        self.ct_level = level
        self._update_pet_lut()
        self._update_ct_lut()
        self._update_fusion_lut()
    
    def _update_pet_lut(self):
        """Update the PET lookup table with current window/level values."""
        if self.pet_lut is not None:
            self.pet_lut.SetRange(self.pet_level - self.pet_window/2, self.pet_level + self.pet_window/2)
            self.pet_lut.Build()
    
    def _update_ct_lut(self):
        """Update the CT lookup table with current window/level values."""
        if self.ct_lut is not None:
            self.ct_lut.SetRange(self.ct_level - self.ct_window/2, self.ct_level + self.ct_window/2)
            self.ct_lut.Build()
    
    def _update_fusion_lut(self):
        """Update the fusion lookup table with current window/level values."""
        if self.fusion_lut is not None:
            fusion_level = (self.pet_level + self.ct_level) / 2
            fusion_window = (self.pet_window + self.ct_window) / 2
            self.fusion_lut.SetRange(fusion_level - fusion_window/2, fusion_level + fusion_window/2)
            self.fusion_lut.Build()
    
    def get_pet_lut(self):
        """
        Get the PET lookup table.
        
        Returns:
            vtkLookupTable: PET lookup table
        """
        return self.pet_lut
    
    def get_ct_lut(self):
        """
        Get the CT lookup table.
        
        Returns:
            vtkLookupTable: CT lookup table
        """
        return self.ct_lut
    
    def get_fusion_lut(self):
        """
        Get the fusion lookup table.
        
        Returns:
            vtkLookupTable: Fusion lookup table
        """
        return self.fusion_lut
    
    def create_color_bar_actor(self, modality, width=20, height=200):
        """
        Create a color bar actor for displaying the color scale.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
            width (int): Width of the color bar
            height (int): Height of the color bar
            
        Returns:
            vtkActor: VTK actor for the color bar
        """
        # Get lookup table based on modality
        lut = None
        if modality == self.PET:
            lut = self.pet_lut
        elif modality == self.CT:
            lut = self.ct_lut
        elif modality == self.FUSION:
            lut = self.fusion_lut
        
        if lut is None:
            logger.warning(f"No lookup table for modality {modality}")
            return None
        
        try:
            # Create color bar
            color_bar = vtk.vtkScalarBarActor()
            color_bar.SetLookupTable(lut)
            color_bar.SetWidth(0.1)
            color_bar.SetHeight(0.8)
            color_bar.SetPosition(0.9, 0.1)
            color_bar.SetLabelFormat("%.1f")
            color_bar.SetNumberOfLabels(5)
            color_bar.SetOrientationToVertical()
            
            # Set title based on modality
            if modality == self.PET:
                color_bar.SetTitle("SUV")
            elif modality == self.CT:
                color_bar.SetTitle("HU")
            else:
                color_bar.SetTitle("Value")
            
            # Customize text properties
            title_prop = color_bar.GetTitleTextProperty()
            title_prop.SetColor(1, 1, 1)
            title_prop.SetFontSize(12)
            title_prop.SetBold(True)
            
            label_prop = color_bar.GetLabelTextProperty()
            label_prop.SetColor(1, 1, 1)
            label_prop.SetFontSize(10)
            
            return color_bar
        except Exception as e:
            logger.error(f"Error creating color bar actor: {str(e)}")
            return None


class ColorMapWidget(QtWidgets.QWidget):
    """
    Widget for selecting and customizing color maps.
    """
    
    # Signal emitted when color map changes
    colorMapChanged = QtCore.pyqtSignal(int)
    
    # Signal emitted when window/level changes
    windowLevelChanged = QtCore.pyqtSignal(float, float)
    
    def __init__(self, parent=None):
        """
        Initialize the ColorMapWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(ColorMapWidget, self).__init__(parent)
        
        # Create color map handler
        self.color_map_handler = ColorMapHandler()
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        
        # Create color map selector
        selector_layout = QtWidgets.QHBoxLayout()
        selector_label = QtWidgets.QLabel("Color Map:")
        self.color_map_combo = QtWidgets.QComboBox()
        self.color_map_combo.addItems(self.color_map_handler.get_color_map_names())
        self.color_map_combo.currentIndexChanged.connect(self._on_color_map_changed)
        
        selector_layout.addWidget(selector_label)
        selector_layout.addWidget(self.color_map_combo, 1)
        
        # Create window/level controls
        wl_layout = QtWidgets.QGridLayout()
        
        # Window control
        window_label = QtWidgets.QLabel("Window:")
        self.window_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.window_slider.setMinimum(1)
        self.window_slider.setMaximum(1000)
        self.window_slider.setValue(400)
        self.window_slider.valueChanged.connect(self._on_window_changed)
        
        self.window_spin = QtWidgets.QSpinBox()
        self.window_spin.setMinimum(1)
        self.window_spin.setMaximum(5000)
        self.window_spin.setValue(400)
        self.window_spin.valueChanged.connect(self._on_window_spin_changed)
        
        # Level control
        level_label = QtWidgets.QLabel("Level:")
        self.level_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.level_slider.setMinimum(-1000)
        self.level_slider.setMaximum(1000)
        self.level_slider.setValue(40)
        self.level_slider.valueChanged.connect(self._on_level_changed)
        
        self.level_spin = QtWidgets.QSpinBox()
        self.level_spin.setMinimum(-1000)
        self.level_spin.setMaximum(3000)
        self.level_spin.setValue(40)
        self.level_spin.valueChanged.connect(self._on_level_spin_changed)
        
        # Add controls to layout
        wl_layout.addWidget(window_label, 0, 0)
        wl_layout.addWidget(self.window_slider, 0, 1)
        wl_layout.addWidget(self.window_spin, 0, 2)
        wl_layout.addWidget(level_label, 1, 0)
        wl_layout.addWidget(self.level_slider, 1, 1)
        wl_layout.addWidget(self.level_spin, 1, 2)
        
        # Create preset buttons
        preset_layout = QtWidgets.QHBoxLayout()
        
        # CT presets
        self.preset_lung = QtWidgets.QPushButton("Lung")
        self.preset_lung.clicked.connect(lambda: self._set_preset(1500, -600))
        
        self.preset_bone = QtWidgets.QPushButton("Bone")
        self.preset_bone.clicked.connect(lambda: self._set_preset(2000, 400))
        
        self.preset_soft = QtWidgets.QPushButton("Soft Tissue")
        self.preset_soft.clicked.connect(lambda: self._set_preset(400, 40))
        
        self.preset_brain = QtWidgets.QPushButton("Brain")
        self.preset_brain.clicked.connect(lambda: self._set_preset(80, 40))
        
        # Add buttons to layout
        preset_layout.addWidget(self.preset_lung)
        preset_layout.addWidget(self.preset_bone)
        preset_layout.addWidget(self.preset_soft)
        preset_layout.addWidget(self.preset_brain)
        
        # Create color bar preview
        self.color_bar = QtWidgets.QLabel()
        self.color_bar.setMinimumHeight(150)
        self.color_bar.setStyleSheet("border: 1px solid #aaa;")
        
        # Add widgets to main layout
        layout.addLayout(selector_layout)
        layout.addLayout(wl_layout)
        layout.addLayout(preset_layout)
        layout.addWidget(self.color_bar, 1)
        
        # Initialize color bar
        self._update_color_bar()
    
    def set_modality(self, modality):
        """
        Set the modality for this widget.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
        """
        # Set appropriate color map and window/level values
        if modality == ColorMapHandler.PET:
            self.color_map_combo.setCurrentIndex(ColorMapHandler.COLORMAP_HOT_METAL)
            self._set_window_level(6.0, 3.0)
        elif modality == ColorMapHandler.CT:
            self.color_map_combo.setCurrentIndex(ColorMapHandler.COLORMAP_GRAYSCALE)
            self._set_window_level(400.0, 40.0)
        elif modality == ColorMapHandler.FUSION:
            self.color_map_combo.setCurrentIndex(ColorMapHandler.COLORMAP_JET)
            self._set_window_level(400.0, 40.0)
    
    def _on_color_map_changed(self, index):
        """
        Handle color map change.
        
        Args:
            index (int): Color map index
        """
        self.colorMapChanged.emit(index)
        self._update_color_bar()
    
    def _on_window_changed(self, value):
        """
        Handle window slider change.
        
        Args:
            value (int): Window value
        """
        self.window_spin.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _on_window_spin_changed(self, value):
        """
        Handle window spin box change.
        
        Args:
            value (int): Window value
        """
        self.window_slider.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _on_level_changed(self, value):
        """
        Handle level slider change.
        
        Args:
            value (int): Level value
        """
        self.level_spin.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _on_level_spin_changed(self, value):
        """
        Handle level spin box change.
        
        Args:
            value (int): Level value
        """
        self.level_slider.setValue(value)
        self._emit_window_level()
        self._update_color_bar()
    
    def _emit_window_level(self):
        """Emit window/level changed signal."""
        window = self.window_spin.value()
        level = self.level_spin.value()
        self.windowLevelChanged.emit(float(window), float(level))
    
    def _set_preset(self, window, level):
        """
        Set a window/level preset.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        self._set_window_level(window, level)
        self._emit_window_level()
        self._update_color_bar()
    
    def _set_window_level(self, window, level):
        """
        Set window/level values.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        # Update controls
        self.window_slider.setValue(min(1000, int(window)))
        self.window_spin.setValue(int(window))
        self.level_slider.setValue(max(-1000, min(1000, int(level))))
        self.level_spin.setValue(int(level))
    
    def _update_color_bar(self):
        """Update the color bar preview."""
        # Get current color map
        color_map_id = self.color_map_combo.currentIndex()
        
        # Get window/level values
        window = self.window_spin.value()
        level = self.level_spin.value()
        
        # Create gradient image
        width = 20
        height = 150
        image = QtGui.QImage(width, height, QtGui.QImage.Format_RGB32)
        
        # Get color map
        color_map = self.color_map_handler.color_maps[color_map_id]
        
        # Calculate value range
        min_val = level - window/2
        max_val = level + window/2
        
        # Fill image with gradient
        for y in range(height):
            # Calculate value (bottom to top)
            value = min_val + (max_val - min_val) * (height - 1 - y) / (height - 1)
            
            # Normalize value to 0-1 range
            norm_value = (value - min_val) / (max_val - min_val)
            norm_value = max(0, min(1, norm_value))
            
            # Find color in color map
            r, g, b = self._get_color_from_map(color_map, norm_value)
            
            # Fill row with color
            color = QtGui.qRgb(int(r*255), int(g*255), int(b*255))
            for x in range(width):
                image.setPixel(x, y, color)
        
        # Create pixmap and set to label
        pixmap = QtGui.QPixmap.fromImage(image)
        self.color_bar.setPixmap(pixmap)
    
    def _get_color_from_map(self, color_map, value):
        """
        Get color from color map for a specific value.
        
        Args:
            color_map (list): Color map as list of (value, r, g, b) tuples
            value (float): Value to get color for (0-1)
            
        Returns:
            tuple: (r, g, b) color values (0-1)
        """
        # Handle edge cases
        if value <= color_map[0][0]:
            return color_map[0][1:]
        
        if value >= color_map[-1][0]:
            return color_map[-1][1:]
        
        # Find surrounding points in color map
        for i in range(len(color_map) - 1):
            if color_map[i][0] <= value < color_map[i+1][0]:
                # Interpolate between points
                t = (value - color_map[i][0]) / (color_map[i+1][0] - color_map[i][0])
                r = color_map[i][1] + t * (color_map[i+1][1] - color_map[i][1])
                g = color_map[i][2] + t * (color_map[i+1][2] - color_map[i][2])
                b = color_map[i][3] + t * (color_map[i+1][3] - color_map[i][3])
                return (r, g, b)
        
        # Fallback
        return (0, 0, 0)


class ColorBarWidget(QtWidgets.QWidget):
    """
    Widget for displaying a color intensity bar.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the ColorBarWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(ColorBarWidget, self).__init__(parent)
        
        # Create color map handler
        self.color_map_handler = ColorMapHandler()
        
        # Create layout
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create color bar
        self.color_bar = QtWidgets.QLabel()
        self.color_bar.setMinimumWidth(20)
        self.color_bar.setStyleSheet("border: 1px solid #aaa;")
        
        # Create labels
        self.max_label = QtWidgets.QLabel("Max")
        self.max_label.setAlignment(QtCore.Qt.AlignCenter)
        self.min_label = QtWidgets.QLabel("Min")
        self.min_label.setAlignment(QtCore.Qt.AlignCenter)
        
        # Add widgets to layout
        layout.addWidget(self.max_label)
        layout.addWidget(self.color_bar, 1)
        layout.addWidget(self.min_label)
        
        # Initialize variables
        self.modality = ColorMapHandler.CT
        self.color_map_id = ColorMapHandler.COLORMAP_GRAYSCALE
        self.window = 400.0
        self.level = 40.0
        
        # Update color bar
        self._update_color_bar()
    
    def set_modality(self, modality):
        """
        Set the modality for this widget.
        
        Args:
            modality (int): Modality type (PET, CT, or FUSION)
        """
        self.modality = modality
        
        # Set appropriate color map and window/level values
        if modality == ColorMapHandler.PET:
            self.color_map_id = ColorMapHandler.COLORMAP_HOT_METAL
            self.window = 6.0
            self.level = 3.0
            self.max_label.setText("SUV Max")
            self.min_label.setText("SUV Min")
        elif modality == ColorMapHandler.CT:
            self.color_map_id = ColorMapHandler.COLORMAP_GRAYSCALE
            self.window = 400.0
            self.level = 40.0
            self.max_label.setText("HU Max")
            self.min_label.setText("HU Min")
        elif modality == ColorMapHandler.FUSION:
            self.color_map_id = ColorMapHandler.COLORMAP_JET
            self.window = 400.0
            self.level = 40.0
            self.max_label.setText("Max")
            self.min_label.setText("Min")
        
        self._update_color_bar()
    
    def set_color_map(self, color_map_id):
        """
        Set the color map.
        
        Args:
            color_map_id (int): Color map identifier
        """
        self.color_map_id = color_map_id
        self._update_color_bar()
    
    def set_window_level(self, window, level):
        """
        Set window/level values.
        
        Args:
            window (float): Window value
            level (float): Level value
        """
        self.window = window
        self.level = level
        
        # Update labels
        min_val = level - window/2
        max_val = level + window/2
        
        if self.modality == ColorMapHandler.PET:
            self.max_label.setText(f"SUV {max_val:.1f}")
            self.min_label.setText(f"SUV {min_val:.1f}")
        elif self.modality == ColorMapHandler.CT:
            self.max_label.setText(f"HU {max_val:.0f}")
            self.min_label.setText(f"HU {min_val:.0f}")
        else:
            self.max_label.setText(f"{max_val:.0f}")
            self.min_label.setText(f"{min_val:.0f}")
        
        self._update_color_bar()
    
    def _update_color_bar(self):
        """Update the color bar."""
        # Get color map
        color_map = self.color_map_handler.color_maps[self.color_map_id]
        
        # Create gradient image
        width = 20
        height = 150
        image = QtGui.QImage(width, height, QtGui.QImage.Format_RGB32)
        
        # Fill image with gradient
        for y in range(height):
            # Calculate normalized value (bottom to top)
            norm_value = (height - 1 - y) / (height - 1)
            
            # Find color in color map
            r, g, b = self._get_color_from_map(color_map, norm_value)
            
            # Fill row with color
            color = QtGui.qRgb(int(r*255), int(g*255), int(b*255))
            for x in range(width):
                image.setPixel(x, y, color)
        
        # Create pixmap and set to label
        pixmap = QtGui.QPixmap.fromImage(image)
        self.color_bar.setPixmap(pixmap)
    
    def _get_color_from_map(self, color_map, value):
        """
        Get color from color map for a specific value.
        
        Args:
            color_map (list): Color map as list of (value, r, g, b) tuples
            value (float): Value to get color for (0-1)
            
        Returns:
            tuple: (r, g, b) color values (0-1)
        """
        # Handle edge cases
        if value <= color_map[0][0]:
            return color_map[0][1:]
        
        if value >= color_map[-1][0]:
            return color_map[-1][1:]
        
        # Find surrounding points in color map
        for i in range(len(color_map) - 1):
            if color_map[i][0] <= value < color_map[i+1][0]:
                # Interpolate between points
                t = (value - color_map[i][0]) / (color_map[i+1][0] - color_map[i][0])
                r = color_map[i][1] + t * (color_map[i+1][1] - color_map[i][1])
                g = color_map[i][2] + t * (color_map[i+1][2] - color_map[i][2])
                b = color_map[i][3] + t * (color_map[i+1][3] - color_map[i][3])
                return (r, g, b)
        
        # Fallback
        return (0, 0, 0)


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("Color Map Test")
    window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QHBoxLayout(central_widget)
    
    # Create color map widget
    color_map_widget = ColorMapWidget()
    layout.addWidget(color_map_widget)
    
    # Create color bar widget
    color_bar_widget = ColorBarWidget()
    layout.addWidget(color_bar_widget)
    
    # Connect signals
    color_map_widget.colorMapChanged.connect(color_bar_widget.set_color_map)
    color_map_widget.windowLevelChanged.connect(color_bar_widget.set_window_level)
    
    # Set initial modality
    color_map_widget.set_modality(ColorMapHandler.CT)
    color_bar_widget.set_modality(ColorMapHandler.CT)
    
    # Show window
    window.show()
    
    sys.exit(app.exec_())
