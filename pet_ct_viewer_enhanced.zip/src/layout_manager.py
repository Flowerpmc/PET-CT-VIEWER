#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UI Layout Manager Module for PET/CT Viewer
----------------------------------------
This module provides manual adjustment capabilities for UI windows and layouts.
"""

import os
import sys
import logging
import json
from PyQt5 import QtCore, QtGui, QtWidgets

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('LayoutManager')

class ResizableWidget(QtWidgets.QWidget):
    """
    Widget that can be resized by the user.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the ResizableWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(ResizableWidget, self).__init__(parent)
        
        # Enable mouse tracking
        self.setMouseTracking(True)
        
        # Initialize variables
        self.resizing = False
        self.resize_edge = None
        self.start_pos = None
        self.start_geometry = None
        self.min_size = QtCore.QSize(100, 100)
        self.border_width = 5
        
        # Set frame style
        self.setFrameStyle(QtWidgets.QFrame.Box | QtWidgets.QFrame.Raised)
        self.setLineWidth(1)
    
    def mousePressEvent(self, event):
        """
        Handle mouse press events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if event.button() == QtCore.Qt.LeftButton:
            # Check if near edge
            edge = self._get_resize_edge(event.pos())
            if edge:
                self.resizing = True
                self.resize_edge = edge
                self.start_pos = event.globalPos()
                self.start_geometry = self.geometry()
                event.accept()
                return
        
        super(ResizableWidget, self).mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        """
        Handle mouse move events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if self.resizing and self.resize_edge and self.start_pos:
            # Calculate delta
            delta = event.globalPos() - self.start_pos
            
            # Apply resize based on edge
            new_geometry = QtCore.QRect(self.start_geometry)
            
            if 'left' in self.resize_edge:
                new_width = max(self.min_size.width(), self.start_geometry.width() - delta.x())
                new_x = self.start_geometry.x() + self.start_geometry.width() - new_width
                new_geometry.setLeft(new_x)
            elif 'right' in self.resize_edge:
                new_width = max(self.min_size.width(), self.start_geometry.width() + delta.x())
                new_geometry.setWidth(new_width)
            
            if 'top' in self.resize_edge:
                new_height = max(self.min_size.height(), self.start_geometry.height() - delta.y())
                new_y = self.start_geometry.y() + self.start_geometry.height() - new_height
                new_geometry.setTop(new_y)
            elif 'bottom' in self.resize_edge:
                new_height = max(self.min_size.height(), self.start_geometry.height() + delta.y())
                new_geometry.setHeight(new_height)
            
            # Apply new geometry
            self.setGeometry(new_geometry)
            event.accept()
            return
        elif not self.resizing:
            # Update cursor based on position
            edge = self._get_resize_edge(event.pos())
            if edge:
                if edge in ['left', 'right']:
                    self.setCursor(QtCore.Qt.SizeHorCursor)
                elif edge in ['top', 'bottom']:
                    self.setCursor(QtCore.Qt.SizeVerCursor)
                elif edge in ['top-left', 'bottom-right']:
                    self.setCursor(QtCore.Qt.SizeFDiagCursor)
                elif edge in ['top-right', 'bottom-left']:
                    self.setCursor(QtCore.Qt.SizeBDiagCursor)
                event.accept()
                return
            else:
                self.setCursor(QtCore.Qt.ArrowCursor)
        
        super(ResizableWidget, self).mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        """
        Handle mouse release events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if event.button() == QtCore.Qt.LeftButton and self.resizing:
            self.resizing = False
            self.resize_edge = None
            self.start_pos = None
            self.start_geometry = None
            event.accept()
            return
        
        super(ResizableWidget, self).mouseReleaseEvent(event)
    
    def _get_resize_edge(self, pos):
        """
        Determine which edge the position is near.
        
        Args:
            pos (QPoint): Position to check
            
        Returns:
            str: Edge name, or None if not near an edge
        """
        x, y = pos.x(), pos.y()
        width, height = self.width(), self.height()
        
        # Check corners first
        if x < self.border_width and y < self.border_width:
            return 'top-left'
        elif x > width - self.border_width and y < self.border_width:
            return 'top-right'
        elif x < self.border_width and y > height - self.border_width:
            return 'bottom-left'
        elif x > width - self.border_width and y > height - self.border_width:
            return 'bottom-right'
        
        # Check edges
        if x < self.border_width:
            return 'left'
        elif x > width - self.border_width:
            return 'right'
        elif y < self.border_width:
            return 'top'
        elif y > height - self.border_width:
            return 'bottom'
        
        return None


class DraggableWidget(QtWidgets.QWidget):
    """
    Widget that can be dragged by the user.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the DraggableWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        super(DraggableWidget, self).__init__(parent)
        
        # Enable mouse tracking
        self.setMouseTracking(True)
        
        # Initialize variables
        self.dragging = False
        self.start_pos = None
        self.start_geometry = None
        
        # Set frame style
        self.setFrameStyle(QtWidgets.QFrame.Box | QtWidgets.QFrame.Raised)
        self.setLineWidth(1)
    
    def mousePressEvent(self, event):
        """
        Handle mouse press events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if event.button() == QtCore.Qt.LeftButton:
            self.dragging = True
            self.start_pos = event.globalPos()
            self.start_geometry = self.geometry()
            event.accept()
            return
        
        super(DraggableWidget, self).mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        """
        Handle mouse move events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if self.dragging and self.start_pos:
            # Calculate delta
            delta = event.globalPos() - self.start_pos
            
            # Apply move
            new_geometry = QtCore.QRect(self.start_geometry)
            new_geometry.moveTopLeft(self.start_geometry.topLeft() + delta)
            
            # Apply new geometry
            self.setGeometry(new_geometry)
            event.accept()
            return
        
        super(DraggableWidget, self).mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        """
        Handle mouse release events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if event.button() == QtCore.Qt.LeftButton and self.dragging:
            self.dragging = False
            self.start_pos = None
            self.start_geometry = None
            event.accept()
            return
        
        super(DraggableWidget, self).mouseReleaseEvent(event)


class ResizableDraggableWidget(ResizableWidget, DraggableWidget):
    """
    Widget that can be both resized and dragged by the user.
    """
    
    def __init__(self, parent=None):
        """
        Initialize the ResizableDraggableWidget.
        
        Args:
            parent (QWidget, optional): Parent widget
        """
        ResizableWidget.__init__(self, parent)
        
        # Initialize variables from DraggableWidget
        self.dragging = False
    
    def mousePressEvent(self, event):
        """
        Handle mouse press events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if event.button() == QtCore.Qt.LeftButton:
            # Check if near edge for resizing
            edge = self._get_resize_edge(event.pos())
            if edge:
                self.resizing = True
                self.resize_edge = edge
                self.start_pos = event.globalPos()
                self.start_geometry = self.geometry()
                event.accept()
                return
            else:
                # Start dragging
                self.dragging = True
                self.start_pos = event.globalPos()
                self.start_geometry = self.geometry()
                event.accept()
                return
        
        super(ResizableWidget, self).mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        """
        Handle mouse move events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if self.resizing and self.resize_edge and self.start_pos:
            # Handle resizing (from ResizableWidget)
            ResizableWidget.mouseMoveEvent(self, event)
            return
        elif self.dragging and self.start_pos:
            # Handle dragging (from DraggableWidget)
            # Calculate delta
            delta = event.globalPos() - self.start_pos
            
            # Apply move
            new_geometry = QtCore.QRect(self.start_geometry)
            new_geometry.moveTopLeft(self.start_geometry.topLeft() + delta)
            
            # Apply new geometry
            self.setGeometry(new_geometry)
            event.accept()
            return
        elif not self.resizing and not self.dragging:
            # Update cursor based on position
            edge = self._get_resize_edge(event.pos())
            if edge:
                if edge in ['left', 'right']:
                    self.setCursor(QtCore.Qt.SizeHorCursor)
                elif edge in ['top', 'bottom']:
                    self.setCursor(QtCore.Qt.SizeVerCursor)
                elif edge in ['top-left', 'bottom-right']:
                    self.setCursor(QtCore.Qt.SizeFDiagCursor)
                elif edge in ['top-right', 'bottom-left']:
                    self.setCursor(QtCore.Qt.SizeBDiagCursor)
                event.accept()
                return
            else:
                self.setCursor(QtCore.Qt.ArrowCursor)
        
        super(ResizableWidget, self).mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        """
        Handle mouse release events.
        
        Args:
            event (QMouseEvent): Mouse event
        """
        if event.button() == QtCore.Qt.LeftButton:
            if self.resizing:
                self.resizing = False
                self.resize_edge = None
                self.start_pos = None
                self.start_geometry = None
                event.accept()
                return
            elif self.dragging:
                self.dragging = False
                self.start_pos = None
                self.start_geometry = None
                event.accept()
                return
        
        super(ResizableWidget, self).mouseReleaseEvent(event)


class DockableWidget(QtWidgets.QDockWidget):
    """
    Widget that can be docked and undocked.
    """
    
    def __init__(self, title, parent=None):
        """
        Initialize the DockableWidget.
        
        Args:
            title (str): Widget title
            parent (QWidget, optional): Parent widget
        """
        super(DockableWidget, self).__init__(title, parent)
        
        # Set features
        self.setFeatures(
            QtWidgets.QDockWidget.DockWidgetClosable |
            QtWidgets.QDockWidget.DockWidgetMovable |
            QtWidgets.QDockWidget.DockWidgetFloatable
        )
        
        # Create content widget
        self.content_widget = QtWidgets.QWidget()
        self.setWidget(self.content_widget)
        
        # Create layout for content
        self.layout = QtWidgets.QVBoxLayout(self.content_widget)
    
    def set_content(self, widget):
        """
        Set the content widget.
        
        Args:
            widget (QWidget): Content widget
        """
        # Clear layout
        while self.layout.count():
            item = self.layout.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
        
        # Add new widget
        self.layout.addWidget(widget)


class LayoutManager:
    """
    Class for managing UI layouts.
    """
    
    def __init__(self, main_window):
        """
        Initialize the LayoutManager.
        
        Args:
            main_window (QMainWindow): Main window
        """
        self.main_window = main_window
        
        # Initialize variables
        self.dock_widgets = {}
        self.layout_states = {}
        self.current_layout = "default"
    
    def create_dock_widget(self, name, title, widget, area=QtCore.Qt.RightDockWidgetArea):
        """
        Create a dockable widget.
        
        Args:
            name (str): Widget name
            title (str): Widget title
            widget (QWidget): Widget content
            area (Qt.DockWidgetArea): Dock area
            
        Returns:
            DockableWidget: Created dock widget
        """
        # Create dock widget
        dock = DockableWidget(title, self.main_window)
        dock.set_content(widget)
        
        # Add to main window
        self.main_window.addDockWidget(area, dock)
        
        # Store reference
        self.dock_widgets[name] = dock
        
        return dock
    
    def get_dock_widget(self, name):
        """
        Get a dock widget by name.
        
        Args:
            name (str): Widget name
            
        Returns:
            DockableWidget: Dock widget, or None if not found
        """
        return self.dock_widgets.get(name)
    
    def save_layout(self, name="default"):
        """
        Save the current layout.
        
        Args:
            name (str): Layout name
        """
        # Save dock widget states
        dock_states = {}
        for dock_name, dock in self.dock_widgets.items():
            dock_states[dock_name] = {
                'visible': dock.isVisible(),
                'floating': dock.isFloating(),
                'geometry': dock.geometry().getRect() if dock.isFloating() else None
            }
        
        # Save main window state
        main_state = self.main_window.saveState().toBase64().data().decode()
        
        # Store layout state
        self.layout_states[name] = {
            'dock_states': dock_states,
            'main_state': main_state
        }
        
        self.current_layout = name
    
    def restore_layout(self, name="default"):
        """
        Restore a saved layout.
        
        Args:
            name (str): Layout name
            
        Returns:
            bool: True if layout was restored, False otherwise
        """
        if name not in self.layout_states:
            logger.warning(f"Layout '{name}' not found")
            return False
        
        # Get layout state
        state = self.layout_states[name]
        
        # Restore dock widget states
        for dock_name, dock_state in state['dock_states'].items():
            if dock_name in self.dock_widgets:
                dock = self.dock_widgets[dock_name]
                dock.setVisible(dock_state['visible'])
                dock.setFloating(dock_state['floating'])
                if dock_state['floating'] and dock_state['geometry']:
                    dock.setGeometry(*dock_state['geometry'])
        
        # Restore main window state
        self.main_window.restoreState(QtCore.QByteArray.fromBase64(state['main_state'].encode()))
        
        self.current_layout = name
        return True
    
    def save_layouts_to_file(self, file_path):
        """
        Save all layouts to a file.
        
        Args:
            file_path (str): File path
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Convert layout states to serializable format
            serializable_states = {}
            for name, state in self.layout_states.items():
                serializable_states[name] = {
                    'dock_states': state['dock_states'],
                    'main_state': state['main_state']
                }
            
            # Write to file
            with open(file_path, 'w') as f:
                json.dump({
                    'layouts': serializable_states,
                    'current_layout': self.current_layout
                }, f, indent=2)
            
            return True
        except Exception as e:
            logger.error(f"Error saving layouts: {str(e)}")
            return False
    
    def load_layouts_from_file(self, file_path):
        """
        Load layouts from a file.
        
        Args:
            file_path (str): File path
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Read from file
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # Load layout states
            self.layout_states = data.get('layouts', {})
            self.current_layout = data.get('current_layout', 'default')
            
            # Restore current layout
            if self.current_layout in self.layout_states:
                self.restore_layout(self.current_layout)
            
            return True
        except Exception as e:
            logger.error(f"Error loading layouts: {str(e)}")
            return False


class SplitterWidget(QtWidgets.QSplitter):
    """
    Splitter widget with adjustable panes.
    """
    
    def __init__(self, orientation=QtCore.Qt.Horizontal, parent=None):
        """
        Initialize the SplitterWidget.
        
        Args:
            orientation (Qt.Orientation): Splitter orientation
            parent (QWidget, optional): Parent widget
        """
        super(SplitterWidget, self).__init__(orientation, parent)
        
        # Set properties
        self.setChildrenCollapsible(False)
        self.setHandleWidth(5)
        
        # Initialize variables
        self.default_sizes = []
    
    def add_widget(self, widget, stretch=1):
        """
        Add a widget to the splitter.
        
        Args:
            widget (QWidget): Widget to add
            stretch (int): Stretch factor
            
        Returns:
            int: Index of added widget
        """
        # Add widget
        self.addWidget(widget)
        
        # Set stretch factor
        count = self.count()
        self.setStretchFactor(count - 1, stretch)
        
        return count - 1
    
    def set_default_sizes(self, sizes):
        """
        Set default sizes for splitter panes.
        
        Args:
            sizes (list): List of sizes
        """
        self.default_sizes = sizes
        self.setSizes(sizes)
    
    def reset_sizes(self):
        """Reset to default sizes."""
        if self.default_sizes:
            self.setSizes(self.default_sizes)


class GridLayoutWidget(QtWidgets.QWidget):
    """
    Widget with a grid layout that can be customized.
    """
    
    def __init__(self, rows=3, cols=3, parent=None):
        """
        Initialize the GridLayoutWidget.
        
        Args:
            rows (int): Number of rows
            cols (int): Number of columns
            parent (QWidget, optional): Parent widget
        """
        super(GridLayoutWidget, self).__init__(parent)
        
        # Create layout
        self.grid_layout = QtWidgets.QGridLayout(self)
        self.grid_layout.setSpacing(5)
        
        # Initialize variables
        self.rows = rows
        self.cols = cols
        self.cells = {}
    
    def set_widget(self, row, col, widget, rowspan=1, colspan=1):
        """
        Set a widget in a grid cell.
        
        Args:
            row (int): Row index
            col (int): Column index
            widget (QWidget): Widget to add
            rowspan (int): Row span
            colspan (int): Column span
            
        Returns:
            bool: True if successful, False otherwise
        """
        if row < 0 or row >= self.rows or col < 0 or col >= self.cols:
            logger.warning(f"Invalid grid position: {row}, {col}")
            return False
        
        # Remove existing widget if any
        cell_key = (row, col)
        if cell_key in self.cells:
            old_widget = self.cells[cell_key]
            self.grid_layout.removeWidget(old_widget)
            old_widget.setParent(None)
        
        # Add new widget
        self.grid_layout.addWidget(widget, row, col, rowspan, colspan)
        self.cells[cell_key] = widget
        
        return True
    
    def get_widget(self, row, col):
        """
        Get the widget at a grid cell.
        
        Args:
            row (int): Row index
            col (int): Column index
            
        Returns:
            QWidget: Widget at the specified position, or None if not found
        """
        return self.cells.get((row, col))
    
    def clear_cell(self, row, col):
        """
        Clear a grid cell.
        
        Args:
            row (int): Row index
            col (int): Column index
            
        Returns:
            bool: True if successful, False otherwise
        """
        cell_key = (row, col)
        if cell_key in self.cells:
            widget = self.cells[cell_key]
            self.grid_layout.removeWidget(widget)
            widget.setParent(None)
            del self.cells[cell_key]
            return True
        
        return False
    
    def clear_all(self):
        """Clear all grid cells."""
        for cell_key in list(self.cells.keys()):
            widget = self.cells[cell_key]
            self.grid_layout.removeWidget(widget)
            widget.setParent(None)
        
        self.cells = {}
    
    def resize_grid(self, rows, cols):
        """
        Resize the grid.
        
        Args:
            rows (int): New number of rows
            cols (int): New number of columns
            
        Returns:
            bool: True if successful, False otherwise
        """
        if rows <= 0 or cols <= 0:
            logger.warning(f"Invalid grid size: {rows}x{cols}")
            return False
        
        # Remove widgets outside new grid
        for cell_key in list(self.cells.keys()):
            row, col = cell_key
            if row >= rows or col >= cols:
                widget = self.cells[cell_key]
                self.grid_layout.removeWidget(widget)
                widget.setParent(None)
                del self.cells[cell_key]
        
        # Update grid size
        self.rows = rows
        self.cols = cols
        
        return True


# Example usage
if __name__ == "__main__":
    # This is just for testing - in real use, this would be imported by the main application
    app = QtWidgets.QApplication(sys.argv)
    
    # Create main window
    main_window = QtWidgets.QMainWindow()
    main_window.setWindowTitle("Layout Manager Test")
    main_window.setGeometry(100, 100, 800, 600)
    
    # Create central widget
    central_widget = QtWidgets.QWidget()
    main_window.setCentralWidget(central_widget)
    
    # Create layout
    layout = QtWidgets.QVBoxLayout(central_widget)
    
    # Create grid layout widget
    grid_widget = GridLayoutWidget(3, 3)
    layout.addWidget(grid_widget)
    
    # Add some test widgets to grid
    for row in range(3):
        for col in range(3):
            widget = ResizableDraggableWidget()
            widget.setMinimumSize(100, 100)
            label = QtWidgets.QLabel(f"Cell {row},{col}")
            label.setAlignment(QtCore.Qt.AlignCenter)
            widget_layout = QtWidgets.QVBoxLayout(widget)
            widget_layout.addWidget(label)
            grid_widget.set_widget(row, col, widget)
    
    # Create layout manager
    layout_manager = LayoutManager(main_window)
    
    # Create some dock widgets
    tools_widget = QtWidgets.QWidget()
    tools_layout = QtWidgets.QVBoxLayout(tools_widget)
    tools_layout.addWidget(QtWidgets.QPushButton("Tool 1"))
    tools_layout.addWidget(QtWidgets.QPushButton("Tool 2"))
    tools_layout.addWidget(QtWidgets.QPushButton("Tool 3"))
    
    layout_manager.create_dock_widget("tools", "Tools", tools_widget, QtCore.Qt.LeftDockWidgetArea)
    
    info_widget = QtWidgets.QWidget()
    info_layout = QtWidgets.QVBoxLayout(info_widget)
    info_layout.addWidget(QtWidgets.QLabel("Patient Information"))
    info_layout.addWidget(QtWidgets.QLineEdit())
    
    layout_manager.create_dock_widget("info", "Information", info_widget, QtCore.Qt.RightDockWidgetArea)
    
    # Create layout controls
    control_layout = QtWidgets.QHBoxLayout()
    
    save_button = QtWidgets.QPushButton("Save Layout")
    save_button.clicked.connect(lambda: layout_manager.save_layout("test"))
    
    restore_button = QtWidgets.QPushButton("Restore Layout")
    restore_button.clicked.connect(lambda: layout_manager.restore_layout("test"))
    
    control_layout.addWidget(save_button)
    control_layout.addWidget(restore_button)
    
    layout.addLayout(control_layout)
    
    # Show window
    main_window.show()
    
    sys.exit(app.exec_())
