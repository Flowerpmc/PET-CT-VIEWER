# PET/CT DICOM Viewer - User Guide

## Overview

This PET/CT DICOM Viewer is a comprehensive application for viewing, analyzing, and reporting on PET/CT DICOM images. It provides a robust set of features for medical professionals working with PET/CT data, including:

- 3x3 layout with PET, CT, and fused views
- Adjustable MIP view panel
- Advanced quantification tools (SUV calculation, volume measurement)
- Annotation and reporting capabilities
- PACS integration for seamless workflow
- Customizable layouts and visualization options

## Installation

### Prerequisites

- Python 3.8 or higher
- Required Python packages:
  - pydicom
  - numpy
  - vtk
  - PyQt5
  - matplotlib
  - pynetdicom (for PACS connectivity)
  - python-docx (for report generation)
  - pandas (for data export)
  - weasyprint (for PDF export)

### Installation Steps

1. Clone or download the repository to your local machine
2. Install required packages:

```bash
pip install pydicom numpy vtk PyQt5 matplotlib pynetdicom python-docx pandas weasyprint
```

3. Run the application:

```bash
python src/main.py
```

## Features

### Main Interface

The application provides a 3x3 grid layout:
- Top row: PET images (axial, coronal, sagittal)
- Middle row: CT images (axial, coronal, sagittal)
- Bottom row: Fused PET/CT images (axial, coronal, sagittal)
- Right panel: MIP view with rotation controls

### Navigation

- Use mouse wheel to scroll through slices
- Click and drag to pan images
- Right-click and drag to adjust window/level

### Quantification Tools

Access quantification tools from the Tools menu:
- Distance measurement
- Area measurement
- Angle measurement
- SUV calculation
- Volume calculation

### Annotation Tools

Access annotation tools from the Tools menu:
- Text annotations
- Arrow annotations
- Save annotations for later review

### Viewing Options

The View menu provides different layout options:
- 3x3 + MIP (default)
- 1x3 + MIP
- 2x2
- Synchronize views option

### Window/Level Presets

Access window/level presets from the Settings menu:
- Lung
- Bone
- Soft tissue
- Custom presets

### PACS Integration

Connect to PACS servers to:
- Query for studies
- Retrieve today's cases
- Download studies and series
- Upload results

### Search Functionality

Search for studies by:
- Patient name
- Patient ID
- Study date
- Modality
- Description

### Report Generation

Generate reports with:
- Patient information
- Study information
- Measurements and annotations
- Screenshots
- Export to HTML, DOCX, or PDF formats

## Module Structure

The application is organized into the following modules:

- `main.py`: Main application entry point
- `dicom_loader.py`: DICOM file loading and processing
- `dicom_visualizer.py`: Visualization of PET/CT images
- `dicom_quantification.py`: Measurement and quantification tools
- `dicom_search.py`: Search functionality for DICOM studies
- `pacs_connector.py`: PACS connectivity and networking
- `dicom_validator.py`: Validation and error handling
- `report_generator.py`: Report generation and export

## Usage Examples

### Loading DICOM Data

1. Click File > Open DICOM Folder
2. Select a directory containing PET/CT DICOM files
3. The application will load and display the images

### Measuring SUV

1. Select "SUV" from the Tools > Measurement menu
2. Click on a point of interest in the PET image
3. The SUV value will be displayed and can be added to the report

### Creating a Report

1. Add annotations and measurements to the images
2. Click File > Export Report
3. Choose the report format (HTML, DOCX, or PDF)
4. Enter additional report information if prompted
5. Save the report to your desired location

### Connecting to PACS

1. Enter PACS connection details in the left panel
2. Click "Connect to PACS"
3. Use the search functionality to find studies
4. Double-click a study to retrieve and load it

## Troubleshooting

### Common Issues

- **Images not displaying correctly**: Ensure the DICOM files are valid and contain pixel data
- **SUV calculation errors**: Check that the PET images contain required DICOM tags for SUV calculation
- **PACS connection failures**: Verify network connectivity and PACS server settings
- **Report generation errors**: Ensure required libraries are installed

### Error Logging

Error logs are stored in the user's home directory under `.pet_ct_viewer/logs/`

## Advanced Configuration

Advanced configuration options can be set in the `config.json` file:

- Default window/level values
- Color maps
- PACS connection settings
- Report templates

## License

This software is provided under the MIT License. See LICENSE file for details.

## Support

For support or feature requests, please contact the development team.
